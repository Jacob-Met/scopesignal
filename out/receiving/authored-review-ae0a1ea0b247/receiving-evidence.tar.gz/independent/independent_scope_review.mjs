import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const here = dirname(fileURLToPath(import.meta.url));
const source = resolve(process.argv[2] ?? '/dev/shm/ae0a1ea0b247-scopesignal-review');
const out = resolve(process.argv[3] ?? here);
mkdirSync(out, { recursive: true });
const expectedHead = 'e60084d731d441e00efdda680f288fb3e711803a';
const expectedBaseline = '8a241c9ce409fa9b22ab0bbdc339e46fd4b38525';
const git = (...args) => execFileSync('git', args, { cwd: source, encoding: 'utf8' }).trim();
const sha256 = bytes => createHash('sha256').update(bytes).digest('hex');
const gitBlob = bytes => createHash('sha1').update(`blob ${bytes.length}\0`).update(bytes).digest('hex');
const sourceFiles = [
  'src/scope-review-export.mjs', 'src/scope-workspace.mjs', 'scope.html',
  'src/scope-workspace-record.mjs', 'src/scope-plan.mjs', 'src/ledger.mjs',
  'src/payment-status.mjs', 'tests/scope-review-export.test.mjs', 'source-pin.json'
];
const pins = () => Object.fromEntries(sourceFiles.map(path => {
  const bytes = readFileSync(resolve(source, path));
  return [path, { gitBlob: gitBlob(bytes), sha256: sha256(bytes), bytes: bytes.length }];
}));
const beforePins = pins();
const receipt = {
  review: 'Independent source/native receiving of ScopeSignal authored-scope HTML export',
  boundary: 'Synthetic authored workspace only. Python standard-library HTML tokenization, not browser layout/print or live payment verification. No product mutations or broad suite rerun.',
  startedAt: new Date().toISOString(), source, expectedHead, expectedBaseline,
  head: git('rev-parse', 'HEAD'), tree: git('rev-parse', 'HEAD^{tree}'),
  baselineClosure: git('rev-parse', 'HEAD~2'), runtime: process.version,
  sourcePinsBefore: beforePins, groups: [], artifacts: {}
};
const run = (name, fn) => {
  const result = { name };
  try { result.evidence = fn(); result.status = 'PASS'; }
  catch (error) { result.status = 'FAIL'; result.error = error.stack; throw error; }
  finally { receipt.groups.push(result); }
};
const save = (name, contents) => {
  writeFileSync(resolve(out, name), contents);
  const bytes = readFileSync(resolve(out, name));
  receipt.artifacts[name] = { bytes: bytes.length, sha256: sha256(bytes), gitBlob: gitBlob(bytes) };
};
const snapshotCaller = workspace => JSON.stringify({
  draft: workspace.draft, review: workspace.review?.snapshot() ?? null,
  evidenceDrafts: [...(workspace.evidenceDrafts ?? new Map())]
});
const freeze = value => {
  if (value && typeof value === 'object') {
    for (const child of Object.values(value)) freeze(child);
    Object.freeze(value);
  }
  return value;
};
// Independently format fixture expectations from integer cents; do not call the
// production money formatter to manufacture the expected displayed numbers.
const money = cents => {
  const value = BigInt(cents);
  return '$' + String(value / 100n).replace(/\B(?=(\d{3})+(?!\d))/g, ',') + '.' + String(value % 100n).padStart(2, '0');
};
const parse = html => {
  const result = JSON.parse(execFileSync(process.env.CODEX_PRIMARY_RUNTIME_PYTHON ?? 'python3',
    [resolve(here, 'parse_html.py')], { input: Buffer.from(html), encoding: 'utf8', maxBuffer: 2 * 1024 * 1024 }));
  assert.deepEqual(result.errors, []);
  assert.deepEqual(result.declarations, ['doctype html']);
  return result.root;
};
const elements = node => typeof node === 'string' ? [] : [node, ...node.children.flatMap(elements)];
const descendants = (node, tag) => elements(node).filter(item => item.tag === tag);
const text = node => typeof node === 'string' ? node : node.children.map(text).join('');
const attrs = node => Object.fromEntries(node.attrs);
const withClass = (node, name) => elements(node).filter(item => (attrs(item).class ?? '').split(/\s+/).includes(name));
const fields = node => withClass(node, 'field').map(item => {
  const keys = descendants(item, 'dt');
  const values = descendants(item, 'dd');
  assert.equal(keys.length, 1); assert.equal(values.length, 1);
  return [text(keys[0]), text(values[0])];
});
const exactlyField = (node, label, expected) => {
  assert.deepEqual(fields(node).filter(([key]) => key === label).map(([, value]) => value), [expected]);
};

let workspace, document, html, review, draft, expectedEvents;
try {
  run('Exact frozen source and unchanged native replay boundary', () => {
    assert.equal(receipt.head, expectedHead);
    assert.equal(beforePins['src/scope-review-export.mjs'].gitBlob, '6b4ad847283ffb275e99634982dd515f5bc604f5');
    // The producer may add its separate browser driver while these production
    // blobs remain frozen. Bind tracked source and record other work, rather
    // than treating an unrelated untracked receiving helper as source drift.
    const observedWorktree = git('status', '--porcelain');
    assert.equal(git('status', '--porcelain', '--untracked-files=no'), '');
    const manifest = JSON.parse(readFileSync(resolve(source, 'source-pin.json'), 'utf8'));
    assert.equal(manifest.base, expectedBaseline);
    const changed = new Set(['scope.html', 'src/scope-workspace.mjs']);
    const preserved = [];
    for (const file of manifest.files) {
      assert.equal(git('rev-parse', `${receipt.baselineClosure}:${file.path}`), file.sha);
      if (!changed.has(file.path)) {
        assert.equal(gitBlob(readFileSync(resolve(source, file.path))), file.sha);
        preserved.push(file.path);
      }
    }
    assert.deepEqual(git('diff', '--name-only', 'HEAD~2', 'HEAD').split('\n').sort(),
      ['scope.html', 'src/scope-review-export.mjs', 'src/scope-workspace.mjs', 'tests/scope-review-export.test.mjs'].sort());
    return { baselineFilesVerified: manifest.files.length, unchangedNativeAndOtherLeaves: preserved.length, observedWorktree,
      additiveControllerLines: 23, addedHtmlLines: 2, nativeReplayAndLedgerUntouched: true };
  });
  const { createScopeReview, validateScopeDraft } = await import(pathToFileURL(resolve(source, 'src/scope-plan.mjs')));
  const { createScopeReviewDocument, SCOPE_REVIEW_FILENAME } = await import(pathToFileURL(resolve(source, 'src/scope-review-export.mjs')));
  const { encodeScopeWorkspace, decodeScopeWorkspace } = await import(pathToFileURL(resolve(source, 'src/scope-workspace-record.mjs')));

  run('Interleaved eight-checkpoint fixture and independently authored journal', () => {
    const literal = '<plaintext></dd><script src="https://example.invalid/pay">pay()</script>&copy; &#13; <img onerror=pay()> "\' 🧭';
    const amounts = ['00013.07', '21.19', '34.23', '55.29', '89.31', '0.47', '0.53', '0.59'];
    draft = freeze({
      label: '  Estuary field atlas & <print> 🧭  ',
      brief: '  Preserve two routes.\r\nKeep literal markup: ' + literal + '\rLast line.\n  ',
      cap: ' 00257.03 ',
      checkpoints: amounts.map((amount, index) => ({
        title: `  Parcel ${index + 1} <${index === 0 ? 'accepted' : 'survey'}>  `,
        amount, evidence: `  Plan ${index + 1}: map both banks\rline two &amp; ${index === 7 ? literal : '⚓'}  `
      }))
    });
    assert.equal(validateScopeDraft(draft).ok, true);
    review = createScopeReview(draft);
    const accepted = new Map([1, 2, 3, 4, 5].map(index => [index,
      ` \nAccepted parcel ${index} evidence\rnot an actual payment: ${index === 1 ? literal : '&copy;'}  `]));
    const sequence = [
      [3, 'approve'], [1, 'approve'], [5, 'approve'], [4, 'approve'], [2, 'approve'],
      [2, 'order'], [1, 'order'], [4, 'order'], [3, 'order'],
      [2, 'request'], [3, 'request'], [1, 'request'], [1, 'lose'], [2, 'lose'],
      [2, 'receipt'], [1, 'receipt'], [2, 'duplicate'], [1, 'duplicate'], [1, 'reconcile']
    ];
    const cents = [1307, 2119, 3423, 5529, 8931, 47, 53, 59];
    const eventBody = (index, action) => {
      const checkpointId = `scope-${index}`, orderId = `SANDBOX-SCOPE-${index}`, captureId = `CAP-SCOPE-${index}`;
      switch (action) {
        case 'approve': return ['checkpoint.approved', { checkpointId, approver: 'human-reviewer', acceptedEvidence: accepted.get(index).trim() }];
        case 'order': return ['paypal.order.created', { checkpointId, orderId, amount: cents[index - 1], currency: 'USD', environment: 'sandbox' }];
        case 'request': return ['paypal.capture.requested', { checkpointId, orderId, environment: 'sandbox' }];
        case 'lose': return ['paypal.capture.response_lost', { checkpointId, orderId, outcome: 'unknown' }];
        case 'receipt': case 'duplicate': return ['paypal.webhook.received', { checkpointId, eventId: `WH-SCOPE-${index}`, captureId, duplicate: action === 'duplicate', amount: cents[index - 1], currency: 'USD' }];
        case 'reconcile': return ['paypal.capture.reconciled', { checkpointId, captureId, outcome: 'captured', source: 'sandbox-transaction-lookup' }];
        default: assert.fail(action);
      }
    };
    expectedEvents = sequence.map(([index, action], position) => {
      review.act(`scope-${index}`, action, accepted.get(index));
      const [type, body] = eventBody(index, action);
      return { seq: position + 1, type, at: `T+${String(position + 1).padStart(3, '0')}`, ...body };
    });
    const snapshot = review.snapshot();
    assert.deepEqual(snapshot.events, expectedEvents);
    assert.deepEqual(snapshot.checkpoints.map(cp => cp.captureStatus), ['captured', 'unknown', 'pending', 'ready', 'not_started', 'not_started', 'not_started', 'not_started']);
    assert.deepEqual({ cap: snapshot.plan.amount, total: snapshot.total, unallocated: snapshot.unallocated,
      captured: snapshot.captured, remaining: snapshot.remaining, approved: snapshot.approved },
    { cap: 25703, total: 21468, unallocated: 4235, captured: 1307, remaining: 20161, approved: 5 });
    const evidenceDrafts = new Map([
      ['scope-1', 'Ignored stale approved editor\0\ud800'],
      ['scope-6', ''],
      ['scope-7', `\rPending literal ${literal}\nNot approved.\r`]
    ]);
    workspace = { draft, review, evidenceDrafts };
    save('fixture-workspace.json', encodeScopeWorkspace(workspace));
    save('expected-native-history.json', JSON.stringify({ sequence, cents, events: expectedEvents,
      totals: { cap: 25703, allocated: 21468, unallocated: 4235, captured: 1307, remaining: 20161, approved: 5 } }, null, 2) + '\n');
    return { checkpoints: 8, interleavedEvents: 19, approvals: 5, states: snapshot.checkpoints.map(cp => cp.captureStatus),
      countedOnceCents: 1307, unresolvedReceiptCents: 2119, pendingCents: 3423, unallocatedCents: 4235 };
  });

  run('Parsed document has exact native totals, every event and distinct pending/accepted evidence', () => {
    const before = snapshotCaller(workspace);
    html = createScopeReviewDocument(workspace);
    document = parse(html);
    const snapshot = review.snapshot();
    const totalFields = fields(withClass(document, 'totals')[0]);
    assert.deepEqual(totalFields, [
      ['Project cap (USD)', money(25703)], ['Allocated to checkpoints (USD)', money(21468)],
      ['Unallocated cap (USD)', money(4235)], ['Simulated captured (USD)', money(1307)],
      ['Allocated remaining (USD)', money(20161)], ['Recorded approvals', '5 of 8']
    ]);
    exactlyField(document, 'Project name', draft.label.trim());
    exactlyField(document, 'Brief', draft.brief.trim());
    const cards = withClass(document, 'checkpoint');
    assert.equal(cards.length, 8);
    const currentStates = ['captured', 'unknown', 'pending', 'ready', 'not started', 'not started', 'not started', 'not started'];
    const guidance = {
      captured: 'The current fixture ledger counts this checkpoint once. No new capture is needed.',
      unknown: 'The capture response was lost. Do not retry blindly; look up the existing transaction and reconcile once.',
      pending: 'A capture was requested. Its outcome has not been recorded.',
      ready: 'A fixture order exists; no capture has been requested.',
      'not started': 'No capture has been requested for this checkpoint.'
    };
    cards.forEach((card, index) => {
      const cp = snapshot.checkpoints[index];
      assert.equal(text(descendants(card, 'h3')[0]), draft.checkpoints[index].title.trim());
      const pending = index === 5 ? '' : index === 6 ? workspace.evidenceDrafts.get(cp.id) : draft.checkpoints[index].evidence.trim();
      const expected = [
        ['Checkpoint identity', `scope-${index + 1}`], ['Milestone amount (USD)', money([1307, 2119, 3423, 5529, 8931, 47, 53, 59][index])],
        ['Planned acceptance evidence', draft.checkpoints[index].evidence.trim()],
        index < 5 ? ['Accepted evidence — from recorded approval', expectedEvents.find(e => e.type === 'checkpoint.approved' && e.checkpointId === cp.id).acceptedEvidence]
          : ['Pending evidence — not approved', pending],
        ['Current simulated capture state', currentStates[index]], ['Current fixture guidance', guidance[currentStates[index]]]
      ];
      if (index < 4) expected.push(['Fixture order identity', `SANDBOX-SCOPE-${index + 1}`]);
      assert.deepEqual(fields(card), expected);
    });
    const eventNodes = descendants(withClass(document, 'events')[0], 'li');
    assert.equal(eventNodes.length, 19);
    eventNodes.forEach((node, index) => {
      const event = expectedEvents[index];
      assert.equal(text(descendants(node, 'h3')[0]), `Event ${event.seq} · ${event.type}`);
      assert.deepEqual(fields(node), Object.entries(event).map(([key, value]) => [key, String(value)]));
    });
    assert.equal(snapshotCaller(workspace), before);
    assert.equal(createScopeReviewDocument(decodeScopeWorkspace(encodeScopeWorkspace(workspace))), html);
    assert.equal(createScopeReviewDocument(workspace), html);
    save('mixed-state-review.html', html);
    return { exactSummary: Object.fromEntries(totalFields), completeEventsCompared: 19,
      acceptedEvidenceSources: 5, pendingExplicitEmptyPreserved: true, absentPendingUsesPlanned: true,
      approvedStaleInvalidHtmlTextIgnored: true, callerUnchanged: true, deterministicAcrossNativeRoundtrip: true };
  });

  run('HTML tokenization preserves hostile text and limits the document to passive offline structure', () => {
    const allowedTags = new Set(['#document', 'html', 'head', 'meta', 'title', 'style', 'body', 'main', 'header', 'p', 'h1', 'aside', 'strong', 'section', 'h2', 'dl', 'div', 'dt', 'dd', 'article', 'h3', 'ol', 'li', 'footer']);
    const allowedAttrs = new Set(['lang', 'charset', 'name', 'content', 'http-equiv', 'class', 'aria-labelledby', 'id']);
    for (const node of elements(document)) {
      assert.ok(allowedTags.has(node.tag), `Unexpected element ${node.tag}`);
      for (const [key] of node.attrs) assert.ok(allowedAttrs.has(key), `Unexpected active/resource attribute ${key}`);
    }
    const metas = descendants(document, 'meta');
    const csp = metas.find(node => attrs(node)['http-equiv'] === 'Content-Security-Policy');
    assert.equal(attrs(csp).content, "default-src 'none'; style-src 'unsafe-inline'; base-uri 'none'; form-action 'none'");
    const stylesheet = text(descendants(document, 'style')[0]);
    assert.ok(stylesheet.includes('@media print'));
    assert.ok(!/url\s*\(|@import/i.test(stylesheet));
    const allText = text(document);
    assert.ok(allText.includes('<plaintext></dd><script src="https://example.invalid/pay">pay()</script>&copy; &#13; <img onerror=pay()>'));
    assert.ok(allText.includes('Fictional snapshot · no live payments'));
    assert.ok(allText.includes('All recorded approvals, orders and captures are simulated.'));
    assert.ok(allText.includes('Pending and unknown outcomes count nothing.'));
    assert.ok(!allText.includes('Ignored stale approved editor'));
    assert.equal(SCOPE_REVIEW_FILENAME, 'scopesignal-scope-review.html');
    return { elements: elements(document).length, allElementsAndAttributesPassive: true,
      literalMarkupAndCharacterReferenceTextExact: true, internalCRAndCRLFExactInParsedFields: true,
      staticCsp: attrs(csp).content, printStylesPresent: true };
  });

  run('A native rejected approval and an unfinished invalid draft stay distinct and preserve caller state', () => {
    const before = snapshotCaller(workspace);
    assert.throws(() => review.act('scope-6', 'approve', '\r\n \t'), /Acceptance evidence/);
    assert.equal(snapshotCaller(workspace), before);
    assert.equal(createScopeReviewDocument(workspace), html);
    const unfinished = freeze({ label: '', brief: '\rUnfinished <form action="/pay"> &amp;\r\n', cap: '+257,', checkpoints: [
      { title: '', amount: ' \r00.\t', evidence: '  \rPending only <script>\n' },
      { title: '\tMissing amount <input> ', amount: '', evidence: '' }
    ] });
    assert.equal(validateScopeDraft(unfinished).ok, false);
    assert.throws(() => createScopeReview(unfinished));
    const beforeDraft = JSON.stringify(unfinished);
    const rawHtml = createScopeReviewDocument({ draft: unfinished });
    const rawDoc = parse(rawHtml);
    exactlyField(rawDoc, 'Project name', '');
    exactlyField(rawDoc, 'Brief', unfinished.brief);
    exactlyField(rawDoc, 'Project cap in USD (as entered, not validated)', unfinished.cap);
    const rawCards = withClass(rawDoc, 'checkpoint');
    assert.equal(rawCards.length, 2);
    rawCards.forEach((card, index) => assert.deepEqual(fields(card), [
      ['Deliverable (as entered)', unfinished.checkpoints[index].title],
      ['Amount in USD (as entered, not validated)', unfinished.checkpoints[index].amount],
      ['Planned acceptance evidence', unfinished.checkpoints[index].evidence]
    ]));
    assert.equal(withClass(rawDoc, 'totals').length, 0);
    assert.equal(withClass(rawDoc, 'events').length, 0);
    assert.ok(text(rawDoc).includes('Unfinished fictional draft'));
    assert.ok(text(rawDoc).includes('No fixture events have been recorded.'));
    assert.equal(JSON.stringify(unfinished), beforeDraft);
    assert.equal(snapshotCaller(workspace), before);
    save('unfinished-review.html', rawHtml);
    return { invalidDraftAdmittedOnlyAsRawDraft: true, rawEmptyWhitespaceMoneyAndMarkupExact: true,
      fabricatedTotalsOrApprovals: false, realRejectedApprovalUnchanged: true, priorReviewUnchanged: true };
  });

  run('Tampered journal identity, duplicate truth and source terms fail without altering the active workspace', () => {
    const before = snapshotCaller(workspace);
    const cases = [
      ['fixture sequence', snapshot => { snapshot.events[18].seq = 1; }],
      ['fixture timestamp', snapshot => { snapshot.events[18].at = '2026-10-08T00:00:00Z'; }],
      ['unresolved receipt duplicate truth', snapshot => { snapshot.events[16].duplicate = false; }],
      ['cross-checkpoint order binding', snapshot => { snapshot.events[5].orderId = 'SANDBOX-SCOPE-1'; }],
      ['accepted event differs from checkpoint', snapshot => { snapshot.events[0].acceptedEvidence += ' forged'; }]
    ];
    const refusals = [];
    for (const [name, mutate] of cases) {
      const forged = review.snapshot(); mutate(forged); freeze(forged);
      const forgedBefore = JSON.stringify(forged);
      assert.throws(() => createScopeReviewDocument({ draft, review: { snapshot: () => forged }, evidenceDrafts: workspace.evidenceDrafts }),
        error => { refusals.push({ name, error: error.message }); return true; });
      assert.equal(JSON.stringify(forged), forgedBefore);
      assert.equal(snapshotCaller(workspace), before);
    }
    const wrongTerms = structuredClone(draft);
    wrongTerms.checkpoints[1].evidence += ' changed after approval';
    const wrongBefore = JSON.stringify(wrongTerms);
    assert.throws(() => createScopeReviewDocument({ ...workspace, draft: wrongTerms }),
      error => { refusals.push({ name: 'changed planned acceptance terms', error: error.message }); return true; });
    assert.equal(JSON.stringify(wrongTerms), wrongBefore);
    const unknownPending = new Map(workspace.evidenceDrafts);
    unknownPending.set('scope-999', 'Unowned checkpoint');
    const pendingBefore = JSON.stringify([...unknownPending]);
    assert.throws(() => createScopeReviewDocument({ ...workspace, evidenceDrafts: unknownPending }),
      error => { refusals.push({ name: 'unknown pending checkpoint', error: error.message }); return true; });
    assert.equal(JSON.stringify([...unknownPending]), pendingBefore);
    assert.equal(snapshotCaller(workspace), before);
    assert.equal(createScopeReviewDocument(workspace), html);
    return { refusals, activeStateAndInputsUnchanged: true, subsequentValidOutputExact: true };
  });
  receipt.status = 'ACCEPT';
} catch (error) {
  receipt.status = 'BLOCKER'; receipt.error = error.stack; process.exitCode = 1;
} finally {
  receipt.sourcePinsAfter = pins();
  receipt.headAfter = git('rev-parse', 'HEAD');
  receipt.sourceUnchanged = JSON.stringify(receipt.sourcePinsAfter) === JSON.stringify(beforePins) && receipt.headAfter === receipt.head;
  if (!receipt.sourceUnchanged) { receipt.status = 'BLOCKER'; process.exitCode = 1; }
  receipt.finishedAt = new Date().toISOString();
  receipt.driver = { path: 'independent_scope_review.mjs', sha256: sha256(readFileSync(fileURLToPath(import.meta.url))) };
  receipt.parser = { path: 'parse_html.py', sha256: sha256(readFileSync(resolve(here, 'parse_html.py'))) };
  writeFileSync(resolve(out, 'independent-scope-review-receipt.json'), JSON.stringify(receipt, null, 2) + '\n');
  process.stdout.write(JSON.stringify({ status: receipt.status, groups: receipt.groups.map(({ name, status, error }) => ({ name, status, error })),
    sourceUnchanged: receipt.sourceUnchanged, receipt: resolve(out, 'independent-scope-review-receipt.json') }, null, 2) + '\n');
}
