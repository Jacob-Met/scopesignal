# ScopeSignal authored-scope export — independent receiving ACCEPT

Accepted the frozen source candidate `e60084d731d441e00efdda680f288fb3e711803a`, tree `2d554ffe7fbc98700d59c88cfb1c6f3705f39860`, over native `paypal-ai` baseline `8a241c9ce409fa9b22ab0bbdc339e46fd4b38525`. This is independent source and native receiving of the printable authored-scope export. Production separately owns actual browser download, offline-file presentation and print execution.

## Reviewed source boundary

| Path | Reviewed Git blob |
| --- | --- |
| `src/scope-review-export.mjs` | `6b4ad847283ffb275e99634982dd515f5bc604f5` |
| `src/scope-workspace.mjs` | `9877f98ae1a5f0853afe9d1bd6d84f9f84548562` |
| `scope.html` | `162c570f09e9e0d02d066fc44e36e8fdcd04d85c` |
| `src/scope-workspace-record.mjs` | `49905d00ede9a2b22a3fbdef12d09a2374f47716` |
| `src/scope-plan.mjs` | `b36d91a6bbdd3d8cd7e15dcc0550a549ac7135c8` |
| `src/ledger.mjs` | `beb94176ae3b1a2f29890c5752e47c25694f01f0` |
| `src/payment-status.mjs` | `2c5ba31e85e41b1f62dbf1612582574ce677237e` |

Read the complete exporter, private workspace replay, plan, ledger and presentation modules, plus the full controller/HTML diff and surrounding native input/evidence/save paths. Export admission roundtrips the existing bounded workspace format and private fixture replay. The controller adds one import and a separate synchronous download handler, without changing open, edit, approval or payment actions. HTML adds one button and one explanatory paragraph. All 44 materialized baseline blobs matched their source manifest; 42 existing leaves remain byte-identical. Nine reviewed source/test/manifest pins were verified before and after receiving execution.

## Independent fixture and result

All six native receiving groups passed on Node v24.19.0, from `2026-10-08T12:44:45.757Z` through `2026-10-08T12:44:46.148Z`.

The fixture authors eight checkpoints and interleaves 19 real native actions across them. It includes a lost capture response later reconciled, a different lost response with original and duplicate webhook receipts that remains unknown, a pending request, an order awaiting capture, an approved checkpoint without an order, an explicit empty pending evidence draft, an edited pending evidence draft and an unedited planned-evidence fallback. Five approvals are recorded. Expected event fields and integer-cent totals are constructed independently of the exporter and compared with the native ledger before examining output.

| Meaning | Exact rendered expectation |
| --- | --- |
| Project cap | $257.03 |
| Allocated checkpoints | $214.68 |
| Unallocated cap | $42.35 |
| Simulated captured, counted once | $13.07 |
| Allocated remaining | $201.61 |
| Recorded approvals | 5 of 8 |

The unresolved $21.19 webhook/duplicate pair and pending $34.23 capture request contribute zero to captured totals. The printout retains the historical lost-response events while reporting the current reconciled checkpoint as captured. Every field of every one of the 19 events matches its independent expected record.

An independent Python standard-library HTML tokenizer checked 706 emitted elements and all decoded field text. It found only passive document structure, the declared restrictive CSP and static print styling. Literal closing tags, script/resource-looking text, named and numeric character-reference text, supplementary Unicode, carriage returns and CRLF remain exact text. Empty pending evidence remains empty; absent pending evidence uses the planned text; recorded approval evidence wins over a stale approved editor value, even when that ignored editor value contains text HTML cannot represent.

A real native rejected blank approval changes neither state nor subsequent output. A separate unfinished draft with invalid money, empty fields and hostile literal text exports exact raw fields without totals or implied approvals. Seven refusals exercise altered event sequence, fixture timestamp, duplicate marker, cross-checkpoint order identity, accepted-event/checkpoint inconsistency, changed planned terms and an unknown pending checkpoint. Each refusal preserves the supplied objects and the active valid workspace. Repeated exports and a native JSON roundtrip produce identical HTML.

## Evidence and reproduction

Run `node independent_scope_review.mjs SOURCE_DIRECTORY OUTPUT_DIRECTORY` from this packet. The driver requires the exact frozen candidate and reads its actual modules; `parse_html.py` uses only Python's standard library. No installation, browser, network, live provider or actual private/customer artifact is involved.

| Evidence | SHA-256 |
| --- | --- |
| `independent_scope_review.mjs` | `b7319c695d250723c9ec847342daebeb8ba97e916abd157a36776bfe6db566f0` |
| `parse_html.py` | `1ec4045b6de6892779180e6f5272d74131c07ed86dce18559af806eec94d6462` |
| `independent-scope-review-receipt.json` | `88dc688012900b81ae8523212d218b08ed9a073cd22069b0335d384ae83eaba5` |
| `fixture-workspace.json` | `31f4534bb42a6f1d1d19901c75475a4af4ce967af907853ae850b9d6a568982f` |
| `expected-native-history.json` | `cdda30afe646874cd3085a508094e40fa524f268eb33ffa0dadf4d5fc20542d3` |
| `mixed-state-review.html` | `4c9d6b387e2fb710ed553230319055f604fccd5cacca0b6679f1f52d00f2b6ac` |
| `unfinished-review.html` | `bf32c53b6c524d5d8ddf1d5c86c0cb0961ddc0146596d23430e961942ac1e14b` |

The initial `harness-untracked-browser-driver-receipt.json` records a **review-harness precondition failure**, not a product defect. The producer had added its independent untracked `scripts/check-scope-review-export.mjs` while the production blobs remained frozen. The first guard incorrectly required no untracked work anywhere. The corrected guard verifies clean tracked source, all exact source hashes and records the untracked work. That initial receipt is preserved unchanged (SHA-256 `cfa80c4f2396b0fe45042a0980502e1e7d5b3294756e0a50eb11d2b503ee2b93`). No product code was edited to obtain acceptance.

## Limits and integration

This source/native acceptance does not claim browser layout or print execution, a real approval, a payment, target integration or deployment. The existing workspace codec/controller ownership in issue #18 remains unchanged. A later owner correction must be composed normally and assessed against these exact source pins. No broad product suite was rerun by this reviewer.
