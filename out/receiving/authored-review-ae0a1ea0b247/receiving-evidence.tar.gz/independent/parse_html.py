"""Native receiving parser: inspect emitted HTML structure and decoded text.

Uses Python's independent standard-library tokenizer, with no browser/network or
product code. This is source/native review; the producer owns actual browser and
print execution. Decode stdin bytes directly to avoid text-mode CR conversion.
"""
import json
import sys
from html.parser import HTMLParser


class Document(HTMLParser):
    VOID = {"area", "base", "br", "col", "embed", "hr", "img", "input", "link", "meta", "param", "source", "track", "wbr"}

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.root = {"tag": "#document", "attrs": [], "children": []}
        self.stack = [self.root]
        self.declarations = []
        self.comments = []
        self.errors = []

    def handle_starttag(self, tag, attrs):
        node = {"tag": tag, "attrs": attrs, "children": []}
        self.stack[-1]["children"].append(node)
        if tag not in self.VOID:
            self.stack.append(node)

    def handle_startendtag(self, tag, attrs):
        self.handle_starttag(tag, attrs)
        if tag not in self.VOID:
            self.handle_endtag(tag)

    def handle_endtag(self, tag):
        if len(self.stack) < 2 or self.stack[-1]["tag"] != tag:
            self.errors.append("Unmatched closing tag: " + tag)
        else:
            self.stack.pop()

    def handle_data(self, data):
        self.stack[-1]["children"].append(data)

    def handle_decl(self, decl):
        self.declarations.append(decl)

    def handle_comment(self, data):
        self.comments.append(data)


parser = Document()
parser.feed(sys.stdin.buffer.read().decode("utf-8"))
parser.close()
if len(parser.stack) != 1:
    parser.errors.append("Unclosed elements")
json.dump({"root": parser.root, "declarations": parser.declarations,
           "comments": parser.comments, "errors": parser.errors}, sys.stdout,
          ensure_ascii=True, separators=(",", ":"))
