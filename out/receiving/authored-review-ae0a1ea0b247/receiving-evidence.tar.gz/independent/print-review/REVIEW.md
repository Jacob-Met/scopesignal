# Exact-PDF print inspection

Inspected every page of the producer's existing 10-page Chromium PDF at 125 dpi using the PDF skill and Poppler. No browser, new export, product mutation or native suite rerun was performed.

PDF SHA-256: `23d49b1eb683601e7e187381479caf496efdd9fd88030569a238d96d76c29fbb` (53,381 bytes). It came from source `e60084d731d441e00efdda680f288fb3e711803a`, exporter blob `6b4ad847283ffb275e99634982dd515f5bc604f5`, and the actual downloaded HTML with SHA-256 `a4ee6c44dc957c9d29cd6f31dcbefe2fdc3a56d614dd9f6ec6b8cec70c7f7ba9`.

## Result

The main summary and all three checkpoint cards print clearly. No page has clipped, overlapping or horizontally overflowing text. Each checkpoint's monetary amount, acceptance/pending evidence and current status remain together. The summary correctly distinguishes cap, allocation, unallocated cap, captured amount and remaining allocation. Native source acceptance is unchanged.

An unqualified claim that this PDF faithfully prints every authored character is not supported: **the compass character U+1F9ED becomes a missing-glyph box in the brief on page 1 and pending evidence on page 4**. The authored JSON and exported HTML retain the character. The PDF embeds only DejaVu Sans/Bold fonts, and extracting those printed lines yields NUL in place of the compass. This is a concrete loss in the produced PDF, not HTML corruption; behavior in other browser/font environments is not established by this sample.

Two additional print-consumer observations were sent to production:

- The history displays raw native `amount` values `50025` and `40000` with `currency` `USD`, without explaining that these amounts are integer cents. A short explicit unit note would preserve the raw fields and make the history understandable alongside the $500.25/$400.00 checkpoint values.
- Event cards continue across pages. In the clearest awkward case, Event 6's `amount 50025` is at the bottom of page 7 while page 8 begins with only `currency USD`. The continuous card borders make the continuation recognizable, but keeping ordinary event cards together would avoid this separation. The checkpoint cards themselves remain intact.

## Preserved evidence

`print-review-receipt.json` records exact source/PDF/HTML identities, font details, extracted glyph-loss lines, all ten page-inspection notes and all ten raster hashes. Its SHA-256 is `dc56c3d1d426e4f13642d90b5a3e098935b1ea864e332c560e76264f361fc4b9`.

Only three representative page renders are retained: page 1 shows the otherwise clean summary and missing glyph; pages 7 and 8 show the raw cent fields and event continuation. The other seven temporary renders were removed only after inspection. The original PDF and source were not changed.
