const fs=require("node:fs/promises"),path=require("node:path"),os=require("node:os"),crypto=require("node:crypto"),http=require("node:http"),{spawn}=require("node:child_process"),readline=require("node:readline"),assert=require("node:assert/strict");
const sha=b=>crypto.createHash("sha256").update(b).digest("hex");
const blob=b=>crypto.createHash("sha1").update("blob "+b.length+"\0").update(b).digest("hex");
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
async function main(packet){
 if(os.hostname()!=="hamon-thinkpad")throw Error("Wrong native host");
 const root=await fs.mkdtemp(path.join(os.homedir(),"scopesignal-receiving-ac386303dce2-"));await fs.chmod(root,0o700);
 const source=path.join(root,"source"),output=path.join(root,"evidence");await fs.mkdir(source);await fs.mkdir(output);
 const write=async(name,data)=>{const dest=path.join(output,name);await fs.writeFile(dest,data,{flag:"wx"});return {path:dest,bytes:Buffer.byteLength(data),sha256:sha(data)};};
 const sourcePins={};
 for(const[name,item]of Object.entries(packet.source.files)){
  assert(!path.isAbsolute(name)&&!name.split("/").includes(".."));
  const b=Buffer.from(item.text);assert.equal(blob(b),item.git_blob,name);
  const p=path.join(source,name);await fs.mkdir(path.dirname(p),{recursive:true});await fs.writeFile(p,b,{flag:"wx"});
  sourcePins[name]={bytes:b.length,sha256:sha(b),git_blob:item.git_blob};
 }
 const driverPin=await write("reproduce.cjs",packet.driver);
 const report={schema:"scopesignal.removed-checkpoint-cdp-receiving/1",head:packet.source.head,tree:packet.source.tree,root,driver:driverPin,host:os.hostname(),node:process.version,started:new Date().toISOString(),sourceBefore:sourcePins,cases:[],screenshots:[],downloads:[],requests:[],serverRequests:[],blockedExternal:[],pageErrors:[],sourceUnchanged:false,browserClosed:false,profileRemoved:false,limits:["Unmodified exact source capsule and fictional local drafts only.","Normal installed Chromium snap via standard CDP; fresh user-owned visible-home profile.","Keyboard activation and native browser downloads; no provider, account or existing profile.","Missing recovery is a user workflow gap, not a claim that Remove violates its present documented action.","Narrow viewport is not a physical phone. The earlier Playwright driver-startup failure is separate and remains preserved."]};
 const server=http.createServer(async(req,res)=>{try{
  const n=decodeURIComponent(new URL(req.url,"http://127.0.0.1").pathname).replace(/^\/+/,"");report.serverRequests.push(n);
  const item=packet.source.files[n];if(!item){res.writeHead(404);res.end("Not found");return;}
  res.writeHead(200,{"Content-Type":(n.endsWith(".html")?"text/html":n.endsWith(".css")?"text/css":"application/javascript")+"; charset=utf-8","Cache-Control":"no-store"});res.end(item.text);
 }catch(e){res.writeHead(500);res.end("Fixture server error");}});
 await new Promise(r=>server.listen(0,"127.0.0.1",r));
 const origin="http://127.0.0.1:"+server.address().port;report.origin=origin;
 class Browser{
  constructor(){this.seq=0;this.pending=new Map();this.downloads=new Map();this.asyncErrors=[];this.log="";this.closing=false;}
  async waitFor(fn,label,ms=10000){const end=Date.now()+ms;let last;while(Date.now()<end){if(this.asyncErrors.length)throw Error(this.asyncErrors.join("\n"));try{if(await fn())return;}catch(e){last=e;}await sleep(100);}throw Error("Timed out "+label+(last?": "+last.message:""));}
  command(method,params={},session=this.session){return new Promise((resolve,reject)=>{
   const id=++this.seq,timer=setTimeout(()=>{this.pending.delete(id);reject(Error("CDP timeout "+method));},15000);
   this.pending.set(id,{resolve,reject,timer});this.socket.send(JSON.stringify({id,method,params,...(session?{sessionId:session}:{})}));
  });}
  async evaluate(expression){const r=await this.command("Runtime.evaluate",{expression,awaitPromise:true,returnByValue:true});if(r.exceptionDetails)throw Error(r.exceptionDetails.exception?.description||r.exceptionDetails.text);return r.result.value;}
  async key(name){const code={Enter:13,Backspace:8,Tab:9}[name];for(const type of ["keyDown","keyUp"])await this.command("Input.dispatchKeyEvent",{type,key:name,code:name,windowsVirtualKeyCode:code,nativeVirtualKeyCode:code,...(name==="Enter"&&type==="keyDown"?{text:"\r",unmodifiedText:"\r"}:{})});}
  async activate(selector){assert(await this.evaluate("!!document.querySelector("+JSON.stringify(selector)+")"),"Missing "+selector);await this.evaluate("document.querySelector("+JSON.stringify(selector)+").focus()");await this.key("Enter");}
  async fill(selector,value){await this.evaluate("(()=>{const e=document.querySelector("+JSON.stringify(selector)+");e.focus();e.select();})()");await this.key("Backspace");if(value)await this.command("Input.insertText",{text:value});}
  async snapshot(){return this.evaluate("({label:document.querySelector('#scope-label').value,brief:document.querySelector('#scope-brief').value,cap:document.querySelector('#scope-cap').value,checkpoints:[...document.querySelectorAll('.scope-row')].map(row=>Object.fromEntries(['title','amount','evidence'].map(key=>[key,row.querySelector('[data-field=\"'+key+'\"]').value])))})");}
  async launch(){
   this.profile=await fs.mkdtemp(path.join(root,"profile-"));report.profile=this.profile;
   this.child=spawn("/usr/bin/chromium-browser",["--headless=new","--disable-gpu","--disable-background-networking","--disable-component-update","--disable-sync","--no-first-run","--no-default-browser-check","--disable-dev-shm-usage","--remote-debugging-address=127.0.0.1","--remote-debugging-port=0","--user-data-dir="+this.profile,"about:blank"],{stdio:["ignore","ignore","pipe"]});
   this.child.stderr.on("data",b=>{this.log=(this.log+b.toString()).slice(-32000);});let launchError;this.child.on("error",e=>{launchError=e;});
   let port,endpoint;await this.waitFor(async()=>{if(launchError)throw launchError;if(this.child.exitCode!==null)throw Error("Owned Chromium exited "+this.child.exitCode+": "+this.log);[port,endpoint]=(await fs.readFile(path.join(this.profile,"DevToolsActivePort"),"utf8")).trim().split("\n");return port&&endpoint;},"Chromium startup",20000);
   this.socket=new WebSocket("ws://127.0.0.1:"+port+endpoint);
   this.socket.addEventListener("message",event=>{const m=JSON.parse(event.data);
    if(m.id){const p=this.pending.get(m.id);if(!p)return;clearTimeout(p.timer);this.pending.delete(m.id);m.error?p.reject(Error(m.error.message)):p.resolve(m.result);}
    else if(m.method==="Runtime.exceptionThrown")report.pageErrors.push(m.params.exceptionDetails.exception?.description||m.params.exceptionDetails.text);
    else if(m.method==="Network.requestWillBeSent")report.requests.push({url:m.params.request.url,type:m.params.type,sessionId:m.sessionId});
    else if(m.method==="Fetch.requestPaused"){const url=m.params.request.url,allow=url.startsWith(origin+"/")||url.startsWith("blob:")||url.startsWith("data:");if(!allow)report.blockedExternal.push(url);this.command(allow?"Fetch.continueRequest":"Fetch.failRequest",{requestId:m.params.requestId,...(!allow?{errorReason:"BlockedByClient"}:{})},m.sessionId).catch(e=>this.asyncErrors.push(e.message));}
    else if(m.method==="Browser.downloadWillBegin")this.downloads.set(m.params.guid,{...m.params,state:"started"});
    else if(m.method==="Browser.downloadProgress"){const d=this.downloads.get(m.params.guid);if(d)Object.assign(d,m.params);}
   });
   this.socket.addEventListener("close",()=>{for(const p of this.pending.values()){clearTimeout(p.timer);p.reject(Error("CDP closed"));}this.pending.clear();});
   await new Promise((r,j)=>{this.socket.addEventListener("open",r,{once:true});this.socket.addEventListener("error",j,{once:true});});
   report.chromium=await this.command("Browser.getVersion",{},null);
   await this.command("Browser.setDownloadBehavior",{behavior:"allowAndName",downloadPath:output,eventsEnabled:true},null);
  }
  async newPage(phone){
   this.targetId=(await this.command("Target.createTarget",{url:"about:blank"},null)).targetId;
   this.session=(await this.command("Target.attachToTarget",{targetId:this.targetId,flatten:true},null)).sessionId;
   for(const method of ["Page.enable","Runtime.enable","Network.enable"])await this.command(method);
   await this.command("Fetch.enable",{patterns:[{urlPattern:"*"}]});
   await this.command("Emulation.setDeviceMetricsOverride",{width:phone?390:1280,height:phone?844:900,deviceScaleFactor:1,mobile:false});
   await this.command("Page.navigate",{url:origin+"/scope.html"});
   await this.waitFor(()=>this.evaluate("document.readyState==='complete'&&document.querySelectorAll('.scope-row').length===3"),"exact ScopeSignal fixture",10000);
  }
  async save(name){
   const old=new Set(this.downloads.keys());await this.activate("#scope-save");let d;
   await this.waitFor(()=>{d=[...this.downloads.values()].find(x=>!old.has(x.guid));return d&&d.state==="completed";},"native workspace download",10000);
   assert.equal(d.suggestedFilename,"scopesignal-workspace-v1.json");
   const p=path.join(output,d.guid),bytes=await fs.readFile(p);const dest=path.join(output,name+".json");await fs.rename(p,dest);
   const saved={path:dest,bytes:bytes.length,sha256:sha(bytes),suggestedFilename:d.suggestedFilename,record:JSON.parse(bytes.toString("utf8"))};report.downloads.push({...d,path:dest,sha256:saved.sha256});return saved;
  }
  async close(){
   if(this.socket?.readyState===WebSocket.OPEN){this.closing=true;try{await this.command("Browser.close",{},null);}catch(e){report.closeCommandError=e.message;}}
   if(this.child){const exited=()=>this.child.exitCode!==null||this.child.signalCode!==null;for(let i=0;i<30&&!exited();i++)await sleep(100);if(!exited()){report.cleanupSignal="SIGTERM";this.child.kill("SIGTERM");for(let i=0;i<30&&!exited();i++)await sleep(100);}report.browserClosed=exited();report.browserExitCode=this.child.exitCode;report.browserSignal=this.child.signalCode;}
   this.socket?.close();for(const p of this.pending.values()){clearTimeout(p.timer);p.reject(Error("Receiver ended"));}this.pending.clear();
   if(report.browserClosed&&this.profile){await fs.rm(this.profile,{recursive:true,maxRetries:3,retryDelay:100});report.profileRemoved=true;}
   await write("chromium.log",this.log);
  }
 }
 const browser=new Browser();
 try{
  await browser.launch();
  for(const[label,phone,removed]of [
   ["complete-desktop",false,{title:"Lettering <fictional>",amount:"007.50",evidence:"Keep the full authored evidence.\n\nZoë — خدمة & <literal>"}],
   ["unfinished-phone",true,{title:"",amount:"12..30",evidence:"  unfinished acceptance\n\nfinal line  "}]
  ]){
   await browser.newPage(phone);
   for(const[k,v]of Object.entries({label:"Orchid release · authored fixture",brief:"A private fictional editing exercise.\nKeep the remaining fields.",cap:" 2000.00 "}))await browser.fill("#scope-"+k,v);
   for(const[k,v]of Object.entries(removed))await browser.fill("#draft-1-"+k,v);
   const before=await browser.snapshot();assert.deepEqual(before.checkpoints[1],removed,"Native inputs retain the exact authored removed row");
   const savedBefore=await browser.save(label+"-before");assert.deepEqual(savedBefore.record.draft,before,"native before-download");
   await browser.activate('button[data-remove="1"]');
   const after=await browser.snapshot(),expected={...before,checkpoints:[before.checkpoints[0],before.checkpoints[2]]};
   assert.deepEqual(after,expected,"ordinary Remove preserves every other raw field");
   const savedAfter=await browser.save(label+"-after");assert.deepEqual(savedAfter.record.draft,after,"native after-download");
   const selector=await browser.evaluate("(()=>{const e=[...document.querySelectorAll('button')].find(e=>(e.getAttribute('aria-label')||e.textContent.trim())==='Undo last checkpoint removal');return e&&!e.disabled&&!e.hidden&&e.id?'#'+e.id:null;})()");
   const row={name:label,before,after_remove:after,ordinary_removal_exact:true,before_download:savedBefore,after_download:savedAfter,undo_available:!!selector,recovered_exactly:false,visible_buttons:await browser.evaluate("[...document.querySelectorAll('button')].filter(e=>e.checkVisibility()).map(e=>({text:e.textContent.trim(),label:e.getAttribute('aria-label'),disabled:e.disabled}))")};
   if(selector){await browser.activate(selector);row.after_undo=await browser.snapshot();row.recovered_exactly=JSON.stringify(row.after_undo)===JSON.stringify(before);assert(row.recovered_exactly,"Undo restores exact complete raw draft");row.restored_download=await browser.save(label+"-restored");assert.deepEqual(row.restored_download.record.draft,before);}
   else row.recovery_failure="No Undo last checkpoint removal control exists; the removed raw row is absent from both the active draft and the new native workspace download.";
   try{await browser.evaluate("document.querySelector('#scope-add').scrollIntoView({block:'center',behavior:'instant'})");const {data}=await browser.command("Page.captureScreenshot",{format:"png",captureBeyondViewport:false});report.screenshots.push(await write(label+".png",Buffer.from(data,"base64")));}catch(e){row.screenshot_error=e.message;}
   while(await browser.evaluate("document.querySelectorAll('.scope-row').length>1"))await browser.activate('button[data-remove="0"]');
   row.last_row_removal_disabled=await browser.evaluate("document.querySelector('button[data-remove=\"0\"]').disabled");assert(row.last_row_removal_disabled);
   report.cases.push(row);await browser.command("Target.closeTarget",{targetId:browser.targetId},null);browser.session=null;
  }
 }catch(e){report.error=e.message;report.stack=e.stack;}
 finally{
  await browser.close();await new Promise(r=>server.close(r));
  report.sourceUnchanged=true;for(const[n,p]of Object.entries(sourcePins))if(sha(await fs.readFile(path.join(source,n)))!==p.sha256)report.sourceUnchanged=false;
  report.finished=new Date().toISOString();
  report.result=report.error?"RECEIVING_ERROR":report.cases.length===2&&report.cases.every(c=>c.recovered_exactly)?"PASS":"MISSING_WORKFLOW";
  const bytes=Buffer.from(JSON.stringify(report,null,2)+"\n");const receipt=await write("result.json",bytes);
  console.log(JSON.stringify({root,result:report.result,head:report.head,tree:report.tree,driver:driverPin,receipt,chromium:report.chromium,cases:report.cases.map(c=>({name:c.name,ordinary_removal_exact:c.ordinary_removal_exact,undo_available:c.undo_available,recovered_exactly:c.recovered_exactly,last_row_removal_disabled:c.last_row_removal_disabled})),error:report.error,sourceUnchanged:report.sourceUnchanged,browserClosed:report.browserClosed,profileRemoved:report.profileRemoved,browserExitCode:report.browserExitCode,browserSignal:report.browserSignal,pageErrors:report.pageErrors,blockedExternal:report.blockedExternal}));
  process.exitCode=report.result==="PASS"?0:1;
 }
}
console.log("READY ScopeSignal exact-source CDP receiver");
const rl=readline.createInterface({input:process.stdin,terminal:false});rl.once("line",line=>{rl.close();main(JSON.parse(line)).catch(e=>{console.error(e.stack);process.exitCode=1;});});