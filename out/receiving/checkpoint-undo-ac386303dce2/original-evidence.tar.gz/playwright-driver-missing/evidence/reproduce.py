import sys,json,hashlib,tempfile,pathlib,threading,http.server,urllib.parse,traceback,shutil,time,os,importlib.metadata
from playwright.sync_api import sync_playwright
print("READY ScopeSignal unchanged-source recovery receiver",flush=True)
packet=json.loads(sys.stdin.readline())
root=pathlib.Path(tempfile.mkdtemp(prefix="scopesignal-remove-recovery-ac386303dce2-",dir="/tmp"))
source=root/"source";source.mkdir()
output=root/"evidence";output.mkdir()
def digest(data):return hashlib.sha256(data).hexdigest()
def write(name,data):
 p=output/name;p.parent.mkdir(parents=True,exist_ok=True)
 with p.open("xb") as f:f.write(data)
 return {"path":str(p),"bytes":len(data),"sha256":digest(data)}
source_pins={}
for name,item in packet["source"]["files"].items():
 p=source/name
 assert not pathlib.PurePosixPath(name).is_absolute() and ".." not in pathlib.PurePosixPath(name).parts
 p.parent.mkdir(parents=True,exist_ok=True);data=item["text"].encode()
 assert hashlib.sha1(("blob "+str(len(data))+"\0").encode()+data).hexdigest()==item["git_blob"],name
 with p.open("xb") as f:f.write(data)
 source_pins[name]={"bytes":len(data),"sha256":digest(data),"git_blob":item["git_blob"]}
driver=write("reproduce.py",packet["driver"].encode())
report={"schema":"scopesignal.removed-checkpoint-receiving/1","head":packet["source"]["head"],"tree":packet["source"]["tree"],"root":str(root),"driver":driver,"python":sys.version,"playwright":importlib.metadata.version("playwright"),"started":time.time(),"sourceBefore":source_pins,"cases":[],"screenshots":[],"requests":[],"blockedExternal":[],"pageErrors":[],"sourceUnchanged":False,"browserClosed":False,"profileRemoved":False,"limits":["Unmodified source capsule and fictional local drafts only.","Real isolated Chromium controls and native downloads; no provider, account or installed-profile action.","The missing recovery assertion is an absent workflow, not a claimed violation of the existing Remove action.","Phone is a narrow viewport, not a physical device."]}
class Handler(http.server.BaseHTTPRequestHandler):
 def log_message(self,*args):pass
 def do_GET(self):
  name=urllib.parse.unquote(urllib.parse.urlsplit(self.path).path).lstrip("/")
  report["requests"].append(name)
  item=packet["source"]["files"].get(name)
  if item is None:self.send_response(404);self.end_headers();return
  data=item["text"].encode()
  mime="text/html" if name.endswith(".html") else "text/css" if name.endswith(".css") else "application/javascript"
  self.send_response(200);self.send_header("Content-Type",mime+"; charset=utf-8");self.send_header("Cache-Control","no-store");self.end_headers();self.wfile.write(data)
server=http.server.ThreadingHTTPServer(("127.0.0.1",0),Handler)
thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
origin="http://127.0.0.1:"+str(server.server_port);report["origin"]=origin
state_js="""()=>({label:document.querySelector('#scope-label').value,brief:document.querySelector('#scope-brief').value,cap:document.querySelector('#scope-cap').value,checkpoints:[...document.querySelectorAll('.scope-row')].map(row=>Object.fromEntries(['title','amount','evidence'].map(key=>[key,row.querySelector('[data-field="'+key+'"]').value])))})"""
profile=root/"profile"
def snapshot(page):return page.evaluate(state_js)
def saved(page,name):
 with page.expect_download(timeout=7000) as pending:page.locator("#scope-save").click()
 d=pending.value;assert d.suggested_filename=="scopesignal-workspace-v1.json"
 p=output/(name+".json");d.save_as(str(p));assert d.failure() is None
 data=p.read_bytes()
 return {"path":str(p),"bytes":len(data),"sha256":digest(data),"record":json.loads(data)}
context=None
try:
 with sync_playwright() as pw:
  context=pw.chromium.launch_persistent_context(str(profile),executable_path="/usr/bin/chromium-browser",headless=True,accept_downloads=True,viewport={"width":1280,"height":900},args=["--no-sandbox","--disable-dev-shm-usage"],timeout=15000)
  report["chromium"]=context.browser.version
  def gate(route):
   u=route.request.url
   if u.startswith(origin+"/"):route.continue_()
   else:report["blockedExternal"].append(u);route.abort()
  context.route("**/*",gate)
  for label,phone,removed in [
   ("complete-desktop",False,{"title":"Lettering <fictional>","amount":"007.50","evidence":"Keep the full authored evidence.\n\nZoë — خدمة & <literal>"}),
   ("unfinished-phone",True,{"title":"","amount":"12..30","evidence":"  unfinished acceptance\n\nfinal line  "})]:
   page=context.new_page();page.set_default_timeout(7000)
   if phone:page.set_viewport_size({"width":390,"height":844})
   page.on("pageerror",lambda e:report["pageErrors"].append(str(e)))
   page.goto(origin+"/scope.html");page.locator(".scope-row").first.wait_for()
   page.locator("#scope-label").fill("Orchid release · authored fixture")
   page.locator("#scope-brief").fill("A private fictional editing exercise.\nKeep the remaining fields.")
   page.locator("#scope-cap").fill(" 2000.00 ")
   for key,value in removed.items():page.locator("#draft-1-"+key).fill(value)
   before=snapshot(page)
   before_file=saved(page,label+"-before")
   assert before_file["record"]["draft"]==before,"native download must retain the original raw draft"
   page.get_by_role("button",name="Remove checkpoint 2",exact=True).click()
   after=snapshot(page)
   expected={**before,"checkpoints":[before["checkpoints"][0],before["checkpoints"][2]]}
   assert after==expected,"ordinary Remove must retain all other raw draft fields"
   after_file=saved(page,label+"-after")
   assert after_file["record"]["draft"]==after,"post-remove download must match the actual draft"
   undo=page.get_by_role("button",name="Undo last checkpoint removal",exact=True)
   available=undo.count()==1 and undo.is_enabled()
   row={"name":label,"before":before,"after_remove":after,"ordinary_removal_exact":True,"before_download":before_file,"after_download":after_file,"undo_available":available,"visible_buttons":page.get_by_role("button").all_text_contents(),"recovered_exactly":False}
   if available:
    undo.focus();page.keyboard.press("Enter")
    row["after_undo"]=snapshot(page);row["recovered_exactly"]=row["after_undo"]==before
    assert row["recovered_exactly"],"Undo must restore the exact complete raw draft"
    row["restored_download"]=saved(page,label+"-restored")
    assert row["restored_download"]["record"]["draft"]==before
   else:row["recovery_failure"]="No Undo last checkpoint removal control exists; the removed three-field checkpoint is absent from the active draft and its new native workspace download."
   try:
    page.locator("#scope-add").scroll_into_view_if_needed()
    image=page.screenshot(full_page=False,timeout=5000)
    report["screenshots"].append(write(label+".png",image))
   except Exception as e:row["screenshot_error"]=str(e)
   # Positive existing boundary: removing down to one row keeps the last row.
   while page.locator(".scope-row").count()>1:page.get_by_role("button",name="Remove checkpoint 1",exact=True).click()
   row["last_row_removal_disabled"]=page.get_by_role("button",name="Remove checkpoint 1",exact=True).is_disabled()
   assert row["last_row_removal_disabled"]
   report["cases"].append(row);page.close()
  context.close();context=None;report["browserClosed"]=True
except Exception as e:
 report["error"]=str(e);report["traceback"]=traceback.format_exc()
finally:
 if context:
  try:context.close();report["browserClosed"]=True
  except Exception as e:report["cleanupError"]=str(e)
 server.shutdown();server.server_close();thread.join(timeout=2)
 if report["browserClosed"] and profile.exists():shutil.rmtree(profile);report["profileRemoved"]=True
 report["sourceUnchanged"]=all(digest((source/name).read_bytes())==pin["sha256"] for name,pin in source_pins.items())
 report["finished"]=time.time()
 report["result"]="PASS" if len(report["cases"])==2 and all(c["recovered_exactly"] for c in report["cases"]) and not report.get("error") and report["sourceUnchanged"] and not report["pageErrors"] and report["browserClosed"] and report["profileRemoved"] else "FAIL"
 raw=(json.dumps(report,ensure_ascii=False,indent=2)+"\n").encode()
 receipt=write("result.json",raw)
 print(json.dumps({"root":str(root),"result":report["result"],"head":report["head"],"tree":report["tree"],"driver":driver,"receipt":receipt,"chromium":report.get("chromium"),"cases":[{"name":c["name"],"ordinary_removal_exact":c["ordinary_removal_exact"],"undo_available":c["undo_available"],"recovered_exactly":c["recovered_exactly"],"last_row_removal_disabled":c["last_row_removal_disabled"]} for c in report["cases"]],"error":report.get("error"),"sourceUnchanged":report["sourceUnchanged"],"browserClosed":report["browserClosed"],"profileRemoved":report["profileRemoved"],"pageErrors":report["pageErrors"],"blockedExternal":report["blockedExternal"]}),flush=True)
 sys.exit(0 if report["result"]=="PASS" else 1)
