# ScopeSignal checkpoint removal recovery — author receiving

Repository: Jacob-Met/scopesignal, default branch paypal-ai. Qualified base: 847505d2fe9f8295110fc13a3fb9e05ec71f6644, tree cac1d2bbdd38e2e4c2aed7249c2593ec174c0eaa. Root recorded the native source scope before edits at 2026-10-08T17:08:10.756Z. Claim: https://github.com/Jacob-Met/scopesignal/issues/34 . Neighbor notice: https://github.com/Jacob-Met/scopesignal/issues/29#issuecomment-6065625972 . The initial ordinary GitHub creation returned secondary-limit403; normal cooldown later succeeded. No alternate route was used.

The frozen controller is 676c4b3d331cfb8efe7a62cccbb7420de583271f3865e3270e2ddfdc8cd47db1; HTML is b663dad1e86d86c827efb547a6f2337a9940c3c9b5b21d6192c8020964a0a94b. Their Git blobs are 2f2a97a859812c94c028babe2e0c4cd31f940dd7 and 5a7931b321f076b2bed8bcc2ef67d7242ed3784e. The original controller is a71f7ecfca0c3ddb40177c8114846de1cdfcdf3bebd6f4be8c2faa74ea5584b9; original HTML is74d5d0b7dc212dcd6881e1ca14b2a9fcfdbc632b00e55d1dc9a1bb2521dafb4a.

A visitor can undo the most recent removed checkpoint without an earlier saved download. The retained row preserves raw strings, position and surrounding draft fields. Restore is one-shot and focuses the original title. Later field/structural edits, entry to review, another removal and actual file replacement retire the previous recovery. Downloads and invalid/canceled file previews preserve it. Undo retires pending replacement/read continuations through the existing workspaceChanged mechanism. A silent field change refuses stale recovery instead of overwriting it. Recovery is in memory only; reload or closing the tab does not preserve it. Existing saved-file recovery and the read-only export remain intact. renderReview, provider/payment/ledger code, codec, CSS and other workers' checkouts are unchanged.

## Preserved before-control and meaningful browser receiving

The actual /scope.html route imports ./src/scope-workspace.mjs. All source capsules contain its eleven real inputs. The baseline's pre-removal JSON download is a serialization oracle, not an assertion that reopening a deliberately saved old file is broken.

The exact two-case driver a92bffb0655301c1ea278be35afce710a34fe80921730fff61eb5b20ab726d7a demonstrates missing immediate Undo for a complete and an unfinished middle row. Ordinary Remove, exact remaining raw data, native downloads and the minimum-row bound pass. The unchanged driver passes both candidate cases, restoring the exact full draft and native saved JSON through keyboard activation.

The unchanged expanded driver55aad4f600a7a325e66b7caf33273e2796d4c40ce109156cd51f83db1f03641c has12 missing-Undo failures and1 existing-control group on baseline; all13 groups pass on candidate. The groups cover initial/minimum bounds, exact keyboard restoration/focus/download, first/final unfinished rows, six later field changes, Add/copy/move, silent drift, repeated one-shot removal, maximum12 rows, invalid versus actual review/edit/approval, prepared file preview, completed native File.arrayBuffer delivery released after Undo, invalid/canceled/identical file apply, and narrow-screen action/focus. Real native file selection and bytes are used; only delivery after an already completed native read is held. Hidden/disabled synthetic click dispatches occur solely in no-effect guards.

Original result hashes:
- baseline two cases:5f823ad90ea16245866dd0769578f386ca80a721b127fdf094c1cc1f201fde58
- candidate two cases:68a3e389c8dda4e8b9602c6935753c3cf2d0770e1517ddf30db70a57453a4b80
- baseline thirteen groups:dace358fdffbe60f74b8618bf82a2da4fd6f782a60770c33623ba32a6d479a9d
- candidate thirteen groups:41ab3954528a5eb289f39f172c6c82c1161954a7ac8cc94205e5e818277b56a3
- actual maintained CLI:e769f15f5d00a0793b5a13f9b21f31d16fa2e9d1faf2bdd51938aac6d25d244c

scripts/check-scope-checkpoint-undo.cjs (698d1c9eae4c69a5d5fe7b707e950e8954a2a674ad322ee4fdda582c696405b9; Git blob65615a4333f274846ffdd5d4a0821e979b201d06) preserves the13 case bodies and adds reusable source/evidence/browser configuration. Its actual file entry also passed13/13 with exit0. README6f656450e46ceb9171329774d7b9a802cf93c374c59155620732c2c3a8c96b63 describes the one-step lifetime and reproduction.

## Native environment and independent receiving

This exercised Linux/ThinkPad node22.22.1 and installed Chromium153.0.8010.47 snap with isolated loopback fixtures and fresh profiles. ScopeSignal declares Node>=24; this is not a local Node24 package-suite claim. Normal hosted Node24 CI must receive the final published tree. The inspected narrow screenshot shows the complete Undo action, separate existing Add control, no horizontal overflow and restored focus.

Two zero-case environment failures are retained. Python Playwright invoked its missing /usr/share/nodejs/playwright/cli.js. The first CDP launch selected environment HOME/home/jacob/.commander-tp-2 and snap refused that hidden profile lock. The corrected driver resolves the actual account home with os.userInfo().homedir and uses a new visible user-owned directory under/home/jacob. No sandbox, existing profile or live service was changed. Successful runs exit their own browser normally, remove only their profile and preserve source hashes. Google Fonts requests are blocked; do not interpret this as no attempted font requests. Retained Chromium diagnostics are bounded by the driver.

research_integration independently accepted the same676c/b663 source through three distinct native file/lifecycle cases. Its complete24-file packet is copied byte-exact under independent: manifest0076ede91d1582366ecf4771d55af0a75cbc793e1b533e15c569cc6e19acb7ac; receipt5a85a8e42419022949c191d744d36b61e778e090d8238dc5419b378d539e5848; probe067bc57f467b1dddd8be324fb55e0f33615d8ba6bf1cda0220e9b3e1a98eeaf9; result0babe0e1d8984fccddaec9b18b759f7f1e389baee34dccdaad6701cbbafb21d9. Imported locked uncertain-capture history cannot be changed by stale Undo; an already saved reduced draft stays immutable through restore/reload/reopen; actual script-free HTML export retains reduced unfinished fields and does not consume immediate recovery. The independent receipt distinguishes reused CDP plumbing from independently authored cases and does not count its later convenience wrapper as another execution.

## Custody and limits

All original native source, probes, JSON downloads, raw reports, retained diagnostics and screenshots from seven author capsules are preserved as bytes. The independent packet is preserved separately in the same lossless archive. This excludes ephemeral tool-transport envelopes lost during the capability refresh; no native evidence is reconstructed from rendered text. The top-level manifest binds every payload's byte length/hash and native origin. Deterministic ustar permits ordinary directories, but no symlinks or special members. The archive is read back and every regular member checked against the exact copied bytes.

This is author and independent fixture receiving, not deployment or a claim that an existing live visitor tab loaded this candidate. Current-main composition, published-tree CI, root's normal final merge and public Pages receiving remain separate gates.
