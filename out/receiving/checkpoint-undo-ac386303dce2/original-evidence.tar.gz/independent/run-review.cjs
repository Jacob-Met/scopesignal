'use strict';
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const sourceRoot = path.join(__dirname, 'source');
const files = {};
function walk(dir) {
  for (const name of fs.readdirSync(dir)) {
    const file = path.join(dir, name), st = fs.lstatSync(file);
    if (st.isDirectory()) walk(file);
    else if (st.isFile()) {
      const bytes = fs.readFileSync(file);
      files[path.relative(sourceRoot, file)] = {
        text: bytes.toString('utf8'),
        git_blob: crypto.createHash('sha1').update('blob ' + bytes.length + '\0').update(bytes).digest('hex'),
      };
    } else throw new Error('Nonregular source entry');
  }
}
walk(sourceRoot);
for (const [name, pin] of Object.entries({
  'src/scope-workspace.mjs': '676c4b3d331cfb8efe7a62cccbb7420de583271f3865e3270e2ddfdc8cd47db1',
  'scope.html': 'b663dad1e86d86c827efb547a6f2337a9940c3c9b5b21d6192c8020964a0a94b',
})) {
  if (crypto.createHash('sha256').update(files[name].text).digest('hex') !== pin) throw new Error('Frozen source mismatch: ' + name);
}
const driver = fs.readFileSync(path.join(__dirname, 'evidence/reproduce.cjs'), 'utf8');
if (crypto.createHash('sha256').update(driver).digest('hex') !== '067bc57f467b1dddd8be324fb55e0f33615d8ba6bf1cda0220e9b3e1a98eeaf9') throw new Error('Frozen independent probe mismatch');
const packet = { source: { head: '676c4b3d candidate over847505d2', tree: '11-file exact native source capsule', files }, driver };
new Function('require', 'packet', driver + '\nreturn main(packet);')(require, packet)
  .catch(error => { console.error(error.stack); process.exitCode = 1; });
