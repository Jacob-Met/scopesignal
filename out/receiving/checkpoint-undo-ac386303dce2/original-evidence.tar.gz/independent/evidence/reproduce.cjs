const fs=require("node:fs/promises"),path=require("node:path"),os=require("node:os"),crypto=require("node:crypto"),http=require("node:http"),{spawn}=require("node:child_process"),readline=require("node:readline"),assert=require("node:assert/strict");
const sha=b=>crypto.createHash("sha256").update(b).digest("hex");
const blob=b=>crypto.createHash("sha1").update("blob "+b.length+"\0").update(b).digest("hex");
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
async function main(packet){
 if(os.hostname()!=="hamon-thinkpad")throw Error("Wrong native host");
 const root=await fs.mkdtemp(path.join(os.userInfo().homedir,"scopesignal-independent-ac386303dce2-"));await fs.chmod(root,0o700);
 const source=path.join(root,"source"),output=path.join(root,"evidence");await fs.mkdir(source);await fs.mkdir(output);
 const write=async(name,data)=>{const dest=path.join(output,name);await fs.writeFile(dest,data,{flag:"wx"});return {path:dest,bytes:Buffer.byteLength(data),sha256:sha(data)};};
 const sourcePins={};
 for(const[name,item]of Object.entries(packet.source.files)){
  assert(!path.isAbsolute(name)&&!name.split("/").includes(".."));
  const b=Buffer.from(item.text);assert.equal(blob(b),item.git_blob,name);
  const p=path.join(source,name);await fs.mkdir(path.dirname(p),{recursive:true});await fs.writeFile(p,b,{flag:"wx"});
  sourcePins[name]={bytes:b.length,sha256:sha(b),git_blob:item.git_blob};
 }
 const driverPin=await write("reproduce.cjs",packet.driver);
 const report={schema:"scopesignal.checkpoint-undo-independent-file-lifecycle/1",head:packet.source.head,tree:packet.source.tree,root,driver:driverPin,host:os.hostname(),node:process.version,started:new Date().toISOString(),sourceBefore:sourcePins,cases:[],screenshots:[],downloads:[],requests:[],serverRequests:[],blockedExternal:[],pageErrors:[],sourceUnchanged:false,browserClosed:false,profileRemoved:false,limits:["Unmodified exact source capsule and fictional local drafts only.","Normal installed Chromium snap via standard CDP; fresh user-owned visible-home profile.","Keyboard activation and native browser downloads; no provider, account or existing profile.","Missing recovery is a user workflow gap, not a claim that Remove violates its present documented action.","Narrow viewport is not a physical phone. The earlier Playwright driver-startup failure is separate and remains preserved."]};
 const server=http.createServer(async(req,res)=>{try{
  const n=decodeURIComponent(new URL(req.url,"http://127.0.0.1").pathname).replace(/^\/+/,"");report.serverRequests.push(n);
  const item=packet.source.files[n];if(!item){res.writeHead(404);res.end("Not found");return;}
  res.writeHead(200,{"Content-Type":(n.endsWith(".html")?"text/html":n.endsWith(".css")?"text/css":"application/javascript")+"; charset=utf-8","Cache-Control":"no-store"});res.end(item.text);
 }catch(e){res.writeHead(500);res.end("Fixture server error");}});
 await new Promise(r=>server.listen(0,"127.0.0.1",r));
 const origin="http://127.0.0.1:"+server.address().port;report.origin=origin;
 class Browser{
  constructor(){this.seq=0;this.pending=new Map();this.downloads=new Map();this.asyncErrors=[];this.log="";this.closing=false;}
  async waitFor(fn,label,ms=10000){const end=Date.now()+ms;let last;while(Date.now()<end){if(this.asyncErrors.length)throw Error(this.asyncErrors.join("\n"));try{if(await fn())return;}catch(e){last=e;}await sleep(100);}throw Error("Timed out "+label+(last?": "+last.message:""));}
  command(method,params={},session=this.session){return new Promise((resolve,reject)=>{
   const id=++this.seq,timer=setTimeout(()=>{this.pending.delete(id);reject(Error("CDP timeout "+method));},15000);
   this.pending.set(id,{resolve,reject,timer});this.socket.send(JSON.stringify({id,method,params,...(session?{sessionId:session}:{})}));
  });}
  async evaluate(expression){const r=await this.command("Runtime.evaluate",{expression,awaitPromise:true,returnByValue:true});if(r.exceptionDetails)throw Error(r.exceptionDetails.exception?.description||r.exceptionDetails.text);return r.result.value;}
  async key(name){const code={Enter:13,Backspace:8,Tab:9}[name];for(const type of ["keyDown","keyUp"])await this.command("Input.dispatchKeyEvent",{type,key:name,code:name,windowsVirtualKeyCode:code,nativeVirtualKeyCode:code,...(name==="Enter"&&type==="keyDown"?{text:"\r",unmodifiedText:"\r"}:{})});}
  async activate(selector){assert(await this.evaluate("!!document.querySelector("+JSON.stringify(selector)+")"),"Missing "+selector);await this.evaluate("document.querySelector("+JSON.stringify(selector)+").focus()");await this.key("Enter");}
  async fill(selector,value){await this.evaluate("(()=>{const e=document.querySelector("+JSON.stringify(selector)+");e.focus();e.select();})()");await this.key("Backspace");if(value)await this.command("Input.insertText",{text:value});}
  async snapshot(){return this.evaluate("({label:document.querySelector('#scope-label').value,brief:document.querySelector('#scope-brief').value,cap:document.querySelector('#scope-cap').value,checkpoints:[...document.querySelectorAll('.scope-row')].map(row=>Object.fromEntries(['title','amount','evidence'].map(key=>[key,row.querySelector('[data-field=\"'+key+'\"]').value])))})");}
  async launch(){
   this.profile=await fs.mkdtemp(path.join(root,"profile-"));report.profile=this.profile;
   this.child=spawn("/usr/bin/chromium-browser",["--headless=new","--disable-gpu","--disable-background-networking","--disable-component-update","--disable-sync","--no-first-run","--no-default-browser-check","--disable-dev-shm-usage","--remote-debugging-address=127.0.0.1","--remote-debugging-port=0","--user-data-dir="+this.profile,"about:blank"],{stdio:["ignore","ignore","pipe"]});
   this.child.stderr.on("data",b=>{this.log=(this.log+b.toString()).slice(-32000);});let launchError;this.child.on("error",e=>{launchError=e;});
   let port,endpoint;await this.waitFor(async()=>{if(launchError)throw launchError;if(this.child.exitCode!==null)throw Error("Owned Chromium exited "+this.child.exitCode+": "+this.log);[port,endpoint]=(await fs.readFile(path.join(this.profile,"DevToolsActivePort"),"utf8")).trim().split("\n");return port&&endpoint;},"Chromium startup",20000);
   this.socket=new WebSocket("ws://127.0.0.1:"+port+endpoint);
   this.socket.addEventListener("message",event=>{const m=JSON.parse(event.data);
    if(m.id){const p=this.pending.get(m.id);if(!p)return;clearTimeout(p.timer);this.pending.delete(m.id);m.error?p.reject(Error(m.error.message)):p.resolve(m.result);}
    else if(m.method==="Runtime.exceptionThrown")report.pageErrors.push(m.params.exceptionDetails.exception?.description||m.params.exceptionDetails.text);
    else if(m.method==="Network.requestWillBeSent")report.requests.push({url:m.params.request.url,type:m.params.type,sessionId:m.sessionId});
    else if(m.method==="Fetch.requestPaused"){const url=m.params.request.url,allow=url.startsWith(origin+"/")||url.startsWith("blob:")||url.startsWith("data:");if(!allow)report.blockedExternal.push(url);this.command(allow?"Fetch.continueRequest":"Fetch.failRequest",{requestId:m.params.requestId,...(!allow?{errorReason:"BlockedByClient"}:{})},m.sessionId).catch(e=>this.asyncErrors.push(e.message));}
    else if(m.method==="Browser.downloadWillBegin")this.downloads.set(m.params.guid,{...m.params,state:"started"});
    else if(m.method==="Browser.downloadProgress"){const d=this.downloads.get(m.params.guid);if(d)Object.assign(d,m.params);}
   });
   this.socket.addEventListener("close",()=>{for(const p of this.pending.values()){clearTimeout(p.timer);p.reject(Error("CDP closed"));}this.pending.clear();});
   await new Promise((r,j)=>{this.socket.addEventListener("open",r,{once:true});this.socket.addEventListener("error",j,{once:true});});
   report.chromium=await this.command("Browser.getVersion",{},null);
   await this.command("Browser.setDownloadBehavior",{behavior:"allowAndName",downloadPath:output,eventsEnabled:true},null);
  }
  async newPage(phone){
   this.targetId=(await this.command("Target.createTarget",{url:"about:blank"},null)).targetId;
   this.session=(await this.command("Target.attachToTarget",{targetId:this.targetId,flatten:true},null)).sessionId;
   for(const method of ["Page.enable","Runtime.enable","Network.enable"])await this.command(method);
   await this.command("Fetch.enable",{patterns:[{urlPattern:"*"}]});
   await this.command("Emulation.setDeviceMetricsOverride",{width:phone?390:1280,height:phone?844:900,deviceScaleFactor:1,mobile:false});
   await this.command("Page.navigate",{url:origin+"/scope.html"});
   await this.waitFor(()=>this.evaluate("document.readyState==='complete'&&document.querySelectorAll('.scope-row').length===3"),"exact ScopeSignal fixture",10000);
  }
  async save(name){
   const old=new Set(this.downloads.keys());await this.activate("#scope-save");let d;
   await this.waitFor(()=>{d=[...this.downloads.values()].find(x=>!old.has(x.guid));return d&&d.state==="completed";},"native workspace download",10000);
   assert.equal(d.suggestedFilename,"scopesignal-workspace-v1.json");
   const p=path.join(output,d.guid),bytes=await fs.readFile(p);const dest=path.join(output,name+".json");await fs.rename(p,dest);
   const saved={path:dest,bytes:bytes.length,sha256:sha(bytes),suggestedFilename:d.suggestedFilename,record:JSON.parse(bytes.toString("utf8"))};report.downloads.push({...d,path:dest,sha256:saved.sha256});return saved;
  }
  async close(){
   if(this.socket?.readyState===WebSocket.OPEN){this.closing=true;try{await this.command("Browser.close",{},null);}catch(e){report.closeCommandError=e.message;}}
   if(this.child){const exited=()=>this.child.exitCode!==null||this.child.signalCode!==null;for(let i=0;i<30&&!exited();i++)await sleep(100);if(!exited()){report.cleanupSignal="SIGTERM";this.child.kill("SIGTERM");for(let i=0;i<30&&!exited();i++)await sleep(100);}report.browserClosed=exited();report.browserExitCode=this.child.exitCode;report.browserSignal=this.child.signalCode;}
   this.socket?.close();for(const p of this.pending.values()){clearTimeout(p.timer);p.reject(Error("Receiver ended"));}this.pending.clear();
   if(report.browserClosed&&this.profile){await fs.rm(this.profile,{recursive:true,maxRetries:3,retryDelay:100});report.profileRemoved=true;}
   await write("chromium.log",this.log);
  }
 }

 const browser=new Browser();
 try {
  await browser.launch();
  const snapshot=()=>browser.snapshot();
  const undoAvailable=()=>browser.evaluate("(()=>{const e=document.querySelector('#scope-undo-remove');return !!e&&!e.hidden&&!e.disabled&&e.checkVisibility();})()");
  async function fresh(){if(browser.targetId&&browser.session){await browser.command("Target.closeTarget",{targetId:browser.targetId},null);browser.session=null;}await browser.newPage(false);}
  async function arm(){const before=await snapshot();await browser.activate('button[data-remove="1"]');assert.equal(await undoAvailable(),true);assert.equal((await snapshot()).checkpoints.length,before.checkpoints.length-1);return before;}
  async function setFile(file){const doc=await browser.command("DOM.getDocument");const node=await browser.command("DOM.querySelector",{nodeId:doc.root.nodeId,selector:"#scope-open"});await browser.command("DOM.setFileInputFiles",{nodeId:node.nodeId,files:[file]});}
  async function open(file){await setFile(file);await browser.waitFor(()=>browser.evaluate("!document.querySelector('#scope-open-preview').hidden"),"native file preview");await browser.activate("#scope-open-apply");}
  async function staleUndo(){const before=await snapshot();assert.equal(await undoAvailable(),false);await browser.evaluate("document.querySelector('#scope-undo-remove').dispatchEvent(new MouseEvent('click',{bubbles:true}))");assert.deepEqual(await snapshot(),before);}
  async function check(name,body){const row={name,started:new Date().toISOString()};try{row.evidence=await body();row.result="PASS";}catch(error){row.result="FAIL";row.error=error.stack;}report.cases.push(row);console.log(JSON.stringify({case:name,result:row.result,error:row.error?.split("\n")[0]}));}
  async function downloadHtml(name){
   const old=new Set(browser.downloads.keys());await browser.activate("#scope-review-download");let download;
   await browser.waitFor(()=>{download=[...browser.downloads.values()].find(x=>!old.has(x.guid));return download?.state==="completed";},"native review HTML download");
   assert.match(download.suggestedFilename,/\.html$/);
   const original=path.join(output,download.guid),bytes=await fs.readFile(original),target=path.join(output,name+".html");await fs.rename(original,target);
   report.downloads.push({...download,path:target,sha256:sha(bytes)});
   return{path:target,bytes:bytes.length,sha256:sha(bytes),text:bytes.toString("utf8")};
  }

  await check("Imported locked uncertain-capture history retires draft recovery and survives a stale activation",async()=>{
   await fresh();await browser.fill("#scope-label","Imported review with an uncertain capture");
   await browser.activate('#scope-form button[type="submit"]');
   for(const action of ["approve","order","request","lose"]) await browser.activate('[data-action="'+action+'"][data-checkpoint="scope-1"]');
   const incoming=await browser.save("01-locked-uncertain-incoming");
   assert.equal(incoming.record.stage,"review");assert.equal(incoming.record.events.length,4);
   assert(incoming.record.events.some(event=>event.type==="paypal.capture.response_lost"));
   await fresh();await browser.fill("#draft-1-title","Removed draft row must not enter imported history");await arm();
   await open(incoming.path);
   assert.equal(await browser.evaluate("document.querySelector('#scope-form').hidden"),true);
   assert.equal(await browser.evaluate("document.querySelector('#scope-edit').disabled"),true);
   const received=await browser.save("02-locked-received");
   assert.deepEqual(received.record,incoming.record);
   await staleUndo();
   const after=await browser.save("03-locked-after-stale-undo");
   assert.deepEqual(after.record,incoming.record);
   assert.equal(await browser.evaluate("document.querySelectorAll('[data-action=\"request\"]').length"),0);
   return{incoming:incoming.sha256,received:received.sha256,after:after.sha256,events:after.record.events,
    importedReviewLocked:true,noSecondCaptureRequest:true,staleRecoveryPreservedExactFile:true};
  });

  await check("A removed-row JSON download remains immutable across Undo, reload and explicit reopen",async()=>{
   await fresh();await browser.fill("#scope-label","Saved reduced draft survives a new page");
   await browser.fill("#draft-1-title","Transient undo-only checkpoint Ω");
   const original=await arm(),remaining=await snapshot(),saved=await browser.save("04-reduced-draft");
   assert.deepEqual(saved.record.draft,remaining);assert.equal(saved.record.stage,"draft");assert.deepEqual(saved.record.events,[]);
   await browser.activate("#scope-undo-remove");assert.deepEqual(await snapshot(),original);
   const restored=await browser.save("05-restored-draft");assert.deepEqual(restored.record.draft,original);
   assert.equal(sha(await fs.readFile(saved.path)),saved.sha256,"Undo must not mutate the already downloaded file");
   await browser.command("Page.reload",{ignoreCache:true});
   await browser.waitFor(()=>browser.evaluate("document.readyState==='complete'&&document.querySelectorAll('.scope-row').length===3"),"new document after reload");
   await staleUndo();
   await open(saved.path);assert.deepEqual(await snapshot(),remaining);await staleUndo();
   const reopened=await browser.save("06-reopened-reduced-draft");assert.deepEqual(reopened.record,saved.record);
   assert.equal(sha(await fs.readFile(restored.path)),restored.sha256);
   return{before:original,remaining,saved:saved.sha256,restored:restored.sha256,reopened:reopened.sha256,
    undoWasDocumentLocal:true,explicitFileReopenPreservedRawRemovedDraft:true};
  });

  await check("Read-only HTML export preserves current recovery and carries only the reduced raw draft",async()=>{
   await fresh();await browser.fill("#draft-0-title","Remaining <tag> Ω row");
   await browser.fill("#draft-0-amount","12..30");
   await browser.fill("#draft-1-title","REMOVED_UNIQUE_CHECKPOINT_23");
   const before=await arm(),remaining=await snapshot();
   const html=await downloadHtml("07-reduced-review");
   assert.equal(await undoAvailable(),true);assert.deepEqual(await snapshot(),remaining);
   assert(html.text.includes("Remaining &lt;tag&gt; Ω row"));
   assert(html.text.includes("12..30"));
   assert(!html.text.includes("REMOVED_UNIQUE_CHECKPOINT_23"));
   const htmlTarget=(await browser.command("Target.createTarget",{url:"about:blank"},null)).targetId;
   const htmlSession=(await browser.command("Target.attachToTarget",{targetId:htmlTarget,flatten:true},null)).sessionId;
   await browser.command("Page.enable",{},htmlSession);await browser.command("Runtime.enable",{},htmlSession);
   await browser.command("Page.navigate",{url:"file://"+html.path},htmlSession);
   let view;
   await browser.waitFor(async()=>{const r=await browser.command("Runtime.evaluate",{expression:"({ready:document.readyState,text:document.body?.innerText,scripts:document.scripts.length})",returnByValue:true},htmlSession);view=r.result.value;return view?.ready==="complete";},"actual saved review document");
   assert.equal(view.scripts,0);assert(view.text.includes("Remaining <tag> Ω row"));assert(!view.text.includes("REMOVED_UNIQUE_CHECKPOINT_23"));
   await browser.command("Target.closeTarget",{targetId:htmlTarget},null);
   await browser.activate("#scope-undo-remove");assert.deepEqual(await snapshot(),before);
   assert.equal(sha(await fs.readFile(html.path)),html.sha256);await staleUndo();
   return{html:html.sha256,htmlBytes:html.bytes,readOnlyDocumentOpened:true,executableScripts:view.scripts,
    rawInvalidAmountRetained:true,originalCheckpointRestored:before.checkpoints[1],exportFileUnchanged:true};
  });

  assert.equal(report.cases.length,3);
  assert.deepEqual(report.pageErrors,[]);
  assert.deepEqual(report.blockedExternal.filter(u=>!u.startsWith("https://fonts.googleapis.com/")&&!u.startsWith("https://fonts.gstatic.com/")),[]);
 } catch(error) {report.error=error.message;report.stack=error.stack;}
 finally {
  await browser.close();await new Promise(resolve=>server.close(resolve));
  report.sourceUnchanged=true;
  for(const[name,pin]of Object.entries(sourcePins))if(sha(await fs.readFile(path.join(source,name)))!==pin.sha256)report.sourceUnchanged=false;
  report.finished=new Date().toISOString();
  report.result=report.error?"RECEIVING_ERROR":report.cases.length===3&&report.cases.every(x=>x.result==="PASS")?"PASS":"FAIL";
  const bytes=Buffer.from(JSON.stringify(report,null,2)+"\n"),receipt=await write("result.json",bytes);
  console.log(JSON.stringify({root,result:report.result,driver:driverPin,receipt,chromium:report.chromium,cases:report.cases.map(x=>({name:x.name,result:x.result,error:x.error?.split("\n")[0]})),error:report.error,sourceUnchanged:report.sourceUnchanged,browserClosed:report.browserClosed,profileRemoved:report.profileRemoved,browserExitCode:report.browserExitCode,browserSignal:report.browserSignal,pageErrors:report.pageErrors,blockedExternal:report.blockedExternal}));
  process.exitCode=report.result==="PASS"?0:1;
 }
}
