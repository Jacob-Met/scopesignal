import test from 'node:test';
import assert from 'node:assert/strict';
import { pathToFileURL } from 'node:url';
import { resolve } from 'node:path';

const source = process.env.SCOPESIGNAL_REVIEW_SOURCE;
assert.ok(source, 'SCOPESIGNAL_REVIEW_SOURCE must select a frozen source snapshot');
const moduleUrl = pathToFileURL(resolve(source, 'src/workers-ai.mjs'));
let instance = 0;
const api = () => import(`${moduleUrl}?independent-case=${instance++}`);

globalThis.fetch = () => { throw new Error('Independent receiving forbids network requests'); };

const ordinary = label => ({ checkpoints: [{ title: label, evidence: 'Local synthetic evidence' }] });
// Every numeric entry denotes exactly one Unicode scalar. Expected lengths come
// from the constructed scalar count, independently of the validator's spread.
const mixedScalars = [0x41, 0x1d11e, 0x20000, 0x1f680, 0x301, 0, 0x22, 0x5c, 10];
const asciiScalars = [0x41, 0x22, 0x5c, 10, 0];
const generated = (count, scalars) => Array.from(
  { length: count }, (_, index) => String.fromCodePoint(scalars[index % scalars.length]),
).join('');
const escapedJson = value => JSON.stringify(value).replace(
  /[^\x00-\x7f]/g, unit => `\\u${unit.charCodeAt(0).toString(16).padStart(4, '0')}`,
);

for (const [field, maximum] of [['title', 120], ['evidence', 500]]) {
  for (const transport of ['literal JSON', 'escaped response envelope']) {
    for (const [caseName, count, scalars, accepted] of [
      ['mixed scalar exact boundary', maximum, mixedScalars, true],
      ['mixed scalar one above boundary', maximum + 1, mixedScalars, false],
      ['ASCII escaping control', maximum, asciiScalars, true],
    ]) {
      test(`${field}: ${caseName} through ${transport}`, async () => {
        const { interpretWithWorkersAI } = await api();
        const expected = ordinary('Boundary checkpoint');
        expected.checkpoints[0][field] = generated(count, scalars);
        const supplied = transport === 'literal JSON'
          ? JSON.stringify(expected)
          : { response: escapedJson(expected), usage: { synthetic: true } };
        const calls = [];
        const binding = { async run(model, request) {
          calls.push({ model, request });
          await Promise.resolve();
          return supplied;
        } };
        const receiving = interpretWithWorkersAI('Independent synthetic boundary brief', { AI: binding });
        if (accepted) assert.deepEqual(await receiving, expected);
        else await assert.rejects(receiving, /schema/);
        assert.equal(calls.length, 1);
        assert.equal(calls[0].request.response_format.json_schema.properties.checkpoints.items.properties[field].maxLength, maximum);
      });
    }
  }
}

test('overlapping requests keep separate schemas and return the result of their own completion', async () => {
  const { interpretWithWorkersAI } = await api();
  const pending = [];
  const AI = { run(model, request) {
    return new Promise(complete => pending.push({ model, request, complete, receiver: this }));
  } };
  const firstPromise = interpretWithWorkersAI('First independent brief', { AI });
  const secondPromise = interpretWithWorkersAI('Second independent brief', { AI });
  const firstSchema = pending[0].request.response_format.json_schema;
  const secondSchema = pending[1].request.response_format.json_schema;
  const differentRoots = firstSchema !== secondSchema;
  const differentItems = firstSchema.properties.checkpoints.items !== secondSchema.properties.checkpoints.items;
  firstSchema.properties.checkpoints.items.properties.title.maxLength = 1;
  firstSchema.properties.checkpoints.items.additionalProperties = true;
  const unaffectedSecond = secondSchema.properties.checkpoints.items.properties.title.maxLength === 120
    && secondSchema.properties.checkpoints.items.additionalProperties === false;

  // Settle in the reverse of dispatch order, through different supported forms.
  pending[1].complete({ response: escapedJson(ordinary('Second result')) });
  const second = await secondPromise;
  pending[0].complete(JSON.stringify(ordinary('First result')));
  const first = await firstPromise;
  const thirdPromise = interpretWithWorkersAI('Third independent brief', { AI });
  const thirdSchema = pending[2].request.response_format.json_schema;
  const pristineThird = thirdSchema.properties.checkpoints.items.properties.title.maxLength === 120
    && thirdSchema.properties.checkpoints.items.additionalProperties === false;
  pending[2].complete(JSON.stringify(ordinary('Third result')));
  const third = await thirdPromise;

  assert.deepEqual(first, ordinary('First result'));
  assert.deepEqual(second, ordinary('Second result'));
  assert.deepEqual(third, ordinary('Third result'));
  assert.deepEqual(pending.map(call => call.request.messages[1].content), [
    'First independent brief', 'Second independent brief', 'Third independent brief',
  ]);
  assert.ok(pending.every(call => call.receiver === AI));
  assert.equal(differentRoots, true, 'overlapping calls share a schema root');
  assert.equal(differentItems, true, 'overlapping calls share nested schema fields');
  assert.equal(unaffectedSecond, true, 'a first-call schema edit changed an in-flight second call');
  assert.equal(pristineThird, true, 'a retained request changed the schema sent by a later call');
});

test('deeply frozen JSON data yields an independently editable result through the async adapter', async () => {
  const { interpretWithWorkersAI } = await api();
  const original = JSON.parse('{"checkpoints":[{"evidence":"Line 1\\n\\u0000 \\\"quoted\\\"","title":"Review \\ud834\\udd1e"}]}');
  Object.freeze(original.checkpoints[0]);
  Object.freeze(original.checkpoints);
  Object.freeze(original);
  const originalJson = JSON.stringify(original);
  let calls = 0;
  const result = await interpretWithWorkersAI('Independent immutable-data brief', { AI: { async run() {
    calls++;
    await Promise.resolve();
    return original;
  } } });
  assert.deepEqual(result, original);
  result.checkpoints[0].title = 'Human-edited checkpoint';
  result.checkpoints.push({ title: 'Human addition', evidence: 'Locally edited' });
  assert.equal(result.checkpoints.length, 2);
  assert.equal(JSON.stringify(original), originalJson);
  assert.equal(calls, 1);
});

test('a delayed binding rejection leaves another in-flight result intact and triggers no retry', async () => {
  const { interpretWithWorkersAI } = await api();
  const pending = [];
  const AI = { run(_model, request) {
    return new Promise((complete, refuse) => pending.push({ request, complete, refuse }));
  } };
  const providerFailure = new Error('Synthetic independent binding rejection');
  const failed = interpretWithWorkersAI('Failing synthetic brief', { AI });
  const successful = interpretWithWorkersAI('Successful synthetic brief', { AI });
  const observedFailure = assert.rejects(failed, error => error === providerFailure);
  pending[1].complete(JSON.stringify(ordinary('Unrelated success')));
  assert.deepEqual(await successful, ordinary('Unrelated success'));
  pending[0].refuse(providerFailure);
  await observedFailure;
  await Promise.resolve();
  assert.equal(pending.length, 2);
  assert.deepEqual(pending.map(call => call.request.messages[1].content), [
    'Failing synthetic brief', 'Successful synthetic brief',
  ]);
});
