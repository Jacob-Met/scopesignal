import pathlib,json,subprocess,hashlib,os,datetime,signal
root=pathlib.Path('/Users/me/.hamon-rdc-seats/seat-5/hamon-e3a41d2b3368-scope-compare')
node='/opt/homebrew/bin/node'
driver=root/'receive-pages-delivery-c99.mjs'
out=root/'delivery-c99'
log=root/'delivery-c99-process.log'
assert not out.exists() and not log.exists()
syntax=subprocess.run([node,'--check',str(driver)],capture_output=True,text=True,timeout=15)
assert syntax.returncode==0,syntax.stderr
env=os.environ.copy()
env.update({'SCOPESIGNAL_LIVE_URL':'https://jacobmetoyer.com/scopesignal/','SCOPESIGNAL_MERGE_SHA':'c99a291600fff8f56fb2acc3194feeb9a4822d07','SCOPESIGNAL_DEPLOYMENT_RUN':'37805160191','SCOPESIGNAL_DELIVERY_EVIDENCE':str(out)})
receipt={'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'driverSha256':hashlib.sha256(driver.read_bytes()).hexdigest(),'syntaxReturnCode':syntax.returncode,'timedOut':False}
with log.open('x') as f:
 p=subprocess.Popen([node,str(driver)],cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
 try:receipt['returnCode']=p.wait(timeout=150)
 except subprocess.TimeoutExpired:
  receipt['timedOut']=True
  os.killpg(p.pid,signal.SIGTERM)
  try:p.wait(timeout=5)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
  receipt['returnCode']=p.returncode
receipt['finishedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat()
receipt['logSha256']=hashlib.sha256(log.read_bytes()).hexdigest()
(root/'delivery-c99-process.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
print(log.read_text())
