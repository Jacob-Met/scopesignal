// Post-merge delivery receiver: byte identity plus one actual public two-file flow.
// The comprehensive isolated 16-group gate is intentionally not repeated here.
import assert from 'node:assert/strict';
import puppeteer from '/Users/me/.npm/_npx/4b4c857f6efdfb61/node_modules/puppeteer-core/lib/puppeteer/puppeteer-core.js';
import { readFile, writeFile, mkdir, lstat, rm } from 'node:fs/promises';
import { resolve } from 'node:path';
import { createHash } from 'node:crypto';

const root = '/Users/me/.hamon-rdc-seats/seat-5/hamon-e3a41d2b3368-scope-compare';
const site = new URL(process.env.SCOPESIGNAL_LIVE_URL);
assert.equal(site.protocol, 'https:');
assert(site.pathname.endsWith('/'), 'Use the observed deployed site root ending in /');
const merge = process.env.SCOPESIGNAL_MERGE_SHA;
assert.match(merge ?? '', /^[0-9a-f]{40}$/);
const out = resolve(process.env.SCOPESIGNAL_DELIVERY_EVIDENCE);
const profile = resolve(out, 'browser-profile');
const baseline = JSON.parse(await readFile(resolve(root, 'packet-pr28/browser-bab-v2/receipt.json'), 'utf8'));
const hashes = Object.fromEntries(Object.entries(baseline.servedSha256).filter(([path]) => !path.startsWith('baseline/')));
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const current = JSON.parse(await readFile(resolve(root, 'delivery-c99-input.json'), 'utf8'));
assert.equal(merge, current.source);
assert.equal(site.href, current.requestedSite);
const blob = bytes => createHash('sha1').update('blob ' + bytes.length + '\0').update(bytes).digest('hex');
for (const file of current.currentRuntimeChanges) {
  const bytes = Buffer.from(file.content);
  assert.equal(blob(bytes), file.gitBlob, file.path + ' current Git source');
  assert(hashes[file.path], 'Current override must belong to the prior qualified closure');
  hashes[file.path] = sha(bytes);
}
for (const [name, expected] of Object.entries(current.fixtures)) {
  assert.equal(sha(await readFile(resolve(root, 'packet-pr28/browser-bab-v2/fixtures', name))), expected, name + ' frozen actual download');
}
const deadlineSignal = AbortSignal.timeout(120000);
const receipt = {
  schema: 'scopesignal.pages-delivery-receiving.v1', startedAt: new Date().toISOString(),
  mergedSource: merge, deploymentRun: process.env.SCOPESIGNAL_DEPLOYMENT_RUN || null,
  requestedSite: site.href, qualifiedSourceHead: baseline.sourceCommit, currentSourceBoundary: { source: current.source, tree: current.tree, overrides: current.currentRuntimeChanges.map(({path,gitBlob}) => ({path,gitBlob})), fixtures: current.fixtures },
  expectedSha256: hashes, node: process.version, nodeExecutable: process.execPath,
  http: {}, browserAssets: {}, checks: [], failures: [], pageErrors: [], blockedRequests: []
};
await mkdir(out, { recursive: false });
try { await lstat(profile); throw new Error('Fresh owned profile required'); }
catch (error) { if (error.code !== 'ENOENT') throw error; }
let browser;
const watchdog = setTimeout(() => {
  receipt.failures.push({phase: 'deadline', error: '120-second delivery deadline expired'});
  browser?.close().catch(() => {});
}, 120000);
const pendingResponses = [];
async function check(name, fn) {
  console.log('START ' + name);
  await fn();
  receipt.checks.push({ name, result: 'pass' });
  console.log('PASS ' + name);
}
try {
  await check('deployed HTTP assets match the fully qualified source closure', async () => {
    for (const [path, expected] of Object.entries(hashes)) {
      const url = new URL(path, site).href;
      const response = await fetch(url, { headers: { 'cache-control': 'no-cache' }, signal: AbortSignal.any([deadlineSignal, AbortSignal.timeout(15000)]) });
      const bytes = Buffer.from(await response.arrayBuffer());
      receipt.http[path] = { requested: url, finalUrl: response.url, status: response.status,
        contentType: response.headers.get('content-type'), bytes: bytes.length, sha256: sha(bytes) };
      assert.equal(response.status, 200, path + ' HTTP status');
      assert.equal(sha(bytes), expected, path + ' deployed bytes');
    }
  });
  const authorUrl = receipt.http['scope.html'].finalUrl;
  const compareUrl = receipt.http['scope-compare.html'].finalUrl;
  const allowed = new Map(Object.entries(receipt.http).map(([path, value]) =>
    [new URL(value.finalUrl).origin + new URL(value.finalUrl).pathname, path]));
  browser = await puppeteer.launch({
    executablePath: '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
    headless: true, userDataDir: profile, defaultViewport: { width: 1360, height: 1000 },
    timeout: 30000, args: ['--disk-cache-size=1048576']
  });
  receipt.browser = await browser.version();
  receipt.spawnargs = browser.process()?.spawnargs ?? [];
  assert(!receipt.spawnargs.some(arg => /no-sandbox|disable.*sandbox/.test(arg)));
  const guard = async page => {
    page.setDefaultTimeout(10000);
    page.on('pageerror', error => receipt.pageErrors.push({ url: page.url(), error: error.message }));
    await page.setRequestInterception(true);
    page.on('request', request => {
      const url = new URL(request.url());
      if (allowed.has(url.origin + url.pathname) && ['GET', 'HEAD'].includes(request.method())) {
        request.continue().catch(() => {});
      } else {
        receipt.blockedRequests.push({ url: request.url(), method: request.method(), frame: request.frame()?.url() ?? null });
        request.abort('blockedbyclient').catch(() => {});
      }
    });
    page.on('response', response => {
      const url = new URL(response.url()), path = allowed.get(url.origin + url.pathname);
      if (!path) return;
      const capture = response.buffer().then(bytes => {
        const record = { url: response.url(), status: response.status(), bytes: bytes.length, sha256: sha(bytes) };
        receipt.browserAssets[path] = record;
        assert.equal(record.status, 200, path + ' browser response');
        assert.equal(record.sha256, hashes[path], path + ' browser-loaded bytes');
      }).catch(error => { receipt.failures.push({ phase: 'browser response identity', error: error.stack }); });
      pendingResponses.push(capture);
    });
  };
  await check('public authoring link opens the delivered comparison with two real files', async () => {
    const author = await browser.newPage(); await guard(author);
    await author.goto(authorUrl, { waitUntil: 'load' });
    await author.locator('#scope-label').fill('Delivery receiving control');
    const before = await author.evaluate(() => ({
      url: location.href,
      values: [...document.querySelectorAll('#scope-form input, #scope-form textarea')].map(node => [node.id, node.value]),
      label: document.querySelector('#scope-label').value
    }));
    assert.equal(before.label, 'Delivery receiving control');
    const targets = new Set(browser.targets());
    const popup = browser.waitForTarget(target => target.type() === 'page' && !targets.has(target), { timeout: 10000 });
    await author.locator('a[href="./scope-compare.html"]').click();
    const comparison = await (await popup).page(); await guard(comparison);
    await comparison.reload({ waitUntil: 'load' });
    assert.equal(new URL(comparison.url()).pathname, new URL(compareUrl).pathname);
    assert.equal(await comparison.evaluate(() => window.opener), null);
    for (const [side, name] of [['a', 'download-unknown-A.json'], ['b', 'download-reconciled-B.json']]) {
      const input = await comparison.$('#file-' + side); assert(input);
      await input.uploadFile(resolve(root, 'packet-pr28/browser-bab-v2/fixtures', name));
      await input.dispose();
      await comparison.waitForFunction(({ side, name }) =>
        document.querySelector('#status-' + side).textContent.startsWith('Opened ' + name + '.'), {}, { side, name });
    }
    assert.equal(await comparison.$eval('#history-summary', node => node.dataset.relationship), 'a-prefix');
    assert.equal(await comparison.$eval('#totals tr[data-field="captured"] td[data-side="a"]', node => node.innerText), '$0.00');
    assert.equal(await comparison.$eval('#totals tr[data-field="captured"] td[data-side="b"]', node => node.innerText), '$400.00');
    assert.equal(await comparison.$$eval('#pair-controls select', nodes => nodes.length), 3);
    const after = await author.evaluate(() => ({
      url: location.href,
      values: [...document.querySelectorAll('#scope-form input, #scope-form textarea')].map(node => [node.id, node.value]),
      label: document.querySelector('#scope-label').value
    }));
    assert.deepEqual(after, before);
    receipt.authorPreserved = true;
    receipt.finalUrl = comparison.url();
    receipt.files = {
      a: await comparison.$eval('#name-a', node => node.textContent),
      b: await comparison.$eval('#name-b', node => node.textContent)
    };
    await comparison.screenshot({ path: resolve(out, 'delivered-comparison.png') });
  });
  await Promise.all(pendingResponses);
  await check('browser loaded the expected public assets without page errors', async () => {
    assert.deepEqual(receipt.pageErrors, []);
    assert.deepEqual(receipt.failures, []);
    for (const path of Object.keys(hashes)) assert(receipt.browserAssets[path], 'Browser did not consume ' + path);
    assert(receipt.blockedRequests.every(request =>
      request.url.startsWith('https://fonts.googleapis.com/') || new URL(request.url).pathname.endsWith('/favicon.ico')));
  });
} catch (error) { receipt.failures.push({ phase: 'delivery', error: error.stack }); }
finally {
  clearTimeout(watchdog);
  await browser?.close().catch(() => {});
  await rm(profile, { recursive: true, force: true }).catch(() => {});
  receipt.finishedAt = new Date().toISOString();
  receipt.passed = receipt.failures.length === 0;
  receipt.driverSha256 = sha(await readFile(new URL(import.meta.url)));
  await writeFile(resolve(out, 'receipt.json'), JSON.stringify(receipt, null, 2) + '\n');
  console.log(JSON.stringify({ passed: receipt.passed, checks: receipt.checks, failures: receipt.failures }));
}
if (!receipt.passed) process.exitCode = 1;
