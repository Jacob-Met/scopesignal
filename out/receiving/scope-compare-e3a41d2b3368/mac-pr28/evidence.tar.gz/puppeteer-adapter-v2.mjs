// Receiver-only compatibility bridge for the existing ScopeSignal browser gate.
// It preserves the gate's fixtures/assertions and uses native Puppeteer/CDP actions.
// This file is evidence tooling and is never imported by application pages.
import puppeteer from '/Users/me/.npm/_npx/4b4c857f6efdfb61/node_modules/puppeteer-core/lib/puppeteer/puppeteer-core.js';
import assert from 'node:assert/strict';
import { copyFile, readFile, writeFile } from 'node:fs/promises';
import { resolve } from 'node:path';
import { createHash } from 'node:crypto';

const sleep = ms => new Promise(done => setTimeout(done, ms));
const hash = bytes => createHash('sha256').update(bytes).digest('hex');
const note = {
  schema: 'scopesignal.puppeteer-receiver-adapter.v2',
  purpose: 'Execute the unchanged Playwright-shaped gate with an already installed Puppeteer Core.',
  node: process.version, nodeExecutable: process.execPath, platform: process.platform, arch: process.arch,
  puppeteer: '/Users/me/.npm/_npx/4b4c857f6efdfb61/node_modules/puppeteer-core/lib/puppeteer/puppeteer-core.js',
  puppeteerVersion: '25.12.0', downloads: [], popupReloads: [], adapterErrors: [],
  notes: [
    'Only the browser automation API is adapted; source files, synthetic fixtures and assertions are unchanged.',
    'Every file input uses native ElementHandle.uploadFile or FileChooser.accept.',
    'Downloads use actual Browser.downloadWillBegin/downloadProgress events and completed files.',
    'A new popup is reloaded once after request interception is attached, before any workspace files are opened.',
    'Request.get performs an actual HTTP fetch to the receiver loopback server.',
    'On macOS only, the one native-select ArrowDown call uses a verified native typeahead key; trusted keyboard/input/change events and before/after values are recorded. All assertions are unchanged.'
  ]
};
async function saveNote() {
  if (process.env.SCOPESIGNAL_ADAPTER_RECEIPT) {
    await writeFile(process.env.SCOPESIGNAL_ADAPTER_RECEIPT, JSON.stringify(note, null, 2) + '\n');
  }
}

class Locator {
  constructor(page, selector, filter = null) { this.page = page; this.selector = selector; this.filterSpec = filter; }
  async handle(visible = false) {
    const js = await this.page.raw.waitForFunction((selector, filter, visible) => {
      const nodes = Array.from(document.querySelectorAll(selector));
      const node = nodes.find(node => {
        if (!filter) return true;
        const value = node.textContent ?? '';
        return filter.exact ? value.trim() === filter.text : value.includes(filter.text);
      });
      if (!node) return false;
      if (visible) {
        const style = getComputedStyle(node), box = node.getBoundingClientRect();
        if (style.visibility === 'hidden' || style.display === 'none' || !box.width || !box.height) return false;
      }
      return node;
    }, { timeout: this.page.timeout }, this.selector, this.filterSpec, visible);
    const handle = js.asElement();
    if (!handle) { await js.dispose(); throw new Error('Expected an element: ' + this.selector); }
    return handle;
  }
  async use(run, visible = false) {
    const handle = await this.handle(visible);
    try { return await run(handle); } finally { await handle.dispose(); }
  }
  async count() {
    return this.page.raw.$$eval(this.selector, (nodes, filter) =>
      nodes.filter(node => !filter || (filter.exact
        ? (node.textContent ?? '').trim() === filter.text : (node.textContent ?? '').includes(filter.text))).length,
    this.filterSpec);
  }
  async waitFor(options = {}) {
    assert(!options.state || options.state === 'visible', 'Unsupported receiver wait state');
    await this.use(async () => {}, true);
  }
  async innerText() { return this.use(handle => handle.evaluate(node => node.innerText)); }
  async textContent() { return this.use(handle => handle.evaluate(node => node.textContent)); }
  async inputValue() { return this.use(handle => handle.evaluate(node => node.value)); }
  async getAttribute(name) { return this.use(handle => handle.evaluate((node, key) => node.getAttribute(key), name)); }
  async click() {
    if (!this.filterSpec) return this.page.raw.locator(this.selector).setTimeout(this.page.timeout).click();
    return this.use(handle => handle.click(), true);
  }
  async focus() { return this.use(handle => handle.focus()); }
  async fill(value) {
    assert(!this.filterSpec, 'Unsupported filtered fill');
    return this.page.raw.locator(this.selector).setTimeout(this.page.timeout).fill(value);
  }
  async setInputFiles(paths) {
    const list = Array.isArray(paths) ? paths : [paths];
    return this.use(handle => handle.uploadFile(...list));
  }
  async selectOption(value) { return this.use(handle => handle.select(value)); }
  async check() {
    if (!await this.use(handle => handle.evaluate(node => node.checked))) await this.click();
    assert.equal(await this.use(handle => handle.evaluate(node => node.checked)), true);
  }
  async uncheck() {
    if (await this.use(handle => handle.evaluate(node => node.checked))) await this.click();
    assert.equal(await this.use(handle => handle.evaluate(node => node.checked)), false);
  }
  async isVisible() {
    if (await this.count() === 0) return false;
    return this.use(handle => handle.isVisible());
  }
  async isDisabled() {
    return this.use(handle => handle.evaluate(node => node.matches(':disabled')));
  }
  async isEnabled() { return !(await this.isDisabled()); }
  async evaluateAll(fn) {
    assert(!this.filterSpec, 'Unsupported filtered evaluateAll');
    return this.page.raw.$$eval(this.selector, fn);
  }
  filter({ hasText }) {
    assert.equal(typeof hasText, 'string');
    assert(!this.filterSpec, 'Unsupported repeated filter');
    return new Locator(this.page, this.selector, { text: hasText, exact: false });
  }
  async scrollIntoViewIfNeeded() { return this.use(handle => handle.scrollIntoView()); }
}

class Page {
  constructor(raw, context) {
    this.raw = raw; this.context = context; this.timeout = 6000;
    this.keyboard = {
      press: async key => {
        if (key !== 'ArrowDown' || process.platform !== 'darwin') return raw.keyboard.press(key);
        const select = await raw.evaluate(() => {
          const node = document.activeElement;
          if (!(node instanceof HTMLSelectElement) || node.multiple) return null;
          const options = Array.from(node.options).map(option => ({
            label: option.label, value: option.value, disabled: option.disabled
          }));
          let next = node.selectedIndex + 1;
          while (next < options.length && options[next].disabled) next++;
          return { id: node.id, current: node.selectedIndex, next, options };
        });
        if (!select) return raw.keyboard.press(key);
        assert(select.next < select.options.length, 'No forward native-select option for typeahead');
        const keyChar = select.options[select.next].label[0].toLowerCase();
        const firstMatch = select.options.findIndex(option =>
          !option.disabled && option.label.toLowerCase().startsWith(keyChar));
        assert.equal(firstMatch, select.next, 'Receiver requires an unambiguous first native typeahead match');
        await raw.evaluate(id => {
          globalThis.scopeCompareReceiverNativeKeyEvents = [];
          for (const type of ['keydown', 'input', 'change']) {
            document.addEventListener(type, event => {
              if (event.target.id === id) globalThis.scopeCompareReceiverNativeKeyEvents.push({
                type, key: event.key ?? null, trusted: event.isTrusted, value: event.target.value
              });
            }, { once: true, capture: true });
          }
        }, select.id);
        await raw.keyboard.press(keyChar);
        const observed = await raw.evaluate(() => ({
          id: document.activeElement.id, value: document.activeElement.value,
          events: globalThis.scopeCompareReceiverNativeKeyEvents
        }));
        note.keyboardAdaptations ??= [];
        note.keyboardAdaptations.push({
          requested: key, actual: keyChar,
          reason: 'Mac headless native select: verified typeahead, since arrow navigation also fails on a plain native select.',
          before: select, observed
        });
        assert.equal(observed.value, select.options[select.next].value);
        for (const type of ['keydown', 'input', 'change']) {
          assert(observed.events.some(event => event.type === type && event.trusted), 'Expected trusted ' + type);
        }
      }
    };
    this.request = {
      get: async url => {
        const parsed = new URL(url);
        assert.equal(parsed.hostname, '127.0.0.1');
        assert.equal(parsed.protocol, 'http:');
        const response = await fetch(url);
        await response.arrayBuffer();
        return { status: () => response.status };
      }
    };
  }
  locator(selector) { return new Locator(this, selector); }
  getByRole(role, options) {
    assert.equal(role, 'button');
    assert.equal(typeof options.name, 'string');
    return new Locator(this, 'button', { text: options.name, exact: Boolean(options.exact) });
  }
  async goto(url) { return this.raw.goto(url, { waitUntil: 'load' }); }
  async close() { return this.raw.close(); }
  url() { return this.raw.url(); }
  content() { return this.raw.content(); }
  screenshot(options) { return this.raw.screenshot(options); }
  evaluate(fn, ...args) { return this.raw.evaluate(fn, ...args); }
  async waitForFunction(fn, arg) {
    const handle = await this.raw.waitForFunction(fn, { timeout: this.timeout }, arg);
    await handle.dispose();
  }
  waitForTimeout(ms) { return sleep(ms); }
  setDefaultTimeout(ms) { this.timeout = ms; this.raw.setDefaultTimeout(ms); this.raw.setDefaultNavigationTimeout(ms); }
  setViewportSize(viewport) { return this.raw.setViewport(viewport); }
  on(name, fn) {
    assert.equal(name, 'pageerror');
    this.raw.on(name, fn);
  }
  async waitForEvent(name) {
    if (name === 'download') return this.context.nextDownload();
    if (name === 'filechooser') {
      const chooser = await this.raw.waitForFileChooser({ timeout: this.timeout });
      return { setFiles: paths => chooser.accept(paths) };
    }
    throw new Error('Unsupported page event: ' + name);
  }
}

class Context {
  constructor(browser, version, profile, options) {
    this.raw = browser; this.version = version; this.profile = profile; this.options = options;
    this.pages = new WeakMap(); this.pageHandlers = []; this.routeHandler = null;
    this.downloads = new Map(); this.downloadWaiters = []; this.downloadQueue = [];
  }
  browser() { return { version: () => this.version }; }
  async route(pattern, handler) { assert.equal(pattern, '**/*'); this.routeHandler = handler; }
  on(name, fn) { assert.equal(name, 'page'); this.pageHandlers.push(fn); }
  async wrap(raw) {
    if (this.pages.has(raw)) return this.pages.get(raw);
    const page = new Page(raw, this);
    this.pages.set(raw, page);
    await raw.setRequestInterception(true);
    raw.on('request', request => {
      const route = {
        request: () => ({ url: () => request.url(), frame: () => ({ url: () => request.frame()?.url() ?? raw.url() }) }),
        continue: () => request.continue(),
        abort: () => request.abort('blockedbyclient')
      };
      const handled = this.routeHandler ? this.routeHandler(route) : route.continue();
      Promise.resolve(handled).catch(error => {
        note.adapterErrors.push({ phase: 'request interception', message: error.message, url: request.url() });
        if (!request.isInterceptResolutionHandled()) request.abort('blockedbyclient').catch(() => {});
      });
    });
    for (const handler of this.pageHandlers) handler(page);
    return page;
  }
  async newPage() { return this.wrap(await this.raw.newPage()); }
  async waitForEvent(name) {
    assert.equal(name, 'page');
    const prior = new Set(this.raw.targets());
    const target = await this.raw.waitForTarget(target => target.type() === 'page' && !prior.has(target), { timeout: 6000 });
    const raw = await target.page();
    assert(raw, 'Expected native popup page');
    const page = await this.wrap(raw);
    const ready = await raw.waitForFunction(() => location.href !== 'about:blank', { timeout: 6000 });
    await ready.dispose();
    const url = raw.url();
    await raw.reload({ waitUntil: 'load' });
    note.popupReloads.push({ url, reason: 'Attach request guard before definitive page load; no file chosen yet.' });
    return page;
  }
  async configureDownloads() {
    this.session = await this.raw.target().createCDPSession();
    this.session.on('Browser.downloadWillBegin', event => {
      let finish;
      const done = new Promise(resolve => { finish = resolve; });
      const entry = { guid: event.guid, suggestedFilename: event.suggestedFilename, state: 'inProgress', done, finish };
      this.downloads.set(event.guid, entry);
      note.downloads.push({ guid: event.guid, suggestedFilename: event.suggestedFilename, url: event.url, state: 'inProgress' });
      const download = {
        suggestedFilename: () => entry.suggestedFilename,
        saveAs: async target => {
          await entry.done;
          assert.equal(entry.state, 'completed', 'Browser download did not complete');
          const source = resolve(this.options.downloadsPath, entry.guid);
          await copyFile(source, target);
          const record = note.downloads.find(item => item.guid === entry.guid);
          record.savedAs = target; record.sha256 = hash(await readFile(target));
        },
        failure: async () => { await entry.done; return entry.state === 'completed' ? null : 'Native download ' + entry.state; }
      };
      if (this.downloadWaiters.length) this.downloadWaiters.shift()(download);
      else this.downloadQueue.push(download);
    });
    this.session.on('Browser.downloadProgress', event => {
      const entry = this.downloads.get(event.guid);
      const record = note.downloads.find(item => item.guid === event.guid);
      if (record) Object.assign(record, { state: event.state, receivedBytes: event.receivedBytes, totalBytes: event.totalBytes });
      if (entry && (event.state === 'completed' || event.state === 'canceled')) {
        entry.state = event.state; entry.finish();
      }
    });
    await this.session.send('Browser.setDownloadBehavior', {
      behavior: 'allowAndName', downloadPath: this.options.downloadsPath, eventsEnabled: true
    });
  }
  nextDownload() {
    if (this.downloadQueue.length) return Promise.resolve(this.downloadQueue.shift());
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => reject(new Error('Native download event timeout')), 6000);
      this.downloadWaiters.push(value => { clearTimeout(timer); resolve(value); });
    });
  }
  async close() {
    clearTimeout(this.watchdog);
    try { await this.raw.close(); }
    finally { note.closedAt = new Date().toISOString(); await saveNote(); }
  }
}

export const chromium = {
  async launchPersistentContext(profile, options) {
    assert.equal(options.chromiumSandbox, true, 'Sandbox must remain enabled');
    assert.equal(options.headless, true);
    assert(options.downloadsPath, 'Use an explicit owned download directory');
    assert(!options.args.some(arg => /no-sandbox|disable.*sandbox/.test(arg)), 'Sandbox-disable argument refused');
    note.startedAt = new Date().toISOString(); note.profile = profile; note.options = options;
    let browser;
    try {
      browser = await puppeteer.launch({
        executablePath: options.executablePath, headless: true, userDataDir: profile,
        defaultViewport: options.viewport, args: options.args, timeout: options.timeout
      });
      note.spawnargs = browser.process()?.spawnargs ?? [];
      assert(!note.spawnargs.some(arg => /no-sandbox|disable.*sandbox/.test(arg)), 'Browser sandbox-disable argument refused');
      note.browserVersion = await browser.version();
      const context = new Context(browser, note.browserVersion, profile, options);
      await context.configureDownloads();
      context.watchdog = setTimeout(async () => {
        note.adapterErrors.push({ phase: 'watchdog', message: 'Bounded 150-second receiver deadline' });
        await browser.close().catch(() => {});
      }, 150000);
      return context;
    } catch (error) {
      note.adapterErrors.push({ phase: 'launch', message: error.stack });
      await browser?.close().catch(() => {});
      await saveNote();
      throw error;
    }
  }
};
