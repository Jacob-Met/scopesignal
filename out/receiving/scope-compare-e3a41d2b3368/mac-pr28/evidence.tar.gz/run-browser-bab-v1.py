from pathlib import Path
import os,subprocess,hashlib,json,time,platform,sys
r=Path('/Users/me/.hamon-rdc-seats/seat-5/hamon-e3a41d2b3368-scope-compare')
out=r/'browser-bab-v1'
out.mkdir(exist_ok=False)
(out/'tmp').mkdir()
manifest=json.loads((r/'BAB-RECEIVING-MANIFEST.json').read_text())
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
before={path:sha(r/path) for path in manifest['files']}
assert all(value==manifest['files'][path]['sha256'] for path,value in before.items())
adapter=r/'puppeteer-adapter-v2.mjs'
driver=r/'candidate-bab/scripts/check-scope-compare.mjs'
env=os.environ.copy()
env.update({
 'SCOPESIGNAL_SOURCE':str(r/'candidate-bab'),
 'SCOPESIGNAL_BASELINE':str(r/'baseline-bab'),
 'SCOPESIGNAL_EVIDENCE':str(out),
 'SCOPESIGNAL_PROFILE':str(out/'browser-profile'),
 'SCOPESIGNAL_PLAYWRIGHT':str(adapter),
 'SCOPESIGNAL_CHROME':'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
 'SCOPESIGNAL_SOURCE_COMMIT':'bab391c7c6fec1193e221997e4d66d89bd914cfd + root pinned comparison composition',
 'SCOPESIGNAL_ADAPTER_RECEIPT':str(out/'adapter-receipt.json'),
 'TMPDIR':str(out/'tmp')
})
env.pop('SCOPESIGNAL_RECEIVER_RESOURCE_LIMITS',None)
command=['/opt/homebrew/bin/node',str(driver)]
started=time.time()
runner={'schema':'scopesignal.mac-runner.v1','startedAt':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'parent':manifest['parent'],'macOS':platform.mac_ver()[0],'machine':platform.machine(),'python':sys.version,'pythonExecutable':sys.executable,'command':command,'sourceManifestSha256':sha(r/'BAB-RECEIVING-MANIFEST.json'),'driverSha256':sha(driver),'adapterSha256':sha(adapter),'sourceBefore':before}
(out/'runner-start.json').write_text(json.dumps(runner,indent=2)+'\n')
print(json.dumps({'started':True,'output':str(out),'driver':runner['driverSha256'],'adapter':runner['adapterSha256']}),flush=True)
try:
 with (out/'process.log').open('w') as log:
  result=subprocess.run(command,cwd=r/'candidate-bab',env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
 runner['returncode']=result.returncode
except subprocess.TimeoutExpired:
 runner['outerTimeout']=True
runner['elapsedSeconds']=round(time.time()-started,3)
runner['sourceAfter']={path:sha(r/path) for path in before}
runner['sourceUnchanged']=runner['sourceAfter']==before
runner['profileRemoved']=not (out/'browser-profile').exists()
runner['logSha256']=sha(out/'process.log')
if (out/'receipt.json').exists():
 receipt=json.loads((out/'receipt.json').read_text())
 runner['receiptSha256']=sha(out/'receipt.json')
 runner['passedGroups']=len(receipt.get('checks',[]))
 runner['passed']=bool(receipt.get('passed')) and runner.get('returncode')==0 and runner['sourceUnchanged']
 runner['failureSummary']=[x.get('error','')[:500] for x in receipt.get('failures',[])]
if (out/'adapter-receipt.json').exists(): runner['adapterReceiptSha256']=sha(out/'adapter-receipt.json')
(out/'runner.json').write_text(json.dumps(runner,indent=2)+'\n')
print(json.dumps({k:v for k,v in runner.items() if k not in ['sourceBefore','sourceAfter','python']}),flush=True)
