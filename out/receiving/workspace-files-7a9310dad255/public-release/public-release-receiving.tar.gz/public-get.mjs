import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import {execFileSync} from 'node:child_process';
const own='/home/jacob/.commander-tp-2/scopesignal-workspace-7a9310dad255';
const pin=JSON.parse(await fs.readFile(path.join(own,'public-release-pin.json'),'utf8'));
const out=path.join(own,'public-release');
await fs.mkdir(path.join(out,'served'),{recursive:true});await fs.mkdir(path.join(out,'headers'),{recursive:true});
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const git=b=>crypto.createHash('sha1').update('blob '+b.length+'\0').update(b).digest('hex');
const startedAt=new Date().toISOString(), rows=[];
for(const item of pin.files){
 const destination=path.join(out,'served',item.path),headers=path.join(out,'headers',item.path.replaceAll('/','__')+'.txt');
 await fs.mkdir(path.dirname(destination),{recursive:true});
 const url=pin.publicBase+item.path;
 try{
 const output=execFileSync('curl',['--fail','--silent','--show-error','--location','--proto','=https','--tlsv1.2','--max-time','25','--dump-header',headers,'--output',destination,'--write-out','%{http_code}\t%{url_effective}\t%{ssl_verify_result}\t%{remote_ip}\t%{http_version}',url],{encoding:'utf8',timeout:30000});
 const [status,finalUrl,sslVerifyResult,remoteIp,httpVersion]=output.split('\t');const bytes=await fs.readFile(destination);const observed=git(bytes);
 rows.push({...item,url,status:Number(status),finalUrl,sslVerifyResult:Number(sslVerifyResult),remoteIp,httpVersion,observedBytes:bytes.length,observedGitBlob:observed,sha256:sha(bytes),matches:observed===item.gitBlob&&bytes.length===item.bytes});
 }catch(error){rows.push({...item,url,error:String(error.message),stderr:String(error.stderr||'')});}
}
const receipt={schema:'scopesignal.public-https-runtime-receiving.v1',startedAt,completedAt:new Date().toISOString(),merge:pin.merge,tree:pin.tree,workflow:pin.workflow,transport:'Native curl with default certificate verification; no insecure flag, trust override, proxy override or cache-busting URL.',curlVersion:execFileSync('curl',['--version'],{encoding:'utf8'}).split('\n')[0],files:rows,passed:rows.filter(x=>x.matches&&x.status===200&&x.sslVerifyResult===0).length};
await fs.writeFile(path.join(out,'https-receipt.json'),JSON.stringify(receipt,null,2)+'\n');
console.log(JSON.stringify({out,passed:receipt.passed,total:rows.length,failures:rows.filter(x=>!x.matches||x.status!==200||x.sslVerifyResult!==0)}));
if(receipt.passed!==rows.length)process.exitCode=1;
