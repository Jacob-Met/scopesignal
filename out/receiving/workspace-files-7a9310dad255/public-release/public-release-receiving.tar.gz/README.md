# ScopeSignal — actual public Pages receiving

Receiver: estate-7a9310dad255 / production. Completed 2026-10-08 at 12:31:48 UTC.

## Accepted boundaries

Source integration: PR18 merged as 8a241c9ce409fa9b22ab0bbdc339e46fd4b38525, with tree 7686f7568c398f522df4d32f75a98814b1c4cd1d. Root independently verified both current-parent composition and preservation.

Automatic deployment: the unchanged Fixture-mode Pages deployment workflow completed successfully for that exact merge. Run 37774089051 began at 12:02:26Z and finished at 12:03:14Z. Test job 113300491678 and deploy job 113300541847 both succeeded. No workflow edit, manual dispatch, forced deployment or publication mutation was made for this receiving.

Served source: all twenty published runtime HTML, CSS and JavaScript files returned HTTP 200 from https://jacobmetoyer.com/scopesignal/ and matched the merge's Git blobs and byte lengths exactly. Native curl used its normal HTTPS certificate verification, without an insecure flag or trust/proxy override; each verification result was 0. Full response bodies and headers are retained.

Served behavior: the actual public page https://jacobmetoyer.com/scopesignal/scope.html passed three bounded behavior groups plus the runtime/source boundary group. Native Chromium 153.0.8010.47 and Node 22.22.1 ran for 14.184 seconds, using an isolated empty profile. Twenty-four actual browser response bodies (eight authoring runtime files over three loads) matched the exact merged source before actions and navigation. There was no local HTTP substitute, application source injection, synthetic File/Blob read hook, certificate override, provider call, or real payment action.

## Observed product behavior

1. An unfinished two-checkpoint draft was authored using normal text input and downloaded through the focused native button. Its Unicode, outer whitespace and incomplete money strings remained exact. After reload, choosing the actual downloaded file displayed an explicit preview without replacing current work; Cancel retained that work, and a subsequent explicit Replace restored the draft. Ordinary review validation continued to refuse the incomplete draft.
2. A three-checkpoint mixed review was authored through current UI controls. Its ten canonical events included one unknown capture after duplicate handling, a captured second checkpoint, and pending Unicode evidence for the third. The real downloaded file restored the exact canonical review after reload, preserving current work until explicit replacement.
3. The next explicit reconciliation appended the expected eleventh event and changed simulated captured money from 30000 to 42525 cents. A third actual download matched the already frozen canonical continuation fixture.

These are three live behavior groups, plus one source/runtime group; this is not a claim that the earlier full fifteen-group independent suite was repeated on the public site. That broader source receiving remains in the immutable PR18 proof archive.

Actual disk downloads:
- desktop-unfinished-draft.json: 587 bytes, SHA-256 87b3c83d01dfd1b1752cba21566e23115653df1933fcb147015078700b515439.
- desktop-review-unknown.json: 3293 bytes, SHA-256 4adf5ec896a243110fed8b386954873e0c37d0312fbe7a7ecb9beca3128f69f2.
- desktop-review-reconciled.json: 3528 bytes, SHA-256 5d349835049421b9ba633fcd6d3ac6823f8df73fd0a61afb6daea1143b719fd2.

## Independent fixtures and receiving mechanism

The three expected behavior groups, canonical values and real native pointer/keyboard/file/download plumbing come from runtime's already frozen independent receiver v4, SHA-256 eaba9123995effdc9221a7f46319f0f707443e9108c31ac7454c52d433b75f9c. The public derivative changes only the served URL/source audit, removal of the local HTTP fixture and synthetic read hooks, bounded case selection, runtime-version metadata and receipt attribution. Its final SHA256 is 7cb5d2090a37415316bfd2fef2eef5493e726ae390e48176a474f39d44de7295. The exact derivation is retained.

All 45 independent fixture files were verified before and after. Their original complete archive is immutable at:
https://github.com/Jacob-Met/scopesignal/blob/b74539fc8662f66a5a557dcefdaafd12615deae4/out/receiving/workspace-files-7a9310dad255/browser-receiving.tar.gz
The archive SHA256 is dc53e97a53c2b4b486a81679c26957577dafc68e13f92f743fb7af0ebd1e2d0d. This packet references that full fixture corpus rather than rewriting the authored expectations.

## Preserved infrastructure attempts

Attempt 1 completed zero groups and loaded no application page: the Chromium Snap could not create its isolated profile's SingletonLock at the first storage location. A separate about:blank probe reproduced the exact permission denial. The receiving profile and download path were moved to an ordinary owned home directory; no permissions or Snap controls were changed.

Attempt 2 completed zero groups and loaded no page: Chromium's standalone --version wrapper exceeded its 15-second deadline. The successful attempt obtains Browser.getVersion from the actual launched Chromium process. No fixture, application bytes or assertions changed.

The original two receipts, neutral startup diagnostic and narrow metadata correction are retained separately. They are setup failures, not source or behavior failures.

## Visual and cleanup checks

Both live screenshots were inspected: the replacement preview clearly preserves the existing form underneath, and the restored review displays the unknown capture, its explicit lookup action, accepted evidence, exact totals and history context. The inherited Google Fonts request was deliberately blocked by the existing receiver network boundary, so screenshots use fallback fonts. All application requests were GET; there were no application exceptions or CDP errors.

The successful run closed its own browser and left an empty receiving profile directory. No local HTTP server was created. A postflight process check found no owned public receiving process. This qualifies the actual native desktop/public-site boundary; the earlier full proof separately qualifies phone layouts and broader file/refusal/race cases.
