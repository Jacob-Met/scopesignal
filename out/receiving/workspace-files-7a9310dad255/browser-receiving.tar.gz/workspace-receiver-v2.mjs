import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import fs from 'node:fs/promises';
import http from 'node:http';
import path from 'node:path';
import { spawn, execFileSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const [kind, sourceArg, manifestArg, evidenceArg] = process.argv.slice(2);
if (!['baseline', 'candidate'].includes(kind) || !sourceArg || !manifestArg || !evidenceArg) throw Error('Use baseline|candidate SOURCE MANIFEST EVIDENCE');
const own = path.dirname(fileURLToPath(import.meta.url));
const source = path.resolve(sourceArg), evidence = path.resolve(evidenceArg);
const fixtureRoot = path.join(own, 'frozen-fixtures');
const readJSON = async filename => JSON.parse(await fs.readFile(filename, 'utf8'));
const fixtures = Object.fromEntries(await Promise.all(['unfinished-draft', 'review-ready', 'review-unknown-mixed', 'review-next-reconciled', 'replacement-draft', 'legacy-fixed-record', 'expected-model', 'refusal-index'].map(async name => [name, await readJSON(path.join(fixtureRoot, name + '.json'))])));
const expected = fixtures['expected-model'];
const sourceManifest = await readJSON(manifestArg);
const fixtureManifest = await readJSON(path.join(own, 'fixture-manifest.json'));
const chromium = process.env.SCOPE_RECEIVING_CHROMIUM || '/snap/bin/chromium';
const profileRoot = process.env.SCOPE_RECEIVING_PROFILE_ROOT;
if (!profileRoot) throw Error('Set a unique native Chromium profile namespace');
const sha = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
const delay = ms => new Promise(resolve => setTimeout(resolve, ms));
const money = cents => new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(cents / 100);
await fs.mkdir(evidence, { recursive: true });
await fs.mkdir(path.join(evidence, 'downloads'), { recursive: true });
await fs.mkdir(profileRoot, { recursive: true });
const profile = await fs.mkdtemp(path.join(profileRoot, 'workspace-'));
const checks = [], downloads = [], requests = [], blocked = [], responses = [], exceptions = [], captures = [], wireErrors = [], pointerTargets = [];
const pending = new Map();
let browser, socket, session, server, nextId = 0, mode = null, fatal = null, browserVersion = null;
const startedAt = new Date().toISOString();

function send(method, params = {}, sessionId = session) {
  const id = ++nextId;
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => { pending.delete(id); reject(Error('CDP timeout: ' + method)); }, 15000);
    pending.set(id, { resolve, reject, timer, method });
    socket.send(JSON.stringify({ id, method, params, ...(sessionId ? { sessionId } : {}) }));
  });
}
async function evaluate(expression) {
  const result = await send('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: true });
  if (result.exceptionDetails) throw Error(result.exceptionDetails.exception?.description || result.exceptionDetails.text);
  return result.result.value;
}
async function until(expression) {
  const deadline = Date.now() + 15000;
  while (Date.now() < deadline) {
    if (await evaluate(expression)) return;
    await delay(60);
  }
  throw Error('Expected browser state not reached: ' + expression);
}
async function settle() {
  await evaluate('new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve)))');
}
async function group(name, fn) {
  try { checks.push({ name: `${mode || kind}.${name}`, passed: true, observed: await fn() }); }
  catch (error) { checks.push({ name: `${mode || kind}.${name}`, passed: false, failure: error.stack || String(error) }); throw error; }
  await fs.writeFile(path.join(evidence, 'observations.json'), JSON.stringify(checks, null, 2) + '\n');
}
async function click(selector, keyboard = false) {
  if (keyboard) {
    await evaluate(`(()=>{const e=document.querySelector(${JSON.stringify(selector)});if(!e||e.disabled)throw Error('Missing/disabled keyboard target');e.scrollIntoView({block:'center',behavior:'instant'});e.focus();})()`);
    await send('Input.dispatchKeyEvent', { type: 'keyDown', key: 'Enter', code: 'Enter', windowsVirtualKeyCode: 13 });
    await send('Input.dispatchKeyEvent', { type: 'keyUp', key: 'Enter', code: 'Enter', windowsVirtualKeyCode: 13 });
    return;
  }
  await evaluate(`(()=>{const e=document.querySelector(${JSON.stringify(selector)});if(!e||e.disabled)throw Error('Missing/disabled pointer target');e.scrollIntoView({block:'center',behavior:'instant'});})()`);
  await settle();
  const point = await evaluate(`(()=>{const e=document.querySelector(${JSON.stringify(selector)});const r=e.getBoundingClientRect();const x=r.x+r.width/2,y=r.y+r.height/2;return{x,y,viewport:{width:innerWidth,height:innerHeight},hitTarget:e.contains(document.elementFromPoint(x,y))}})()`);
  pointerTargets.push({ mode, selector, ...point });
  assert.ok(point.hitTarget, 'Pointer center must hit the intended visible control: ' + selector);
  await send('Input.dispatchMouseEvent', { type: 'mousePressed', button: 'left', clickCount: 1, x: point.x, y: point.y });
  await send('Input.dispatchMouseEvent', { type: 'mouseReleased', button: 'left', clickCount: 1, x: point.x, y: point.y });
}
async function fill(selector, text) {
  await evaluate(`(()=>{const e=document.querySelector(${JSON.stringify(selector)});if(!e||e.readOnly||e.disabled)throw Error('Missing/noneditable text field');e.scrollIntoView({block:'center',behavior:'instant'});e.focus();e.select();})()`);
  await send('Input.insertText', { text });
  assert.equal(await evaluate(`document.querySelector(${JSON.stringify(selector)}).value`), text);
}
async function fileInput(name) {
  await until("document.readyState==='complete'&&!!document.querySelector('#scope-open')");
  const doc = await send('DOM.getDocument');
  const node = await send('DOM.querySelector', { nodeId: doc.root.nodeId, selector: '#scope-open' });
  assert.ok(node.nodeId, 'Native file input exists');
  await send('DOM.setFileInputFiles', { nodeId: node.nodeId, files: [path.join(fixtureRoot, name)] });
  await settle();
}
async function filePathInput(filename) {
  const doc = await send('DOM.getDocument');
  const node = await send('DOM.querySelector', { nodeId: doc.root.nodeId, selector: '#scope-open' });
  await send('DOM.setFileInputFiles', { nodeId: node.nodeId, files: [filename] });
  await settle();
}
const previewVisible = `(()=>{const e=document.querySelector('#scope-open-preview');return !!e&&!e.hidden&&getComputedStyle(e).display!=='none'&&e.getBoundingClientRect().height>0})()`;
async function status() { return evaluate("document.querySelector('#scope-file-status')?.textContent||''"); }
async function state() {
  return evaluate(`({stage:document.querySelector('#scope-form').hidden?'review':'draft',draft:{label:document.querySelector('#scope-label').value,brief:document.querySelector('#scope-brief').value,cap:document.querySelector('#scope-cap').value,checkpoints:[...document.querySelectorAll('.scope-row')].map(e=>({title:e.querySelector('[data-field=title]').value,amount:e.querySelector('[data-field=amount]').value,evidence:e.querySelector('[data-field=evidence]').value}))},review:{title:document.querySelector('#review-title').textContent,brief:document.querySelector('#review-brief').textContent,cap:document.querySelector('#scope-total').textContent,approved:document.querySelector('#scope-approved').textContent,captured:document.querySelector('#scope-captured').textContent,remaining:document.querySelector('#scope-remaining').textContent,unallocated:document.querySelector('#scope-unallocated').textContent,editDisabled:document.querySelector('#scope-edit').disabled,cards:[...document.querySelectorAll('.scope-review-card')].map(e=>({id:e.dataset.checkpoint,title:e.querySelector('h3').textContent,evidence:e.querySelector('textarea').value,readonly:e.querySelector('textarea').readOnly,actions:[...e.querySelectorAll('button[data-action]')].map(b=>b.dataset.action),capture:e.querySelector('.scope-review-state strong').textContent,receipts:e.querySelector('.scope-receipt-ids')?.textContent||''})),events:[...document.querySelectorAll('#scope-event-body tr')].map(e=>[...e.querySelectorAll('td')].map(c=>c.textContent))},origin:document.querySelector('#scope-file-origin')?.textContent||''})`);
}
async function shot(name, selector) {
  if (selector) await evaluate(`document.querySelector(${JSON.stringify(selector)}).scrollIntoView({block:'start',behavior:'instant'})`);
  await settle();
  const result = await send('Page.captureScreenshot', { format: 'png', captureBeyondViewport: false });
  const filename = `${mode}-${name}.png`;
  await fs.writeFile(path.join(evidence, filename), Buffer.from(result.data, 'base64'));
  captures.push(filename);
}
async function layout(name) {
  const observed = await evaluate(`({viewport:innerWidth,document:document.documentElement.scrollWidth,controls:[...document.querySelectorAll('#scope-save,#scope-open,#scope-open-apply,#scope-open-cancel,#scope-file-status,#scope-open-summary,.scope-fields input,.scope-fields textarea,.scope-evidence')].filter(e=>e.getBoundingClientRect().width>0).map(e=>{const r=e.getBoundingClientRect();return{id:e.id,x:r.x,right:r.right,width:r.width,scroll:e.scrollWidth,client:e.clientWidth}})})`);
  assert.ok(observed.document <= observed.viewport + 1, 'The page must not overflow horizontally');
  for (const control of observed.controls) assert.ok(control.x >= -1 && control.right <= observed.viewport + 1, 'Control outside page: ' + JSON.stringify(control));
  await shot(name);
  return observed;
}
async function fillDraft(value) {
  assert.equal((await state()).stage, 'draft');
  let count = await evaluate("document.querySelectorAll('.scope-row').length");
  while (count < value.checkpoints.length) { await click('#scope-add'); count++; await until(`document.querySelectorAll('.scope-row').length===${count}`); }
  while (count > value.checkpoints.length) { await click(`button[data-remove="${count - 1}"]`); count--; await until(`document.querySelectorAll('.scope-row').length===${count}`); }
  for (const key of ['label', 'brief', 'cap']) await fill('#scope-' + key, value[key]);
  for (let index = 0; index < value.checkpoints.length; index++) for (const key of ['title', 'amount', 'evidence']) await fill(`#draft-${index}-${key}`, value.checkpoints[index][key]);
  assert.deepEqual((await state()).draft, value);
}
async function reviewDraft() {
  await click('#scope-form button[type=submit]');
  await until("!document.querySelector('#scope-review').hidden");
}
async function act(id, action) {
  await click(`button[data-checkpoint="${id}"][data-action="${action}"]`);
  await settle();
  assert.equal(await evaluate("document.querySelector('#scope-action-status').classList.contains('error')"), false);
}
async function previewFile(name) {
  await fileInput(name);
  await until(previewVisible);
  return evaluate("document.querySelector('#scope-open-summary').textContent");
}
async function applyPreview(keyboard = false) {
  assert.equal(await evaluate(previewVisible), true);
  await click('#scope-open-apply', keyboard);
  await until('!' + previewVisible);
  await settle();
  assert.ok((await state()).origin.trim().length > 0, 'Opened unsigned fixture must show its origin notice');
}
async function restore(name, keyboard = false) { await previewFile(name); await applyPreview(keyboard); }
async function cancelPreview(keyboard = false) {
  await click('#scope-open-cancel', keyboard);
  await until('!' + previewVisible);
}
async function download(label, selector = '#scope-save', keyboard = false) {
  const count = downloads.length;
  await click(selector, keyboard);
  const deadline = Date.now() + 15000;
  while (Date.now() < deadline && !downloads.slice(count).some(item => item.state === 'completed')) await delay(60);
  const item = downloads.slice(count).find(item => item.state === 'completed');
  assert.ok(item, 'Actual browser download must complete');
  assert.equal(item.suggestedFilename, selector === '#scope-save' ? 'scopesignal-workspace-v1.json' : 'scopesignal-fixture-record-v1.json');
  const bytes = await fs.readFile(path.join(evidence, 'downloads', item.guid));
  const text = new TextDecoder('utf-8', { fatal: true }).decode(bytes);
  const value = JSON.parse(text);
  const filename = `${mode}-${label}.json`;
  await fs.rename(path.join(evidence, 'downloads', item.guid), path.join(evidence, filename));
  Object.assign(item, { savedAs: filename, bytes: bytes.length, sha256: sha(bytes) });
  return { value, filename: path.join(evidence, filename), sha256: sha(bytes), bytes: bytes.length };
}
function assertReview(actual, model, record) {
  assert.equal(actual.stage, 'review');
  assert.deepEqual(actual.draft, record.draft);
  assert.equal(actual.review.title, model.plan.label); assert.equal(actual.review.brief, model.plan.brief);
  assert.equal(actual.review.cap, money(model.plan.amount)); assert.equal(actual.review.approved, `${model.approved} / ${model.checkpoints.length}`);
  assert.equal(actual.review.captured, money(model.captured)); assert.equal(actual.review.remaining, money(model.remaining));
  assert.ok(actual.review.unallocated.includes(money(model.unallocated)));
  assert.equal(actual.review.editDisabled, model.events.length > 0);
  assert.equal(actual.review.events.length, model.events.length);
  assert.deepEqual(actual.review.events.map(row => row[2]), model.events.map(event => event.type));
  assert.deepEqual(actual.review.cards.map(card => card.id), model.checkpoints.map(cp => cp.id));
  for (let index = 0; index < model.checkpoints.length; index++) {
    const cp = model.checkpoints[index], card = actual.review.cards[index];
    assert.equal(card.title, cp.title); assert.equal(card.readonly, cp.approved);
    assert.equal(card.evidence, cp.approved ? cp.acceptedEvidence : record.evidenceDrafts.find(row => row.checkpointId === cp.id)?.text ?? cp.evidence);
    assert.deepEqual(card.actions, cp.actions);
    assert.equal(card.capture, `Capture state: ${cp.captureStatus === 'not_started' ? 'not started' : cp.captureStatus}`);
  }
}
async function installReadControls() {
  await evaluate(`(()=>{window.receiverReadControls={modes:{},calls:[],waiting:[]};for(const method of ['text','arrayBuffer']){const original=Blob.prototype[method];Blob.prototype[method]=function(...args){const name=this instanceof File?this.name:null;const mode=name&&window.receiverReadControls.modes[name];if(mode){window.receiverReadControls.calls.push({name,method,mode});if(mode==='reject')return Promise.reject(new Error('Receiver synthetic byte-read failure'));const promise=original.apply(this,args);return promise.then(value=>new Promise(resolve=>window.receiverReadControls.waiting.push({name,resolve:()=>resolve(value)})));}return original.apply(this,args);};}})()`);
}
async function hold(name) { await evaluate(`window.receiverReadControls.modes[${JSON.stringify(name)}]='hold'`); }
async function selectHeld(name) {
  await hold(name);
  const before = await evaluate('window.receiverReadControls.calls.length');
  await fileInput(name);
  await until(`window.receiverReadControls.calls.length>${before}&&window.receiverReadControls.waiting.some(item=>item.name===${JSON.stringify(name)})`);
}
async function release(name) {
  await evaluate(`(()=>{delete window.receiverReadControls.modes[${JSON.stringify(name)}];const waiting=window.receiverReadControls.waiting.filter(item=>item.name===${JSON.stringify(name)});window.receiverReadControls.waiting=window.receiverReadControls.waiting.filter(item=>item.name!==${JSON.stringify(name)});for(const item of waiting)item.resolve();})()`);
  await settle(); await delay(100);
}
async function verifySource() {
  for (const row of sourceManifest.source_files) assert.equal(sha(await fs.readFile(path.join(source, row.path))), row.sha256, row.path);
  for (const row of fixtureManifest.files) assert.equal(sha(await fs.readFile(path.join(fixtureRoot, row.path))), row.sha256, row.path);
}
async function delivered() {
  const expectedHashes = new Map(sourceManifest.source_files.map(row => [row.path, row.sha256]));
  const result = [];
  for (const response of responses.filter(row => row.session === session && row.url.startsWith(origin + '/'))) {
    const relative = decodeURIComponent(new URL(response.url).pathname.slice(1));
    if (!expectedHashes.has(relative)) continue;
    const body = await send('Network.getResponseBody', { requestId: response.requestId });
    response.sha256 = sha(Buffer.from(body.body, body.base64Encoded ? 'base64' : 'utf8'));
    assert.equal(response.sha256, expectedHashes.get(relative), 'Delivered source ' + relative);
    result.push(relative);
  }
  assert.ok(result.includes('src/scope-workspace.mjs') || result.includes('app.mjs'));
  return result;
}
let origin;
async function openPage(name, width, height, page = 'scope.html') {
  mode = name;
  const target = await send('Target.createTarget', { url: 'about:blank' }, null);
  session = (await send('Target.attachToTarget', { targetId: target.targetId, flatten: true }, null)).sessionId;
  await send('Runtime.enable'); await send('Page.enable'); await send('Network.enable');
  await send('Fetch.enable', { patterns: [{ urlPattern: '*', requestStage: 'Request' }] });
  await send('Emulation.setDeviceMetricsOverride', { width, height, deviceScaleFactor: 1, mobile: width < 500 });
  await send('Page.navigate', { url: `${origin}/${page}` });
  await until(page === 'scope.html' ? "document.readyState==='complete'&&document.querySelectorAll('.scope-row').length>0" : "document.readyState==='complete'&&document.querySelectorAll('#ledger-body tr').length===7");
  return { target: target.targetId, session };
}
async function closePage(target) { await delivered(); await send('Target.closeTarget', { targetId: target.target }, null); session = undefined; }

async function baselineRun() {
  const target = await openPage('baseline-desktop', 1360, 1000);
  await group('capability_absence_and_reload_loss', async () => {
    const controls = await evaluate("({save:!!document.querySelector('#scope-save'),open:!!document.querySelector('#scope-open')})");
    assert.deepEqual(controls, { save: false, open: false });
    await fillDraft(expected.unfinished);
    const before = await state();
    await shot('authored-before-reload', '#scope-form');
    await send('Page.reload', { ignoreCache: true });
    await until("document.readyState==='complete'&&document.querySelectorAll('.scope-row').length===3");
    const after = await state();
    assert.notDeepEqual(after.draft, before.draft);
    assert.equal(after.stage, 'draft'); assert.equal(after.review.events.length, 0);
    return { controls, before, after, qualification: 'One missing capability witness; no attempt to count every new action as a baseline failure.' };
  });
  await closePage(target);
}
async function coreRoundTrip(name, width, height) {
  const target = await openPage(name, width, height);
  await installReadControls();
  let savedDraft;
  await group('unfinished_actual_download_preview_cancel_apply', async () => {
    await until("!!document.querySelector('#scope-save')&&!!document.querySelector('#scope-open')");
    await fillDraft(expected.unfinished);
    const before = await state();
    savedDraft = await download('unfinished-draft', '#scope-save', true);
    assert.deepEqual(savedDraft.value, fixtures['unfinished-draft']); assert.deepEqual(await state(), before);
    await send('Page.reload', { ignoreCache: true });
    await until("document.readyState==='complete'&&document.querySelectorAll('.scope-row').length===3");
    await installReadControls();
    const clean = await state();
    await filePathInput(savedDraft.filename); await until(previewVisible);
    const preview = await evaluate("document.querySelector('#scope-open-summary').textContent");
    assert.ok(preview.includes(expected.unfinished.label.trim())); assert.match(preview.toLowerCase(), /draft/); assert.match(preview, /2/);
    assert.deepEqual(await state(), clean);
    await shot('unfinished-preview', '#scope-open-preview');
    await cancelPreview(true); assert.deepEqual(await state(), clean);
    await filePathInput(savedDraft.filename); await until(previewVisible); await applyPreview(true);
    assert.equal((await state()).stage, 'draft'); assert.deepEqual((await state()).draft, expected.unfinished);
    await click('#scope-form button[type=submit]');
    assert.equal((await state()).stage, 'draft'); assert.equal(await evaluate("document.querySelector('#scope-errors').hidden"), false);
    assert.deepEqual((await state()).draft, expected.unfinished);
    const accessibility = await evaluate("({openLabel:[...document.querySelectorAll('label[for=scope-open]')].map(e=>e.textContent),saveText:document.querySelector('#scope-save').textContent,saveTab:document.querySelector('#scope-save').tabIndex,openTab:document.querySelector('#scope-open').tabIndex})");
    assert.ok(accessibility.openLabel.join('').trim()); assert.ok(accessibility.saveTab >= 0 && accessibility.openTab >= 0);
    return { actualDownload: savedDraft, preview, restored: await state(), accessibility };
  });
  await group('authored_mixed_review_and_real_restore', async () => {
    await fillDraft(expected.plan); await reviewDraft();
    await fill('#review-evidence-scope-3', expected.pendingC);
    for (const [id, action, text] of expected.steps) { if (text !== undefined) await fill('#review-evidence-' + id, text); await act(id, action); }
    const authored = await state(); assertReview(authored, expected.beforeReconciliation, fixtures['review-unknown-mixed']);
    const saved = await download('review-unknown'); assert.deepEqual(saved.value, fixtures['review-unknown-mixed']); assert.deepEqual(await state(), authored);
    await send('Page.reload', { ignoreCache: true });
    await until("document.readyState==='complete'&&document.querySelectorAll('.scope-row').length===3");
    await installReadControls();
    const clean = await state(); await filePathInput(saved.filename); await until(previewVisible);
    const preview = await evaluate("document.querySelector('#scope-open-summary').textContent");
    assert.ok(preview.includes(expected.plan.label.trim())); assert.match(preview.toLowerCase(), /review/); assert.match(preview, /10/);
    assert.deepEqual(await state(), clean); await applyPreview(true);
    const restored = await state(); assertReview(restored, expected.beforeReconciliation, saved.value);
    await shot('unknown-restored', '#scope-review');
    return { actualDownload: saved, preview, restored };
  });
  await group('next_explicit_action_and_frozen_model_equivalence', async () => {
    const before = await state(); assertReview(before, expected.beforeReconciliation, fixtures['review-unknown-mixed']);
    await act('scope-1', 'reconcile');
    const after = await state(); assertReview(after, expected.afterReconciliation, fixtures['review-next-reconciled']);
    assert.equal(await evaluate("!!document.querySelector('button[data-checkpoint=scope-1][data-action=reconcile]')"), false);
    const saved = await download('review-reconciled'); assert.deepEqual(saved.value, fixtures['review-next-reconciled']); assert.deepEqual(await state(), after);
    return { before, after, actualDownload: saved };
  });
  if (name === 'desktop') {
    await group('complete_workspace_preserved_by_real_file_refusals', async () => {
      const before = await state(); const results = [];
      for (const filename of [...fixtures['refusal-index'].files, 'legacy-fixed-record.json']) {
        await fileInput(filename);
        await until(`!${previewVisible}&&document.querySelector('#scope-file-status').textContent.trim().length>0&&!/reading|validating|opening/i.test(document.querySelector('#scope-file-status').textContent)`);
        const message = await status(); assert.ok(message.trim()); assert.equal(await evaluate(previewVisible), false); assert.deepEqual(await state(), before, filename);
        results.push({ filename, status: message });
      }
      const saved = await download('after-refusals'); assert.deepEqual(saved.value, fixtures['review-next-reconciled']);
      return { refused: results, retained: before, actualDownload: saved };
    });
    await group('exact_one_mebibyte_admission_and_over_limit_refusal', async () => {
      const before = await state(); await previewFile('draft-exact-byte-limit.json'); assert.deepEqual(await state(), before); await applyPreview();
      assert.deepEqual((await state()).draft, expected.unfinished);
      const restored = await state(); await fileInput('refuse-over-byte-limit.json'); await until(`!${previewVisible}&&!/reading|validating|opening/i.test(document.querySelector('#scope-file-status').textContent)`); assert.deepEqual(await state(), restored);
      return { admittedBytes: 1048576, refusedBytes: 1048577, restored, status: await status() };
    });
    await group('unapproved_review_edits_return_to_draft', async () => {
      await restore('review-ready.json'); const before = await state();
      assert.equal(before.review.events.length, 0); assert.equal(before.review.editDisabled, false);
      assert.equal(before.review.cards[0].evidence, fixtures['review-ready'].evidenceDrafts[0].text); assert.equal(before.review.cards[2].evidence, '');
      await click('#scope-edit');
      const after = await state(); assert.equal(after.stage, 'draft');
      assert.equal(after.draft.checkpoints[0].evidence, fixtures['review-ready'].evidenceDrafts[0].text); assert.equal(after.draft.checkpoints[2].evidence, '');
      return { before, after };
    });
    await group('delayed_real_reads_newer_selection_cancel_and_read_error', async () => {
      await restore('unfinished-draft.json');
      const before = await state(); await selectHeld('review-ready.json');
      const newerPreview = await previewFile('replacement-draft.json'); assert.ok(newerPreview.includes('Receiver replacement Δ')); assert.deepEqual(await state(), before);
      await release('review-ready.json'); assert.equal(await evaluate("document.querySelector('#scope-open-summary').textContent"), newerPreview); await applyPreview(); assert.deepEqual((await state()).draft, fixtures['replacement-draft'].draft);
      const replaced = await state(); await selectHeld('review-ready.json'); await cancelPreview(true); await release('review-ready.json'); assert.equal(await evaluate(previewVisible), false); assert.deepEqual(await state(), replaced);
      await evaluate("window.receiverReadControls.modes['review-ready.json']='reject'");
      await fileInput('review-ready.json'); await until(`!${previewVisible}&&!/reading|validating|opening/i.test(document.querySelector('#scope-file-status').textContent)`); assert.deepEqual(await state(), replaced);
      await evaluate("delete window.receiverReadControls.modes['review-ready.json']");
      return { latestSelection: replaced, readCalls: await evaluate('window.receiverReadControls.calls'), syntheticReadFailureStatus: await status() };
    });
    await group('every_current_work_mutation_invalidates_pending_or_preview', async () => {
      const observed = [];
      async function exercise(label, initial, prepare, mutate) {
        await restore(initial);
        await prepare();
        await mutate();
        const newer = await state();
        await release('replacement-draft.json');
        assert.equal(await evaluate(previewVisible), false, label + ' has no applicable stale preview');
        assert.deepEqual(await state(), newer, label + ' preserves newer work');
        observed.push({ label, retained: newer });
      }
      const pendingRead = () => selectHeld('replacement-draft.json');
      const readyPreview = () => previewFile('replacement-draft.json');
      await exercise('pending-draft-text', 'unfinished-draft.json', pendingRead, () => fill('#scope-label', 'A newer draft edit Ω'));
      await exercise('preview-draft-text', 'unfinished-draft.json', readyPreview, () => fill('#scope-brief', 'New brief after preview\nKeep me.'));
      await exercise('pending-row-add', 'unfinished-draft.json', pendingRead, () => click('#scope-add'));
      await exercise('preview-row-remove', 'unfinished-draft.json', readyPreview, () => click('button[data-remove="1"]'));
      await restore('review-ready.json'); await click('#scope-edit');
      await fill('#draft-2-evidence', 'Filled so ordinary review is valid.');
      await selectHeld('replacement-draft.json'); await reviewDraft();
      let newer = await state(); await release('replacement-draft.json'); assert.equal(await evaluate(previewVisible), false); assert.deepEqual(await state(), newer); observed.push({ label: 'pending-enter-review', retained: newer });
      await exercise('pending-return-to-draft', 'review-ready.json', pendingRead, () => click('#scope-edit'));
      await exercise('pending-evidence-edit', 'review-ready.json', pendingRead, () => fill('#review-evidence-scope-3', 'New evidence after read start Ω'));
      await exercise('preview-approval', 'review-ready.json', readyPreview, () => act('scope-1', 'approve'));
      await exercise('pending-reconciliation', 'review-unknown-mixed.json', pendingRead, () => act('scope-1', 'reconcile'));
      return observed;
    });
    await group('download_preparation_failure_then_actual_retry', async () => {
      await restore('review-unknown-mixed.json'); const before = await state(), count = downloads.length;
      await evaluate("window.receiverOriginalObjectURL=URL.createObjectURL;URL.createObjectURL=()=>{throw Error('Receiver synthetic object-URL failure')}");
      await click('#scope-save'); await settle(); assert.deepEqual(await state(), before); assert.equal(downloads.length, count); const message = await status(); assert.ok(message.trim());
      await evaluate('URL.createObjectURL=window.receiverOriginalObjectURL');
      const saved = await download('after-download-retry'); assert.deepEqual(saved.value, fixtures['review-unknown-mixed']); assert.deepEqual(await state(), before);
      return { syntheticFailureStatus: message, actualRetry: saved };
    });
  } else {
    await group('phone_refusal_and_responsive_controls', async () => {
      const before = await state(); await fileInput('refuse-payment-claim.json'); await until(`!${previewVisible}&&!/reading|validating|opening/i.test(document.querySelector('#scope-file-status').textContent)`); assert.deepEqual(await state(), before);
      const phone = await layout('phone-390');
      await send('Emulation.setDeviceMetricsOverride', { width: 320, height: 900, deviceScaleFactor: 1, mobile: true });
      const narrow = await layout('phone-320');
      return { phone, narrow, retained: before };
    });
  }
  await closePage(target);
}
async function legacyRun() {
  const target = await openPage('legacy-current', 1360, 1000, 'index.html');
  await group('existing_fixed_record_actual_download', async () => {
    const before = await evaluate("({events:document.querySelector('#ledger-count').textContent,captured:document.querySelector('#captured').textContent,accepted:document.querySelector('#evidence-journey').value,readonly:document.querySelector('#evidence-journey').readOnly})");
    assert.equal(before.events, '7 events'); assert.equal(before.captured, '$400.00'); assert.equal(before.readonly, true);
    const record = await download('fixed-fixture-record', '#export-record'); assert.deepEqual(record.value, fixtures['legacy-fixed-record']);
    const after = await evaluate("({events:document.querySelector('#ledger-count').textContent,captured:document.querySelector('#captured').textContent,accepted:document.querySelector('#evidence-journey').value,readonly:document.querySelector('#evidence-journey').readOnly})");
    assert.deepEqual(after, before);
    return { before, actualDownload: record };
  });
  await closePage(target);
}

try {
  await verifySource();
  server = http.createServer(async (request, response) => {
    const url = new URL(request.url, 'http://127.0.0.1');
    if (url.pathname === '/favicon.ico') { response.writeHead(204); response.end(); return; }
    const relative = decodeURIComponent(url.pathname).replace(/^\/+/, '') || 'index.html';
    const filename = path.resolve(source, relative);
    if (!filename.startsWith(source + path.sep)) { response.writeHead(403); response.end(); return; }
    try { const data = await fs.readFile(filename); response.writeHead(200, { 'content-type': ({ '.html': 'text/html; charset=utf-8', '.mjs': 'application/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.json': 'application/json; charset=utf-8' })[path.extname(filename)] || 'application/octet-stream', 'cache-control': 'no-store' }); response.end(data); }
    catch { response.writeHead(404); response.end(); }
  });
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  origin = `http://127.0.0.1:${server.address().port}`;
  browserVersion = execFileSync(chromium, ['--version'], { encoding: 'utf8', timeout: 15000 }).trim();
  browser = spawn(chromium, ['--headless=new', '--disable-gpu', '--no-first-run', '--no-default-browser-check', '--disable-background-networking', '--disable-component-update', '--disable-sync', '--disable-extensions', '--password-store=basic', '--remote-debugging-address=127.0.0.1', '--remote-debugging-port=0', `--user-data-dir=${profile}`, 'about:blank'], { stdio: ['ignore', 'ignore', 'pipe'] });
  const endpoint = await new Promise((resolve, reject) => {
    let stderr = '';
    const timer = setTimeout(() => reject(Error('Chromium startup timeout: ' + stderr.slice(-2000))), 15000);
    browser.on('error', error => { clearTimeout(timer); reject(error); });
    browser.on('exit', code => { clearTimeout(timer); reject(Error('Chromium exited ' + code)); });
    browser.stderr.on('data', bytes => { stderr += bytes; const match = stderr.match(/DevTools listening on (ws:\/\/127\.0\.0\.1:[^\s]+)/); if (match) { clearTimeout(timer); resolve(match[1]); } });
  });
  socket = new WebSocket(endpoint);
  await new Promise((resolve, reject) => { socket.addEventListener('open', resolve, { once: true }); socket.addEventListener('error', reject, { once: true }); });
  socket.addEventListener('message', event => {
    const message = JSON.parse(event.data);
    if (message.id && pending.has(message.id)) { const item = pending.get(message.id); pending.delete(message.id); clearTimeout(item.timer); if (message.error) item.reject(Error(item.method + ': ' + JSON.stringify(message.error))); else item.resolve(message.result); }
    if (message.method === 'Runtime.exceptionThrown') exceptions.push({ mode, session: message.sessionId, text: message.params.exceptionDetails.exception?.description || message.params.exceptionDetails.text });
    if (message.method === 'Network.requestWillBeSent') requests.push({ mode, url: message.params.request.url, method: message.params.request.method });
    if (message.method === 'Network.responseReceived') responses.push({ mode, session: message.sessionId, url: message.params.response.url, requestId: message.params.requestId, status: message.params.response.status });
    if (message.method === 'Fetch.requestPaused') {
      const request = message.params.request, url = new URL(request.url);
      const allowed = url.origin === origin || ['about:', 'data:', 'blob:'].includes(url.protocol);
      if (!allowed) blocked.push({ mode, url: request.url, method: request.method, inheritedFont: ['fonts.googleapis.com', 'fonts.gstatic.com'].includes(url.hostname) });
      send(allowed ? 'Fetch.continueRequest' : 'Fetch.failRequest', { requestId: message.params.requestId, ...(allowed ? {} : { errorReason: 'BlockedByClient' }) }, message.sessionId).catch(error => wireErrors.push(String(error)));
    }
    if (message.method === 'Browser.downloadWillBegin') downloads.push({ mode, ...message.params });
    if (message.method === 'Browser.downloadProgress') { const item = downloads.find(download => download.guid === message.params.guid); if (item) Object.assign(item, message.params); }
  });
  await send('Browser.setDownloadBehavior', { behavior: 'allowAndName', downloadPath: path.join(evidence, 'downloads'), eventsEnabled: true }, null);
  if (kind === 'baseline') await baselineRun();
  else { await coreRoundTrip('desktop', 1360, 1000); await coreRoundTrip('phone', 390, 900); await legacyRun(); }
  mode = null;
  await group('source_delivery_errors_and_network_boundary', async () => {
    await verifySource(); assert.deepEqual(exceptions, []); assert.deepEqual(wireErrors, []);
    assert.deepEqual(blocked.filter(item => !item.inheritedFont), []);
    assert.deepEqual(requests.filter(item => item.method !== 'GET'), []);
    return { sourceFilesVerified: sourceManifest.source_files.length, fixtureFilesVerified: fixtureManifest.files.length, blockedInheritedFonts: blocked, requests: requests.length, delivered: responses.filter(row => row.sha256).map(row => ({ url: row.url, sha256: row.sha256 })) };
  });
} catch (error) {
  fatal = error.stack || String(error);
  if (socket?.readyState === 1 && session) { try { await shot('failure'); } catch {} }
} finally {
  if (socket?.readyState === 1) { try { await send('Browser.close', {}, null); } catch {} socket.close(); }
  if (browser && browser.exitCode === null) browser.kill('SIGTERM');
  if (server) { server.closeAllConnections(); await new Promise(resolve => server.close(resolve)); }
  for (const item of pending.values()) clearTimeout(item.timer);
  await delay(150); await fs.rm(profile, { recursive: true, force: true });
  const receipt = { schema: 'scopesignal.workspace-independent-browser-receiving.v1', kind, startedAt, completedAt: new Date().toISOString(), source, manifestSha256: sha(await fs.readFile(manifestArg)), runnerSha256: sha(await fs.readFile(fileURLToPath(import.meta.url))), casesSha256: sha(await fs.readFile(path.join(own, 'receiving-cases.json'))), fixtureManifestSha256: sha(await fs.readFile(path.join(own, 'fixture-manifest.json'))), publicContractSha256: sha(await fs.readFile(path.join(own, 'public-contract.md'))), chromium: browserVersion, node: process.version, checks, downloads, captures, requests, responses, blocked, exceptions, wireErrors, pointerTargets, fatal, cleanup: { ownServerClosed: !server?.listening, ownProfileRemoved: true }, qualification: 'Actual native Chromium and current-source DOM, pointer/keyboard input, native file admission and downloaded bytes. Transport race/failure hooks are explicit synthetic controls over otherwise real files. No owner source/cache/ref, user profile, provider, or live payment action.' };
  await fs.writeFile(path.join(evidence, 'browser-receipt.json'), JSON.stringify(receipt, null, 2) + '\n');
}
const failed = checks.filter(check => !check.passed).map(check => check.name);
console.log(JSON.stringify({ kind, passed: checks.length - failed.length, failed, fatal, evidence }));
if (fatal || failed.length) process.exitCode = 1;
