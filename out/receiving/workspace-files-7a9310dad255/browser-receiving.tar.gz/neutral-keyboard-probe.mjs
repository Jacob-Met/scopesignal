import fs from 'node:fs/promises';
import { spawn } from 'node:child_process';
import assert from 'node:assert/strict';
const root='/home/jacob/hamon-7a9310dad255-runtime-scopesignal';
const profile=await fs.mkdtemp('/home/jacob/snap/chromium/common/hamon-7a9310dad255-runtime-scopesignal/keyboard-neutral-');
const pending=new Map();let id=0,socket,session,browser;const observations=[];
function send(method,params={},sid=session){const n=++id;return new Promise((resolve,reject)=>{const timer=setTimeout(()=>{pending.delete(n);reject(Error('Timeout '+method));},10000);pending.set(n,{resolve,reject,timer});socket.send(JSON.stringify({id:n,method,params,...(sid?{sessionId:sid}:{})}));});}
async function ev(expression){const r=await send('Runtime.evaluate',{expression,returnByValue:true,awaitPromise:true});if(r.exceptionDetails)throw Error(JSON.stringify(r.exceptionDetails));return r.result.value;}
try {
 browser=spawn('/snap/bin/chromium',['--headless=new','--disable-gpu','--no-first-run','--no-default-browser-check','--disable-background-networking','--disable-component-update','--disable-sync','--disable-extensions','--password-store=basic','--remote-debugging-address=127.0.0.1','--remote-debugging-port=0','--user-data-dir='+profile,'about:blank'],{stdio:['ignore','ignore','pipe']});
 const endpoint=await new Promise((resolve,reject)=>{let text='';const timer=setTimeout(()=>reject(Error('startup timeout')),15000);browser.stderr.on('data',x=>{text+=x;const m=text.match(/DevTools listening on (ws:\/\/127\.0\.0\.1:[^\s]+)/);if(m){clearTimeout(timer);resolve(m[1]);}});browser.on('error',reject);});
 socket=new WebSocket(endpoint);await new Promise((resolve,reject)=>{socket.addEventListener('open',resolve,{once:true});socket.addEventListener('error',reject,{once:true});});
 socket.addEventListener('message',event=>{const m=JSON.parse(event.data),p=pending.get(m.id);if(p){pending.delete(m.id);clearTimeout(p.timer);m.error?p.reject(Error(JSON.stringify(m.error))):p.resolve(m.result);}});
 const t=await send('Target.createTarget',{url:'about:blank'},null);session=(await send('Target.attachToTarget',{targetId:t.targetId,flatten:true},null)).sessionId;
 await send('Runtime.enable');await send('Page.enable');
 await ev(`document.body.innerHTML='<button id="neutral" type="button">Neutral button</button>';window.clicks=0;window.events=[];for(const type of ['keydown','keypress','keyup','click'])document.querySelector('button').addEventListener(type,e=>{events.push({type:e.type,key:e.key,code:e.code,trusted:e.isTrusted});if(e.type==='click')clicks++});document.querySelector('button').focus();`);
 const sequences=[
  {name:'receiver_v3_no_text',down:{type:'keyDown',key:'Enter',code:'Enter',windowsVirtualKeyCode:13},up:{type:'keyUp',key:'Enter',code:'Enter',windowsVirtualKeyCode:13}},
  {name:'native_enter_with_text',down:{type:'keyDown',key:'Enter',code:'Enter',windowsVirtualKeyCode:13,text:'\r',unmodifiedText:'\r'},up:{type:'keyUp',key:'Enter',code:'Enter',windowsVirtualKeyCode:13}}
 ];
 for(const s of sequences){await ev('clicks=0;events=[];document.querySelector("button").focus()');await send('Input.dispatchKeyEvent',s.down);await send('Input.dispatchKeyEvent',s.up);await ev('new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r)))');observations.push({name:s.name,sequence:{down:s.down,up:s.up},observed:await ev('({clicks,events,focus:document.activeElement.id})')});}
 assert.equal(observations[0].observed.clicks,0);assert.equal(observations[1].observed.clicks,1);
 const result={schema:'scopesignal.receiver-neutral-keyboard-probe.v1',completedAt:new Date().toISOString(),qualification:'Receiver transport isolation on an authored plain native HTML button in about:blank; no ScopeSignal source loaded.',observations};await fs.writeFile(root+'/neutral-keyboard-result.json',JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result));
}finally{if(socket?.readyState===1){try{await send('Browser.close',{},null);}catch{}socket.close();}if(browser&&browser.exitCode===null)browser.kill('SIGTERM');for(const p of pending.values())clearTimeout(p.timer);await new Promise(r=>setTimeout(r,150));await fs.rm(profile,{recursive:true,force:true});}
