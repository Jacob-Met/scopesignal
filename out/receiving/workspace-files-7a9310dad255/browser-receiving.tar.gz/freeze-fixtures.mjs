import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createScopeReview, validateScopeDraft } from './baseline/src/scope-plan.mjs';
import { replayFixture } from './baseline/src/ledger.mjs';
import { createFixtureRecord } from './baseline/src/fixture-record.mjs';

const own = path.dirname(fileURLToPath(import.meta.url));
const out = path.join(own, 'frozen-fixtures');
await fs.mkdir(out, { recursive: true });
const sha = data => crypto.createHash('sha256').update(data).digest('hex');
const save = async (name, value) => fs.writeFile(path.join(out, name), typeof value === 'object' && !Buffer.isBuffer(value) ? JSON.stringify(value, null, 2) + '\n' : value);
const constants = { schema: 'scopesignal.scope-workspace', version: 1, fixtureOnly: true, paymentEvidence: false };
const unfinished = {
  label: '  Unfinished “studio” α  ',
  brief: 'First line\n\n Second line: <b>literal</b> & "quoted" \\ draft  ',
  cap: '',
  checkpoints: [
    { title: '  Rough concept  ', amount: '1.', evidence: '\n Draft evidence Ω\nSecond line  ' },
    { title: '', amount: 'USD 2', evidence: '' }
  ]
};
assert.equal(validateScopeDraft(unfinished).ok, false);
const plan = {
  label: '  Aurora “mosaic” / review α  ',
  brief: 'Design a fictional exhibit.\nKeep <b>literal markup</b>, “quotes”, and a \\ path.  ',
  cap: ' 1250.75 ',
  checkpoints: [
    { title: '  Concept α  ', amount: '00125.25', evidence: 'Planned first acceptance\nShow the two alternatives.' },
    { title: 'Layout β', amount: ' 300.00 ', evidence: 'Planned second acceptance\nMeasure the layout.' },
    { title: 'Handoff γ', amount: '75.50', evidence: 'Planned final acceptance\nKeep source files readable.' }
  ]
};
assert.equal(validateScopeDraft(plan).ok, true);
const acceptedA = '  Approved α\nCompare “A” and "B"; <b>literal</b> \\ path.  ';
const acceptedB = '\nReviewed β: layout evidence\nSecond line.  ';
const pendingC = '  Pending γ\nDo not approve this draft. <b>literal</b> & \\ Ω  ';
const steps = [
  ['scope-1', 'approve', acceptedA], ['scope-1', 'order'], ['scope-1', 'request'],
  ['scope-1', 'lose'], ['scope-1', 'receipt'], ['scope-1', 'duplicate'],
  ['scope-2', 'approve', acceptedB], ['scope-2', 'order'], ['scope-2', 'request'], ['scope-2', 'receipt']
];
const model = createScopeReview(plan);
for (const step of steps) model.act(...step);
const unknown = model.snapshot();
assert.equal(unknown.events.length, 10);
assert.equal(unknown.approved, 2); assert.equal(unknown.captured, 30000);
assert.equal(unknown.total, 50075); assert.equal(unknown.remaining, 20075); assert.equal(unknown.unallocated, 75000);
assert.equal(unknown.checkpoints[0].captureStatus, 'unknown');
assert.equal(unknown.checkpoints[0].acceptedEvidence, acceptedA.trim());
assert.deepEqual(unknown.checkpoints[0].actions, ['reconcile']);
assert.deepEqual(unknown.checkpoints[1].actions, ['duplicate']);
assert.deepEqual(unknown.checkpoints[2].actions, ['approve']);
const review = { ...constants, stage: 'review', draft: plan, events: unknown.events, evidenceDrafts: [{ checkpointId: 'scope-3', text: pendingC }] };
const next = model.act('scope-1', 'reconcile');
assert.equal(next.events.length, 11); assert.equal(next.captured, 42525); assert.equal(next.remaining, 7550);
assert.equal(next.checkpoints[0].captureStatus, 'captured'); assert.deepEqual(next.checkpoints[0].actions, []);
await save('unfinished-draft.json', { ...constants, stage: 'draft', draft: unfinished, events: [], evidenceDrafts: [] });
await save('review-ready.json', { ...constants, stage: 'review', draft: plan, events: [], evidenceDrafts: [{ checkpointId: 'scope-1', text: '\nUnapproved first edit α  ' }, { checkpointId: 'scope-3', text: '' }] });
await save('review-unknown-mixed.json', review);
await save('review-next-reconciled.json', { ...review, events: next.events });
await save('replacement-draft.json', { ...constants, stage: 'draft', draft: { ...unfinished, label: 'Receiver replacement Δ', brief: 'A newer file must win.\nNothing is approved.' }, events: [], evidenceDrafts: [] });
await save('legacy-fixed-record.json', createFixtureRecord(replayFixture().events));
await save('expected-model.json', { baselineCommit: '8e50105fdc1645720e64ca83738727473c9f6acf', plan, unfinished, steps, acceptedA, acceptedB, canonicalAcceptedA: acceptedA.trim(), canonicalAcceptedB: acceptedB.trim(), pendingC, beforeReconciliation: unknown, afterReconciliation: next, manualMoneyAssertions: { cap: 125075, allocated: 50075, unallocated: 75000, beforeCaptured: 30000, beforeRemaining: 20075, afterCaptured: 42525, afterRemaining: 7550 } });

const mutations = [
  ['wrong-schema', x => { x.schema = 'scopesignal.fixture-record'; }],
  ['future-version', x => { x.version = 2; }],
  ['fixture-false', x => { x.fixtureOnly = false; }],
  ['payment-claim', x => { x.paymentEvidence = true; }],
  ['extra-top-field', x => { x.savedApproval = true; }],
  ['missing-top-field', x => { delete x.evidenceDrafts; }],
  ['unknown-stage', x => { x.stage = 'captured'; }],
  ['draft-with-history', x => { x.stage = 'draft'; }],
  ['numeric-raw-amount', x => { x.draft.checkpoints[0].amount = 125.25; }],
  ['invalid-reviewed-plan', x => { x.draft.cap = '1.'; }],
  ['unknown-draft-field', x => { x.draft.approved = true; }],
  ['unknown-checkpoint-field', x => { x.draft.checkpoints[0].id = 'other'; }],
  ['null-checkpoint', x => { x.draft.checkpoints[1] = null; }],
  ['zero-checkpoints', x => { x.draft.checkpoints = []; }],
  ['thirteen-checkpoints', x => { x.draft.checkpoints = Array.from({ length: 13 }, () => structuredClone(x.draft.checkpoints[0])); }],
  ['label-utf16-limit', x => { x.draft.label = '🙂'.repeat(61); }],
  ['raw-cap-limit', x => { x.draft.cap = '0'.repeat(64) + '1'; }],
  ['noncanonical-sequence', x => { x.events[1].seq = 3; }],
  ['noncanonical-time', x => { x.events[1].at = 'T+999'; }],
  ['noncanonical-order', x => { x.events[1].orderId = 'ORDER-OTHER'; }],
  ['wrong-event-amount', x => { x.events[4].amount += 1; }],
  ['wrong-currency', x => { x.events[4].currency = 'EUR'; }],
  ['wrong-environment', x => { x.events[1].environment = 'live'; }],
  ['wrong-duplicate-fact', x => { x.events[5].duplicate = false; }],
  ['unreachable-first-event', x => { x.events = [structuredClone(x.events[1])]; x.events[0].seq = 1; x.events[0].at = 'T+001'; }],
  ['event-extra-field', x => { x.events[0].paid = true; }],
  ['noncanonical-accepted-text', x => { x.events[0].acceptedEvidence = ' ' + x.events[0].acceptedEvidence; }],
  ['too-many-events', x => { x.events = Array.from({ length: 97 }, () => structuredClone(x.events[0])); }],
  ['pending-for-approved', x => { x.evidenceDrafts = [{ checkpointId: 'scope-1', text: 'Replace an accepted fact' }]; }],
  ['duplicate-pending-id', x => { x.evidenceDrafts.push(structuredClone(x.evidenceDrafts[0])); }],
  ['unknown-pending-id', x => { x.evidenceDrafts[0].checkpointId = 'scope-99'; }],
  ['pending-text-limit', x => { x.evidenceDrafts[0].text = 'a'.repeat(5001); }],
  ['pending-extra-field', x => { x.evidenceDrafts[0].approved = true; }]
];
const refusalFiles = [];
for (const [name, change] of mutations) {
  const value = structuredClone(review); change(value);
  const filename = `refuse-${name}.json`; await save(filename, value); refusalFiles.push(filename);
}
await save('refuse-malformed.json', '{"schema":'); refusalFiles.push('refuse-malformed.json');
const plainDraft = JSON.stringify({ ...constants, stage: 'draft', draft: unfinished, events: [], evidenceDrafts: [] });
const invalidUTF8 = Buffer.concat([Buffer.from(plainDraft.slice(0, plainDraft.indexOf('Unfinished'))), Buffer.from([255]), Buffer.from(plainDraft.slice(plainDraft.indexOf('Unfinished') + 'Unfinished'.length))]);
await save('refuse-invalid-utf8.json', invalidUTF8); refusalFiles.push('refuse-invalid-utf8.json');
const exactLimit = Buffer.concat([Buffer.from(plainDraft), Buffer.alloc(1024 * 1024 - Buffer.byteLength(plainDraft), 32)]);
await save('draft-exact-byte-limit.json', exactLimit);
await save('refuse-over-byte-limit.json', Buffer.concat([exactLimit, Buffer.from(' ')])); refusalFiles.push('refuse-over-byte-limit.json');
await save('refusal-index.json', { files: refusalFiles, description: 'Each real file must refuse atomically while a populated workspace and pending evidence remain intact. Canonical history comes from the unchanged public baseline model, never the new codec.' });
const files = (await fs.readdir(out)).sort();
const rows = [];
for (const name of files) { const bytes = await fs.readFile(path.join(out, name)); rows.push({ path: name, bytes: bytes.length, sha256: sha(bytes) }); }
await fs.writeFile(path.join(own, 'fixture-manifest.json'), JSON.stringify({ frozenAt: new Date().toISOString(), phase: 'Before reading any workspace save/open candidate implementation', baselineManifestSha256: sha(await fs.readFile(path.join(own, 'baseline-manifest.json'))), publicContractSha256: sha(await fs.readFile(path.join(own, 'public-contract.md'))), generatorSha256: sha(await fs.readFile(fileURLToPath(import.meta.url))), files: rows }, null, 2) + '\n');
console.log(JSON.stringify({ fixtures: rows.length, refusalFiles: refusalFiles.length, beforeEvents: unknown.events.length, afterEvents: next.events.length, beforeCaptured: unknown.captured, afterCaptured: next.captured }));
