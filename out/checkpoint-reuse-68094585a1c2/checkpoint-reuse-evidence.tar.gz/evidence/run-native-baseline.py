from pathlib import Path
import subprocess,json,hashlib,time
r=Path('/tmp/hamon-scopesignal-checkpoint-import-68094585a1c2')
m=json.loads((r/'baseline-input-map.json').read_text())
def pins():
 out=[]
 for x in m['inputs']:
  b=(r/'baseline'/x['path']).read_bytes()
  blob=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
  assert len(b)==x['bytes'] and blob==x['git_blob'],x['path']
  out.append(dict(x,sha256=hashlib.sha256(b).hexdigest()))
 return out
before=pins()
jobs=[
 ('original-native-tests',['node','--test','tests/scope-plan.test.mjs','tests/scope-workspace-record.test.mjs','tests/scope-revision-draft.test.mjs','tests/workspace-form-values.test.mjs'],r/'baseline'),
 ('original-native-producer',['node',str(r/'evidence'/'produce-original-source.mjs')],r)
]
executions=[]
for name,cmd,cwd in jobs:
 start=time.time()
 with (r/'evidence'/(name+'.stdout.log')).open('wb') as out,(r/'evidence'/(name+'.stderr.log')).open('wb') as err:
  p=subprocess.run(cmd,cwd=cwd,stdout=out,stderr=err,timeout=30)
 e={'name':name,'command':cmd,'cwd':str(cwd),'returncode':p.returncode,'elapsedSeconds':time.time()-start}
 executions.append(e);print(json.dumps(e),flush=True)
 if p.returncode:break
receipt={'source':{'parent':m['parent'],'tree':m['tree']},'before':before,'after':pins(),'executions':executions,'unsupportedNodeFloorDisclosure':'Installed22.22.1 baseline; repository declares>=24. No supported-release runtime claim.'}
(r/'evidence'/'baseline-native-execution.json').write_text(json.dumps(receipt,indent=2)+'\n')
assert all(x['returncode']==0 for x in executions)
