import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { createScopeReview, validateScopeDraft } from '../baseline/src/scope-plan.mjs';
import { encodeScopeWorkspace, decodeScopeWorkspace } from '../baseline/src/scope-workspace-record.mjs';
import { createScopeRevisionDraft } from '../baseline/src/scope-revision-draft.mjs';
const root=path.resolve(import.meta.dirname,'..');
const out=path.join(root,'evidence','native-baseline');
fs.mkdirSync(out,{recursive:true});
const draft={label:'Saved editorial package — fictional',brief:'Original source brief.\nDo not replace the new project.',cap:'0500.00',checkpoints:[
 {title:'  Rough <layout> & proof  ',amount:'00125.50',evidence:'Original proof line 1\nOriginal line 2'},
 {title:'Caption & localization',amount:'25.00',evidence:'Planned caption evidence'},
 {title:'Delivery package',amount:'010.00',evidence:'Original archive and manifest'}
]};
assert.equal(validateScopeDraft(draft).ok,true);
const review=createScopeReview(draft);
review.act('scope-1','approve','ACCEPTED review text: distinct from the planned source');
review.act('scope-1','order');
review.act('scope-1','request');
review.act('scope-1','lose');
const pending=new Map([['scope-2','PENDING review note: do not copy as planned evidence']]);
const raw=encodeScopeWorkspace({draft,review,evidenceDrafts:pending});
const decoded=decodeScopeWorkspace(raw);
assert.deepEqual(decoded.draft,draft);
assert.equal(decoded.review.snapshot().checkpoints[0].acceptedEvidence,'ACCEPTED review text: distinct from the planned source');
assert.equal(decoded.evidenceDrafts.get('scope-2'),'PENDING review note: do not copy as planned evidence');
assert.equal(decoded.review.snapshot().checkpoints[0].captureStatus,'unknown');
const revision=createScopeRevisionDraft({draft,review,evidenceDrafts:pending});
const rd=decodeScopeWorkspace(revision);
assert.deepEqual(rd.draft,draft);
assert.equal(rd.review,null);assert.equal(rd.evidenceDrafts.size,0);
assert.equal(rd.draft.checkpoints.length,3);
fs.writeFileSync(path.join(out,'reviewed-source.json'),raw);
fs.writeFileSync(path.join(out,'whole-revision.json'),revision);
const receipt={sourceParent:'847505d2fe9f8295110fc13a3fb9e05ec71f6644',node:process.version,declaredMinimum:'24',qualification:'Original native baseline on installed Node22; not the supported Node24 release gate.',assertions:8,producer:'Unmodified createScopeReview / encodeScopeWorkspace / createScopeRevisionDraft',draft,review:decoded.review.snapshot(),pending:[...decoded.evidenceDrafts],files:[['reviewed-source.json',raw],['whole-revision.json',revision]].map(([name,s])=>({name,bytes:Buffer.byteLength(s),sha256:createHash('sha256').update(s).digest('hex')})),missingFlow:'Revision export copies all three definitions and existing file open replaces the workspace as a whole. Selected checkpoint append is absent.'};
fs.writeFileSync(path.join(out,'receipt.json'),JSON.stringify(receipt,null,2)+'\n');
console.log(JSON.stringify({pass:true,assertions:8,files:receipt.files}));
