import fs from 'node:fs';
import path from 'node:path';
import http from 'node:http';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { createRequire } from 'node:module';
const require=createRequire(import.meta.url);
const puppeteer=require('/home/jacob/.local/lib/node_modules/@wonderwhy-er/desktop-commander/node_modules/puppeteer/lib/puppeteer/puppeteer.js');
const root='/tmp/hamon-scopesignal-checkpoint-import-68094585a1c2';
const source=path.join(root,'baseline');
const out=path.join(root,'evidence','browser-baseline-v2-remaining');
const browserArea='/home/jacob/hamon-scopesignal-checkpoint-import-68094585a1c2';
const profile=path.join(browserArea,'baseline-profile-v2');
const downloads=path.join(browserArea,'baseline-downloads-v2');
for(const p of [out,profile,downloads])fs.mkdirSync(p,{recursive:true});
const sourceRaw=fs.readFileSync(path.join(root,'evidence/native-baseline/reviewed-source.json'));
const sourceFile=path.join(browserArea,'reviewed-source.json');fs.writeFileSync(sourceFile,sourceRaw);
const sha=b=>createHash('sha256').update(b).digest('hex');
const inputs=JSON.parse(fs.readFileSync(path.join(root,'baseline-input-map.json'),'utf8'));
const pins=()=>inputs.inputs.map(row=>{const b=fs.readFileSync(path.join(source,row.path));const blob=createHash('sha1').update('blob '+b.length+'\0').update(b).digest('hex');assert.equal(blob,row.git_blob,row.path);return {path:row.path,bytes:b.length,gitBlob:blob,sha256:sha(b)};});
const receipt={parent:inputs.parent,tree:inputs.tree,node:process.version,puppeteer:'25.12.0',installedChrome:'/snap/bin/chromium',declaredNodeFloor:'>=24; this installed22 run is baseline only',started:new Date().toISOString(),sourceBefore:pins(),groups:[],served:[],externalBlocked:[],pageErrors:[],consoleErrors:[],downloads:[],negative:null};
const types={'.html':'text/html','.mjs':'text/javascript','.css':'text/css','.json':'application/json'};
let browser,server;
const wait=async(fn,ms=8000)=>{const end=Date.now()+ms;while(Date.now()<end){const v=await fn();if(v)return v;await new Promise(r=>setTimeout(r,40));}throw new Error('Timed out waiting for baseline boundary');};
try{
 server=http.createServer((req,res)=>{
  const url=new URL(req.url,'http://127.0.0.1');
  let rel;try{rel=decodeURIComponent(url.pathname).replace(/^\/+/,'')||'scope.html';}catch{res.writeHead(400);res.end();return;}
  const file=path.resolve(source,rel);
  if(!file.startsWith(source+path.sep)||!fs.existsSync(file)||!fs.statSync(file).isFile()){res.writeHead(404);res.end();return;}
  const b=fs.readFileSync(file);receipt.served.push({path:rel,bytes:b.length,sha256:sha(b)});
  res.writeHead(200,{'Content-Type':types[path.extname(file)]||'application/octet-stream','Cache-Control':'no-store'});res.end(b);
 });
 await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
 const origin='http://127.0.0.1:'+server.address().port;
 browser=await puppeteer.launch({executablePath:'/snap/bin/chromium',headless:true,userDataDir:profile,timeout:20000,args:['--no-sandbox','--disable-dev-shm-usage','--disable-background-networking','--disable-component-update','--no-first-run']});
 receipt.browserVersion=await browser.version();
 const page=await browser.newPage();await page.setViewport({width:1280,height:1000});
 await page.setRequestInterception(true);
 page.on('request',req=>{if(req.url().startsWith(origin+'/')||req.url().startsWith('data:')||req.url().startsWith('blob:'))req.continue();else{receipt.externalBlocked.push(req.url());req.abort();}});
 page.on('pageerror',error=>receipt.pageErrors.push(String(error)));
 page.on('console',msg=>{if(msg.type()==='error')receipt.consoleErrors.push(msg.text());});
 const cdp=await page.createCDPSession();
 await cdp.send('Browser.setDownloadBehavior',{behavior:'allow',downloadPath:downloads,eventsEnabled:true});
 await page.goto(origin+'/scope.html',{waitUntil:'networkidle0',timeout:15000});
 await page.waitForSelector('#draft-2-evidence',{timeout:5000});
 const read=()=>page.evaluate(()=>({label:document.querySelector('#scope-label').value,brief:document.querySelector('#scope-brief').value,cap:document.querySelector('#scope-cap').value,checkpoints:[...document.querySelectorAll('.scope-row')].map(row=>({title:row.querySelector('[data-field=title]').value,amount:row.querySelector('[data-field=amount]').value,evidence:row.querySelector('[data-field=evidence]').value}))}));
 await page.evaluate(()=>{
  const changes={'#scope-label':'New brief — keep <draft> & details','#scope-brief':'Current project line one\nUnfinished local instructions','#scope-cap':'','#draft-0-title':'New first deliverable','#draft-0-amount':'not set','#draft-0-evidence':''};
  for(const [sel,value]of Object.entries(changes)){const el=document.querySelector(sel);el.value=value;el.dispatchEvent(new Event('input',{bubbles:true}));}
 });
 const current=await read();
 const input=await page.$('#scope-open');await input.uploadFile(sourceFile);
 await page.waitForFunction(()=>!document.querySelector('#scope-open-preview').hidden,{timeout:5000});
 assert.deepEqual(await read(),current);
 await page.click('#scope-open-apply');
 assert.equal(await page.$eval('#scope-form',el=>el.hidden),true);
 const opened=await read();assert.deepEqual(opened,JSON.parse(sourceRaw).draft);
 assert.equal(await page.$eval('#scope-event-count',el=>el.textContent),'4 events');
 assert.equal(await page.$eval('#scope-approved',el=>el.textContent),'1 / 3');
 assert.equal(await page.$eval('#scope-captured',el=>el.textContent),'$0.00');
 await page.click('#scope-save');
 const downloaded=await wait(()=>fs.readdirSync(downloads).find(x=>x.endsWith('.json')));
 const reopened=fs.readFileSync(path.join(downloads,downloaded));assert.deepEqual(reopened,sourceRaw);
 fs.writeFileSync(path.join(out,'opened-review-download.json'),reopened);receipt.downloads.push({file:'opened-review-download.json',bytes:reopened.length,sha256:sha(reopened)});
 receipt.groups.push({name:'Remaining original whole-source replacement and exact native download',pass:true,opened,events:4,approved:1,captured:'$0.00'});
 const controls=await page.$$eval('button,input[type=file]',els=>els.map(el=>({tag:el.tagName,id:el.id,type:el.type,text:el.textContent.trim()})));
 receipt.negative={capability:'Selected saved-checkpoint append',expectedAbsent:true,entryCount:controls.filter(el=>/Add selected checkpoints|Reuse saved checkpoints|Import checkpoints/.test(el.text)).length,observed:'The original explicit Replace workspace changed the entire project and restored its approvals/events. No selected checkpoint append control exists.',controls};
 assert.equal(receipt.negative.entryCount,0);
 assert.equal(receipt.pageErrors.length,0);
 receipt.pass=true;
}catch(error){receipt.pass=false;receipt.error={name:error.name,message:error.message,stack:error.stack};process.exitCode=1;}
finally{
 if(browser)await browser.close().catch(error=>receipt.closeError=String(error));
 if(server)await new Promise(resolve=>server.close(resolve));
 receipt.sourceAfter=pins();receipt.finished=new Date().toISOString();
 fs.writeFileSync(path.join(out,'receipt.json'),JSON.stringify(receipt,null,2)+'\n');
 console.log(JSON.stringify({pass:receipt.pass,groups:receipt.groups.map(x=>x.name),negative:receipt.negative&&{entryCount:receipt.negative.entryCount,capability:receipt.negative.capability},pageErrors:receipt.pageErrors,externalBlocked:receipt.externalBlocked,error:receipt.error,receipt:path.join(out,'receipt.json')}));
}
