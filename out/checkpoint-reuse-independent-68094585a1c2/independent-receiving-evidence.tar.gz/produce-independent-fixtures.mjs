import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { pathToFileURL } from 'node:url';
const original='/tmp/hamon-scopesignal-checkpoint-import-68094585a1c2';
const baseline=path.join(original,'baseline');
const root='/tmp/hamon-scopesignal-independent-68094585a1c2';
const out=path.join(root,'frozen-inputs');
fs.mkdirSync(out,{recursive:true});
const sha=bytes=>crypto.createHash('sha256').update(bytes).digest('hex');
const blob=bytes=>crypto.createHash('sha1').update(Buffer.from('blob '+bytes.length+'\0')).update(bytes).digest('hex');
const expectedOriginal=[
 ['contract-before-edit.json','21ee8b3d2c18bd6589805c02a054698fb6ae38898ac67f10bf11518b7e437daf'],
 ['evidence/native-baseline/reviewed-source.json','e5178a88cbf589b767b72da873c78f31692f1c0f9bc9388338fe0eda6842c2b5']
];
for(const[p,digest] of expectedOriginal)if(sha(fs.readFileSync(path.join(original,p)))!==digest)throw Error('original input moved '+p);
const originalMap=JSON.parse(fs.readFileSync(path.join(original,'baseline-input-map.json')));
const pinInputs=()=>originalMap.inputs.map(p=>{
 const bytes=fs.readFileSync(path.join(baseline,p.path));
 if(bytes.length!==p.bytes||blob(bytes)!==p.git_blob)throw Error('baseline pin changed '+p.path);
 return {path:p.path,bytes:bytes.length,sha256:sha(bytes),git_blob:blob(bytes)};
});
const before=pinInputs();
const {createScopeReview,validateScopeDraft}=await import(pathToFileURL(path.join(baseline,'src/scope-plan.mjs')));
const {encodeScopeWorkspace,decodeScopeWorkspace,MAX_WORKSPACE_BYTES}=await import(pathToFileURL(path.join(baseline,'src/scope-workspace-record.mjs')));
const duplicate={title:'  Proof <δ> & "A"  ',amount:'0007.30',evidence:'  Planned A\nsecond & <B>\n'};
const source={label:'Independent source five — fictional',brief:'SOURCE ONLY: no destination brief replacement.\nSecond source line.',cap:'01000.00',
 checkpoints:[
  {...duplicate},
  {title:'Unselected middle',amount:'003.20',evidence:'Unselected planned middle'},
  {...duplicate},
  {title:'State-bearing unselected row',amount:'2.00',evidence:'Unselected planned state row'},
  {title:'Final 😀 café & <last>',amount:'0001.05',evidence:'First literal line\n  indented <script>text only</script>\n最後の行'}
 ]};
const review=createScopeReview(source);
review.act('scope-1','approve','ACCEPTED SOURCE ZERO: must not transfer');
review.act('scope-1','order');review.act('scope-1','request');review.act('scope-1','lose');
const evidenceDrafts=new Map([['scope-3','PENDING DUPLICATE TWO: must not transfer'],['scope-5','PENDING LAST: must not transfer']]);
const sourceText=encodeScopeWorkspace({draft:source,review,evidenceDrafts});
const destination={label:'  Unfinished μ <brief>  ',brief:'  Local line\n  keep & <x>  ',cap:'not yet',
 checkpoints:[
  {title:'  Current <one>  ',amount:' 00x ',evidence:'  pending local\npreserve second line'},
  {title:'Existing two',amount:'0',evidence:'Local planned evidence — untouched'}
 ]};
const selected=[0,2,4];
const expected={...structuredClone(destination),checkpoints:[...structuredClone(destination.checkpoints),...selected.map(i=>structuredClone(source.checkpoints[i]))]};
const validDestination={label:'Independent valid destination',brief:'Current valid brief',cap:'9999.00',
 checkpoints:[{title:'Current valid one',amount:'11.01',evidence:'Local evidence one'},{title:'Current valid two',amount:'12.02',evidence:'Local evidence two'}]};
const validExpected={...structuredClone(validDestination),checkpoints:[...structuredClone(validDestination.checkpoints),...selected.map(i=>structuredClone(source.checkpoints[i]))]};
const capacity={label:'Eleven current rows',brief:'Capacity must be atomic',cap:'9999',checkpoints:Array.from({length:11},(_,i)=>({title:'Keep current '+i,amount:String(i+1)+'.00',evidence:'Current original '+i}))};
const capacityExpected={...structuredClone(capacity),checkpoints:[...structuredClone(capacity.checkpoints),structuredClone(source.checkpoints[4])]};
const unfinished={label:'Unfinished source — fictional',brief:'',cap:'',checkpoints:[{title:'',amount:' 1e3 ',evidence:'literal unfinished\n'}, {title:'  zero amount  ',amount:'0',evidence:''}]};
const files={};
function keep(name,value){
 const bytes=typeof value==='string'?Buffer.from(value):Buffer.isBuffer(value)?value:Buffer.from(JSON.stringify(value,null,2)+'\n');
 const target=path.join(out,name);
 if(fs.existsSync(target)&&!fs.readFileSync(target).equals(bytes))throw Error('frozen fixture changed '+name);
 fs.writeFileSync(target,bytes);files[name]={bytes:bytes.length,sha256:sha(bytes),git_blob:blob(bytes)};
}
keep('reviewed-five.json',sourceText);
keep('destination-unfinished.json',encodeScopeWorkspace({draft:destination}));
keep('expected-unfinished-plus-0-2-4.json',encodeScopeWorkspace({draft:expected}));
keep('destination-valid.json',encodeScopeWorkspace({draft:validDestination}));
keep('expected-valid-plus-0-2-4.json',encodeScopeWorkspace({draft:validExpected}));
keep('expected-valid-new-review.json',encodeScopeWorkspace({draft:validExpected,review:createScopeReview(validExpected)}));
keep('destination-capacity-eleven.json',encodeScopeWorkspace({draft:capacity}));
keep('expected-capacity-twelve.json',encodeScopeWorkspace({draft:capacityExpected}));
keep('unfinished-source.json',encodeScopeWorkspace({draft:unfinished}));
keep('invalid-utf8.json',Buffer.from([0xc3,0x28,0xff]));
keep('malformed.json','{"schema":');
const unsupported=JSON.parse(sourceText);unsupported.version=99;keep('unsupported.json',unsupported);
keep('exact-one-mib.json',Buffer.concat([Buffer.from(sourceText),Buffer.alloc(MAX_WORKSPACE_BYTES-Buffer.byteLength(sourceText),0x20)]));
keep('over-one-mib.json',Buffer.concat([Buffer.from(sourceText),Buffer.alloc(MAX_WORKSPACE_BYTES+1-Buffer.byteLength(sourceText),0x20)]));
if(JSON.stringify(decodeScopeWorkspace(sourceText).draft)!==JSON.stringify(source))throw Error('source literal roundtrip');
if(!validateScopeDraft(validExpected).ok||validateScopeDraft(expected).ok)throw Error('oracle validation control');
if(JSON.stringify(before)!==JSON.stringify(pinInputs()))throw Error('original inputs changed');
const receipt={format:'scopesignal-checkpoint-independent-fixtures/1',produced_at:new Date().toISOString(),node:process.version,
 candidate_accessed:false,author_tests_accessed:false,original_native_inputs:before,original_inputs_unchanged:true,
 fixture_summary:{source_rows:5,source_approvals:review.snapshot().approved,source_events:review.snapshot().events.length,source_unknown_capture:review.snapshot().checkpoints[0].captureStatus,source_pending_notes:evidenceDrafts.size,destination_rows:2,selected_indices:selected,result_rows:5,repeated_source_definitions:[0,2],new_review_approvals:createScopeReview(validExpected).snapshot().approved,new_review_events:createScopeReview(validExpected).snapshot().events.length},
 files,qualification:'Original producer and oracle construction only; no author suite or candidate execution. Node22 is supplemental to supported Node24 receiving.'};
fs.writeFileSync(path.join(root,'frozen-fixtures-receipt.json'),JSON.stringify(receipt,null,2)+'\n');
console.log(JSON.stringify(receipt,null,2));
