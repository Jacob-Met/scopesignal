import fs from 'node:fs';
import path from 'node:path';
import http from 'node:http';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
const root='/tmp/hamon-scopesignal-independent-68094585a1c2';
const runtime=path.join(root,'composed-runtime');
const namespace='/home/jacob/hamon-scopesignal-independent-68094585a1c2';
const runDir=path.join(root,'browser-current-undo-v2');
fs.mkdirSync(runDir,{recursive:true});
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const delay=ms=>new Promise(r=>setTimeout(r,ms));
const custody=JSON.parse(fs.readFileSync(path.join(root,'current-composition-source-receiving.json')));
const receipt={format:'scopesignal-current-undo-independent-browser/1',started_at:new Date().toISOString(),
 contract_sha256:sha(fs.readFileSync(path.join(root,'current-lifecycle-before-composition.json'))),
 source_receipt_sha256:sha(fs.readFileSync(path.join(root,'current-composition-source-receiving.json'))),
 base:custody.base,source_fence:custody.source_fence,steps:[],http:[],page_errors:[],blocked_external:[],
 browser_started:false,passed:false,source_unchanged:false,original_native_groups_rerun:0,original_browser_suite_rerun:false};
receipt.observer_correction={prior_run:'browser-current-undo-v1',preserved:true,reason:'Existing html smooth scrolling made immediate pre-settlement coordinates unreliable; v2 uses instant scroll, two animation frames, verified actual hit target, and waits for native Apply result.',product_source_changes:0,expectation_changes:0};
const persist=()=>fs.writeFileSync(path.join(runDir,'receipt.json'),JSON.stringify(receipt,null,2)+'\n');
function pins(){
 const out={};for(const[p,id]of Object.entries(custody.runtime_files)){
  const b=fs.readFileSync(path.join(runtime,p));assert.equal(sha(b),id.sha256,p);out[p]=sha(b);
 }return out;
}
const sourceBefore=pins();
let server,child,cdp,stderrFD,closed=false;
const checkpoint=(name,detail)=>{receipt.steps.push({name,at:new Date().toISOString(),detail});console.log('CHECK '+name);persist();};
class CDP {
 constructor(socket){this.socket=socket;this.next=1;this.pending=new Map();this.handlers=[];
  socket.addEventListener('message',event=>{let m;try{m=JSON.parse(String(event.data));}catch{return;}
   if(m.id){const p=this.pending.get(m.id);if(!p)return;clearTimeout(p.timer);this.pending.delete(m.id);m.error?p.reject(Error(JSON.stringify(m.error))):p.resolve(m.result);}
   else for(const h of this.handlers)Promise.resolve(h(m)).catch(e=>{receipt.observer_event_errors??=[];receipt.observer_event_errors.push(String(e));});
  });
 }
 call(method,params={},sessionId){return new Promise((resolve,reject)=>{
  const id=this.next++;const timer=setTimeout(()=>{this.pending.delete(id);reject(Error('CDP timeout '+method));},30000);
  this.pending.set(id,{resolve,reject,timer});this.socket.send(JSON.stringify({id,method,params,...(sessionId?{sessionId}:{})}));
 });}
 on(h){this.handlers.push(h);}
}
try {
 receipt.capacity_before=['/home/jacob','/tmp'].map(p=>{const s=fs.statfsSync(p);return {path:p,free_bytes:s.bavail*s.bsize,free_inodes:s.ffree};});
 assert.ok(receipt.capacity_before[0].free_bytes>=536870912,'Insufficient current home space');
 assert.ok(receipt.capacity_before[1].free_bytes>=134217728,'Insufficient current /tmp space');
 fs.mkdirSync(namespace,{recursive:true});
 const browserInputs=path.join(namespace,'inputs');fs.mkdirSync(browserInputs,{recursive:true});
 for(const name of ['destination-valid.json','reviewed-five.json']){
  const raw=fs.readFileSync(path.join(root,'frozen-inputs',name));const out=path.join(browserInputs,name);
  if(fs.existsSync(out))assert.deepEqual(fs.readFileSync(out),raw);else fs.writeFileSync(out,raw);
 }
 const profile=path.join(namespace,'profile-current-undo-v2');assert.ok(!fs.existsSync(profile),'Profile already exists; preserve earlier attempt');
 const downloads=path.join(namespace,'downloads-current-undo-v2');assert.ok(!fs.existsSync(downloads),'Download namespace already exists');
 fs.mkdirSync(downloads);
 const mime={'.html':'text/html','.mjs':'text/javascript','.js':'text/javascript','.css':'text/css','.json':'application/json'};
 server=http.createServer((req,res)=>{
  const pathname=new URL(req.url,'http://localhost').pathname;
  const rel=pathname==='/'?'scope.html':decodeURIComponent(pathname.slice(1));
  if(rel.includes('..')||!Object.hasOwn(custody.runtime_files,rel)){res.writeHead(404);res.end('Not found');receipt.http.push({path:pathname,status:404});return;}
  const bytes=fs.readFileSync(path.join(runtime,rel));const digest=sha(bytes);
  if(digest!==custody.runtime_files[rel].sha256){res.writeHead(500);res.end('Source changed');throw Error('Served source changed '+rel);}
  receipt.http.push({path:pathname,status:200,bytes:bytes.length,sha256:digest});res.writeHead(200,{'content-type':mime[path.extname(rel)]||'application/octet-stream','cache-control':'no-store'});res.end(bytes);
 });
 await new Promise(r=>server.listen(0,'127.0.0.1',r));
 const origin='http://127.0.0.1:'+server.address().port;receipt.origin=origin;
 stderrFD=fs.openSync(path.join(runDir,'chromium.stderr.log'),'w');
 child=spawn('/snap/bin/chromium',['--headless=new','--no-sandbox','--disable-dev-shm-usage','--disable-gpu','--disable-background-networking','--disable-component-update','--no-first-run','--no-default-browser-check','--remote-debugging-port=0','--user-data-dir='+profile,'about:blank'],{stdio:['ignore','ignore',stderrFD],detached:true});
 child.once('exit',(code,signal)=>{closed=true;receipt.browser_process_exit={code,signal};});
 receipt.browser_started=true;receipt.browser_pid=child.pid;receipt.profile=profile;persist();
 const portFile=path.join(profile,'DevToolsActivePort');const deadline=Date.now()+45000;
 while(!fs.existsSync(portFile)){if(closed)throw Error('Browser exited before DevTools');if(Date.now()>deadline)throw Error('DevTools startup exceeded45s');await delay(100);}
 const parts=fs.readFileSync(portFile,'utf8').trim().split('\n');const ws=new WebSocket('ws://127.0.0.1:'+parts[0]+parts[1]);
 await new Promise((resolve,reject)=>{ws.addEventListener('open',resolve,{once:true});ws.addEventListener('error',reject,{once:true});});
 cdp=new CDP(ws);receipt.browser_version=await cdp.call('Browser.getVersion');
 const target=await cdp.call('Target.createTarget',{url:'about:blank'});
 const attached=await cdp.call('Target.attachToTarget',{targetId:target.targetId,flatten:true});const session=attached.sessionId;
 const call=(method,params={})=>cdp.call(method,params,session);
 const downloadsSeen=new Map();
 cdp.on(async m=>{
  if(m.method==='Browser.downloadWillBegin')downloadsSeen.set(m.params.guid,{...m.params});
  if(m.method==='Browser.downloadProgress'){const item=downloadsSeen.get(m.params.guid)||{};downloadsSeen.set(m.params.guid,{...item,...m.params});}
  if(m.sessionId!==session)return;
  if(m.method==='Runtime.exceptionThrown')receipt.page_errors.push(m.params.exceptionDetails);
  if(m.method==='Fetch.requestPaused'){
   const url=m.params.request.url;
   if(url.startsWith(origin+'/')||url.startsWith('blob:'+origin+'/'))await call('Fetch.continueRequest',{requestId:m.params.requestId});
   else{receipt.blocked_external.push(url);await call('Fetch.failRequest',{requestId:m.params.requestId,errorReason:'BlockedByClient'});}
  }
 });
 await call('Page.enable');await call('Runtime.enable');await call('DOM.enable');
 await call('Fetch.enable',{patterns:[{urlPattern:'*'}]});
 await cdp.call('Browser.setDownloadBehavior',{behavior:'allow',downloadPath:downloads,eventsEnabled:true});
 await call('Emulation.setDeviceMetricsOverride',{width:1200,height:900,deviceScaleFactor:1,mobile:false});
 async function evaluate(expression){const r=await call('Runtime.evaluate',{expression,returnByValue:true,awaitPromise:true});if(r.exceptionDetails)throw Error(JSON.stringify(r.exceptionDetails));return r.result.value;}
 async function waitFor(expression,label,timeout=20000){const end=Date.now()+timeout;while(Date.now()<end){if(await evaluate(expression))return;await delay(80);}throw Error('Timed out: '+label);}
 async function click(selector){const point=await evaluate('(async function(){const e=document.querySelector('+JSON.stringify(selector)+');if(!e)throw Error("Missing click target");if(e.disabled)throw Error("Disabled click target");e.scrollIntoView({block:"center",behavior:"instant"});await new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r)));const r=e.getBoundingClientRect();const x=r.x+r.width/2,y=r.y+r.height/2;const hit=document.elementFromPoint(x,y);if(!hit||!(hit===e||e.contains(hit)))throw Error("Hit target mismatch for "+e.id+": "+hit?.tagName+"#"+hit?.id);return {x,y};})()');
  receipt.observed_clicks??=[];receipt.observed_clicks.push({selector,...point});
  await call('Input.dispatchMouseEvent',{type:'mouseMoved',...point});
  await call('Input.dispatchMouseEvent',{type:'mousePressed',button:'left',clickCount:1,...point});await call('Input.dispatchMouseEvent',{type:'mouseReleased',button:'left',clickCount:1,...point});}
 async function choose(selector,name){const doc=await call('DOM.getDocument',{depth:0});const n=await call('DOM.querySelector',{nodeId:doc.root.nodeId,selector});assert.ok(n.nodeId,'Missing input '+selector);await call('DOM.setFileInputFiles',{nodeId:n.nodeId,files:[path.join(browserInputs,name)]});}
 const snapshotExpression='(function(){return {draft:{label:document.querySelector("#scope-label").value,brief:document.querySelector("#scope-brief").value,cap:document.querySelector("#scope-cap").value,checkpoints:[...document.querySelectorAll(".scope-row")].map(r=>({title:r.querySelector("[data-field=title]").value,amount:r.querySelector("[data-field=amount]").value,evidence:r.querySelector("[data-field=evidence]").value}))},undoDisabled:document.querySelector("#scope-undo-remove").disabled,importHidden:document.querySelector("#scope-checkpoint-preview").hidden,formHidden:document.querySelector("#scope-form").hidden,focus:document.activeElement.id,status:document.querySelector("#scope-checkpoint-status").textContent};})()';
 const snapshot=()=>evaluate(snapshotExpression);
 await call('Page.navigate',{url:origin+'/scope.html'});
 await waitFor('document.querySelectorAll(".scope-row").length>0 && Boolean(document.querySelector("#scope-undo-remove"))','current app initialized');
 await choose('#scope-open','destination-valid.json');
 await waitFor('!document.querySelector("#scope-open-preview").hidden','native whole-workspace preview');
 await click('#scope-open-apply');
 const originalDoc=JSON.parse(fs.readFileSync(path.join(root,'frozen-inputs/destination-valid.json')));
 await waitFor('document.querySelector("#scope-label").value==="Independent valid destination" && document.querySelectorAll(".scope-row").length===2','native whole-open applied');
 const initial=await snapshot();assert.deepEqual(initial.draft,originalDoc.draft);assert.equal(initial.formHidden,false);
 checkpoint('current-destination-opened',initial);
 await choose('#scope-checkpoint-file','reviewed-five.json');
 await waitFor('!document.querySelector("#scope-checkpoint-preview").hidden && document.querySelectorAll("#scope-checkpoint-options input").length===5','five checkpoint preview');
 await click('#scope-checkpoint-choice-4');
 await waitFor('!document.querySelector("#scope-checkpoint-apply").disabled','selected source ready');
 checkpoint('import-preview-before-new-undo-path',await snapshot());
 await click('button[data-remove="0"]');
 await waitFor('document.querySelectorAll(".scope-row").length===1 && !document.querySelector("#scope-undo-remove").disabled','native removal available');
 await click('#scope-undo-remove');
 await waitFor('document.querySelectorAll(".scope-row").length===2','native Undo restores order');
 const restored=await snapshot();assert.deepEqual(restored.draft,originalDoc.draft);assert.equal(restored.importHidden,true);
 await evaluate('document.querySelector("#scope-checkpoint-apply").dispatchEvent(new MouseEvent("click",{bubbles:true}))');
 const retired=await snapshot();assert.deepEqual(retired.draft,originalDoc.draft);assert.equal(retired.importHidden,true);
 checkpoint('remove-undo-ABA-cannot-revive-old-import',retired);
 await click('button[data-remove="0"]');
 await waitFor('document.querySelectorAll(".scope-row").length===1 && !document.querySelector("#scope-undo-remove").disabled','second removal has recovery');
 const removed=await snapshot();assert.deepEqual(removed.draft.checkpoints,[originalDoc.draft.checkpoints[1]]);
 await choose('#scope-checkpoint-file','reviewed-five.json');
 await waitFor('!document.querySelector("#scope-checkpoint-preview").hidden && document.querySelectorAll("#scope-checkpoint-options input").length===5','fresh source preview');
 await click('#scope-checkpoint-choice-4');
 await click('#scope-checkpoint-apply');
 await waitFor('document.querySelectorAll(".scope-row").length===2 && document.querySelector("#scope-checkpoint-preview").hidden','explicit append complete');
 const expectedBytes=fs.readFileSync(path.join(root,'frozen-inputs/expected-current-remove-and-append-four.json'));
 const expectedDoc=JSON.parse(expectedBytes);
 const appended=await snapshot();assert.deepEqual(appended.draft,expectedDoc.draft);assert.equal(appended.undoDisabled,true);assert.equal(appended.focus,'draft-1-title');assert.equal(appended.formHidden,false);
 await evaluate('document.querySelector("#scope-undo-remove").dispatchEvent(new MouseEvent("click",{bubbles:true}))');
 const guarded=await snapshot();assert.deepEqual(guarded.draft,expectedDoc.draft);assert.equal(guarded.undoDisabled,true);
 checkpoint('committed-import-clears-recovery-and-keeps-exact-definitions',guarded);
 await click('#scope-save');
 const downloadDeadline=Date.now()+20000;let completed;
 while(Date.now()<downloadDeadline){completed=[...downloadsSeen.values()].find(x=>x.state==='completed');if(completed)break;await delay(100);}
 assert.ok(completed,'No completed actual browser download');
 const downloadedPath=completed.filePath||path.join(downloads,completed.suggestedFilename);
 assert.ok(fs.existsSync(downloadedPath),'Completed native download path absent');
 const received=fs.readFileSync(downloadedPath);assert.deepEqual(received,expectedBytes);
 const receivedDoc=JSON.parse(received);assert.equal(receivedDoc.stage,'draft');assert.deepEqual(receivedDoc.events,[]);assert.deepEqual(receivedDoc.evidenceDrafts,[]);
 fs.writeFileSync(path.join(runDir,'actual-downloaded-workspace.json'),received);
 receipt.download={...completed,path:downloadedPath,bytes:received.length,sha256:sha(received),exact_original_native_reference:true};
 checkpoint('actual-download-byte-exact-630-byte-native-oracle',receipt.download);
 const layout=await call('Page.getLayoutMetrics');const height=Math.min(Math.ceil(layout.cssContentSize.height),4500);
 const shot=await call('Page.captureScreenshot',{format:'png',captureBeyondViewport:true,clip:{x:0,y:0,width:1200,height,scale:1}});
 const screenshot=Buffer.from(shot.data,'base64');fs.writeFileSync(path.join(runDir,'current-undo-import.png'),screenshot);
 receipt.screenshot={path:path.join(runDir,'current-undo-import.png'),bytes:screenshot.length,sha256:sha(screenshot)};
 assert.equal(receipt.page_errors.length,0,'Uncaught page exception');
 assert.deepEqual(pins(),sourceBefore);receipt.source_unchanged=true;receipt.passed=true;
 receipt.fixture_inputs_unchanged=['destination-valid.json','reviewed-five.json'].every(name=>fs.readFileSync(path.join(browserInputs,name)).equals(fs.readFileSync(path.join(root,'frozen-inputs',name))));
 assert.equal(receipt.fixture_inputs_unchanged,true);
} catch(error) {receipt.error={name:error.name,message:error.message,stack:error.stack};process.exitCode=1;}
finally {
 if(cdp){try{await cdp.call('Browser.close');}catch{}try{cdp.socket.close();}catch{}}
 if(child&&!closed){await delay(1200);if(!closed){try{process.kill(-child.pid,'SIGTERM');receipt.browser_termination='Owned process group SIGTERM after close wait';}catch{}}}
 if(server)await new Promise(r=>server.close(r));
 if(stderrFD!==undefined)try{fs.closeSync(stderrFD);}catch{}
 try{assert.deepEqual(pins(),sourceBefore);receipt.source_unchanged=true;}catch(e){receipt.final_source_check_error=String(e);receipt.passed=false;process.exitCode=1;}
 receipt.finished_at=new Date().toISOString();persist();console.log(JSON.stringify({passed:receipt.passed,steps:receipt.steps.map(x=>x.name),download:receipt.download,error:receipt.error,browser:receipt.browser_version,source_unchanged:receipt.source_unchanged,receipt:path.join(runDir,'receipt.json')},null,2));
}
