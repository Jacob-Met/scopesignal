from pathlib import Path
import difflib,hashlib,json,os
root=Path("/tmp/hamon-scopesignal-independent-68094585a1c2")
source=Path("/tmp/hamon-scopesignal-checkpoint-import-68094585a1c2/integration/candidate")
primary=json.loads((root/"current-beforeimages-primary.json").read_bytes())
target=root/"composed-runtime"
expected={
"src/scope-checkpoint-import.mjs":"89019640fbe3a9a5f3955566bb3fd6e7d838fc30c984e41cd24fb43dd6f9788e",
"src/scope-checkpoint-import-ui.mjs":"850e8ef9afcc9c63e013d097839a823615d5e66389acf4a970897ce114843195",
"src/scope-workspace.mjs":"39f2abe72f1ebaf09cf687177a858632bacb2a7d4708f0eb960cd23cc07a6e38",
"scope-checkpoint-import.css":"45587c17cf2db359652b88553b66c88898abb9fa4108380dd6dcb5a8f8e67f2f",
"scope.html":"b8050abc6ccdf11b9c772c5ddbcc2218592c82eae862c58e81bc2929e5f4de34",
"README.md":"c07cd18b097094344287fc92a65992cfb3a6f2ca0c3996932afa753feee111b7"}
def identity(raw):
 return {"bytes":len(raw),"sha256":hashlib.sha256(raw).hexdigest(),"git_blob":hashlib.sha1(b"blob "+str(len(raw)).encode()+bytes([0])+raw).hexdigest()}
record={"format":"scopesignal-current-composition-independent-source/1","base":"cdffd2476cae0c7332dff64677ae814b7f594947","base_tree":primary["tree"]["sha"],
"primary_beforeimages":"current-beforeimages-primary.json","original_native_receipt_sha256":hashlib.sha256((root/"native-receiving.json").read_bytes()).hexdigest(),
"supplement_before_composition_sha256":hashlib.sha256((root/"current-lifecycle-before-composition.json").read_bytes()).hexdigest(),
"source_fence":{},"shared_file_proofs":{},"runtime_files":{},"authored_tests_or_scripts_accessed":False}
for name,digest in expected.items():
 raw=(source/name).read_bytes();assert hashlib.sha256(raw).hexdigest()==digest,name
 record["source_fence"][name]=identity(raw)
for name in ["src/scope-workspace.mjs","scope.html","README.md"]:
 before=primary["files"][name]["content"]
 assert identity(before.encode())["git_blob"]==primary["files"][name]["sha"],name
 after=(source/name).read_text()
 old=before.splitlines(True);new=after.splitlines(True)
 opcodes=difflib.SequenceMatcher(a=old,b=new,autojunk=False).get_opcodes()
 assert all(tag in ("equal","insert") for tag,_,_,_,_ in opcodes),name
 inserts=[]
 restored=[]
 for tag,a,b,c,d in opcodes:
  if tag=="equal":restored.extend(new[c:d])
  else:inserts.append({"before_line":a+1,"lines":d-c,"text":"".join(new[c:d])})
 assert "".join(restored)==before,name
 record["shared_file_proofs"][name]={"before":identity(before.encode()),"after":identity(after.encode()),"only_insertions":True,"full_reverse_exact":True,"insertions":inserts}
workspace=(source/"src/scope-workspace.mjs").read_text()
assert workspace.count("checkpointImport.retire();")==2
assert "function workspaceChanged() {\n  checkpointImport.retire();" in workspace
assert "cancelOpen();\n  checkpointImport.retire();\n  clearDraftRemoval();" in workspace
assert "    const first = current.checkpoints.length;\n    clearDraftRemoval();\n    workspaceChanged();\n    current.checkpoints.push(...checkpoints);" in workspace
assert "value: workspaceValue()" in workspace and "editable: !review && !form.hidden" in workspace
tree={x["path"]:x for x in primary["tree"]["tree"] if x["type"]!="tree"}
paths=[]
for p in source.rglob("*"):
 if not p.is_file():continue
 rel=p.relative_to(source)
 if any(part in {"tests","scripts","docs",".git","node_modules"} for part in rel.parts):continue
 if p.suffix in {".mjs",".js",".json",".css",".html",".svg",".png",".webp",".woff",".woff2"}:paths.append(rel)
for rel in sorted(paths):
 raw=(source/rel).read_bytes();ident=identity(raw)
 if str(rel) not in expected:
  assert str(rel) in tree and ident["git_blob"]==tree[str(rel)]["sha"],rel
 out=target/rel;out.parent.mkdir(parents=True,exist_ok=True)
 if out.exists():assert out.read_bytes()==raw,rel
 else:out.write_bytes(raw)
 record["runtime_files"][str(rel)]=ident
for name in ["src/scope-checkpoint-import.mjs","src/scope-checkpoint-import-ui.mjs","scope-checkpoint-import.css"]:
 assert (root/"candidate-runtime"/name).read_bytes()==(source/name).read_bytes()
record["earlier_qualified_component_bytes_exact"]=True
record["protected_current_capabilities"]=["DraftRemoval remove/restore preserves later text; clear remains separate from workspaceChanged","Every history mount/update/clear line retained","Whole-workspace and comparison HTML retained","Native plan/codec/ledger source pins unchanged"]
record["runtime_files_count"]=len(record["runtime_files"])
record["reviewer_source_conclusion"]="Accepted source composition; one new Remove→Undo/import browser witness pending. No original native/browser suite repeated."
for folder in ["/home/jacob","/tmp"]:
 v=os.statvfs(folder);record.setdefault("resource_read",[]).append({"path":folder,"free_bytes":v.f_bavail*v.f_frsize,"free_inodes":v.f_favail})
raw=json.dumps(record,indent=2,ensure_ascii=False)+"\n"
(root/"current-composition-source-receiving.json").write_text(raw)
print(json.dumps({"receipt":str(root/"current-composition-source-receiving.json"),"sha256":hashlib.sha256(raw.encode()).hexdigest(),"runtime_files":record["runtime_files_count"],"shared_proofs":{k:{"insertions":len(v["insertions"]),"full_reverse_exact":v["full_reverse_exact"]} for k,v in record["shared_file_proofs"].items()},"resource":record["resource_read"]},indent=2))
