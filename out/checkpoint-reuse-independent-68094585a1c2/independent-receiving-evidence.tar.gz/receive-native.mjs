import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {pathToFileURL} from 'node:url';
const root='/tmp/hamon-scopesignal-independent-68094585a1c2';
const runtime=path.join(root,'candidate-runtime');
const fixtures=path.join(root,'frozen-inputs');
const original='/tmp/hamon-scopesignal-checkpoint-import-68094585a1c2/baseline';
const sha=bytes=>crypto.createHash('sha256').update(bytes).digest('hex');
const fixtureManifest=JSON.parse(fs.readFileSync(path.join(root,'frozen-fixtures-receipt.json')));
const custody=JSON.parse(fs.readFileSync(path.join(root,'candidate-custody-native.json')));
function pinFiles(){
 const result={};
 for(const[p,id]of Object.entries(custody.runtime_files)){
  const bytes=fs.readFileSync(path.join(runtime,p));assert.equal(sha(bytes),id.sha256,p);
  result[p]=sha(bytes);
 }
 for(const[p,id]of Object.entries(fixtureManifest.files)){
  const bytes=fs.readFileSync(path.join(fixtures,p));assert.equal(sha(bytes),id.sha256,p);
  result['fixture/'+p]=sha(bytes);
 }
 for(const id of fixtureManifest.original_native_inputs){
  const bytes=fs.readFileSync(path.join(original,id.path));assert.equal(sha(bytes),id.sha256,id.path);
  result['original/'+id.path]=sha(bytes);
 }
 return result;
}
const pinsBefore=pinFiles();
const {readCheckpointSource,selectCheckpointDefinitions}=await import(pathToFileURL(path.join(runtime,'src/scope-checkpoint-import.mjs')));
const {encodeScopeWorkspace,decodeScopeWorkspace}=await import(pathToFileURL(path.join(original,'src/scope-workspace-record.mjs')));
const {createScopeReview,validateScopeDraft}=await import(pathToFileURL(path.join(original,'src/scope-plan.mjs')));
const text=name=>fs.readFileSync(path.join(fixtures,name),'utf8');
const file=name=>fs.readFileSync(path.join(fixtures,name));
const current=decodeScopeWorkspace(text('destination-unfinished.json')).draft;
const source=readCheckpointSource(text('reviewed-five.json'));
const originalSource=decodeScopeWorkspace(text('reviewed-five.json'));
const groups=[];
function group(id,fn){try{const detail=fn();groups.push({id,passed:true,detail});console.log('PASS '+id);}catch(error){groups.push({id,passed:false,error:{name:error.name,message:error.message,stack:error.stack}});console.log('FAIL '+id+' '+error.message);}}
function joined(destination,rows){return {...structuredClone(destination),checkpoints:[...structuredClone(destination.checkpoints),...rows]};}
group('private_review_projects_only_exact_frozen_definitions',()=>{
 assert.deepEqual(Object.keys(source),['label','stage','checkpoints']);
 assert.equal(source.label,originalSource.draft.label);assert.equal(source.stage,'review');
 assert.deepEqual(source.checkpoints,originalSource.draft.checkpoints);
 assert.equal(source.checkpoints.length,5);
 assert.ok(Object.isFrozen(source)&&Object.isFrozen(source.checkpoints)&&source.checkpoints.every(Object.isFrozen));
 for(const row of source.checkpoints)assert.deepEqual(Object.keys(row),['title','amount','evidence']);
 const serialized=JSON.stringify(source);
 for(const forbidden of ['ACCEPTED SOURCE ZERO','PENDING DUPLICATE TWO','PENDING LAST','paypal.capture','checkpointId','paymentEvidence','events','evidenceDrafts'])assert.ok(!serialized.includes(forbidden),forbidden);
 assert.equal(originalSource.review.snapshot().approved,1);
 assert.equal(originalSource.review.snapshot().events.length,4);
 assert.equal(originalSource.review.snapshot().checkpoints[0].captureStatus,'unknown');
 return {source_rows:5,original_approvals:1,original_events:4,original_pending_notes:2,projection_fields:['label','stage','checkpoints']};
});
group('permuted_duplicate_occurrences_preserve_literal_destination_and_exact_native_bytes',()=>{
 const untouched=JSON.stringify(current);
 const definitions=selectCheckpointDefinitions(source,[4,2,0],current.checkpoints.length);
 assert.deepEqual(definitions,[0,2,4].map(i=>originalSource.draft.checkpoints[i]));
 const actual=encodeScopeWorkspace({draft:joined(current,definitions)});
 assert.deepEqual(Buffer.from(actual),file('expected-unfinished-plus-0-2-4.json'));
 assert.equal(JSON.stringify(current),untouched);
 assert.equal(validateScopeDraft(joined(current,definitions)).ok,false);
 assert.notEqual(definitions[0],definitions[1]);assert.notEqual(definitions[0],source.checkpoints[0]);
 const prior=JSON.stringify(source);
 definitions[0].title='receiver mutation of returned copy';
 assert.equal(JSON.stringify(source),prior);assert.notEqual(definitions[1].title,definitions[0].title);
 fs.writeFileSync(path.join(root,'actual-native-unfinished-append.json'),actual);
 return {selected_request:[4,2,0],source_order:[0,2,4],rows:5,bytes:Buffer.byteLength(actual),sha256:sha(Buffer.from(actual)),unchanged_destination:true};
});
group('selection_and_capacity_refuse_atomically_then_admit_exact_twelve',()=>{
 const unchanged=JSON.stringify({current,source});
 const invalid=[[],[0,0],[-1],[5],[1.1],['0'],[true],[NaN],[Infinity],null,{},[0,2,4,1,3]];
 let refusals=0;
 for(const indices of invalid){assert.throws(()=>selectCheckpointDefinitions(source,indices,indices===invalid.at(-1)?8:2));refusals++;}
 for(const count of [0,-1,13,1.5,'2',null]){assert.throws(()=>selectCheckpointDefinitions(source,[0],count));refusals++;}
 const eleven=decodeScopeWorkspace(text('destination-capacity-eleven.json')).draft;
 assert.throws(()=>selectCheckpointDefinitions(source,[0,4],eleven.checkpoints.length));refusals++;
 assert.equal(JSON.stringify({current,source}),unchanged);
 const rows=selectCheckpointDefinitions(source,[4],eleven.checkpoints.length);
 const actual=encodeScopeWorkspace({draft:joined(eleven,rows)});
 assert.deepEqual(Buffer.from(actual),file('expected-capacity-twelve.json'));
 assert.throws(()=>selectCheckpointDefinitions(source,[4],12));refusals++;
 return {refusals,exact_boundary_rows:12,bytes:Buffer.byteLength(actual),sha256:sha(Buffer.from(actual)),partial_mutations:0};
});
group('existing_codec_admission_and_unfinished_strings_remain_authoritative',()=>{
 const cases=[];
 for(const name of ['reviewed-five.json','unfinished-source.json','exact-one-mib.json','over-one-mib.json','malformed.json','unsupported.json']){
  const contents=text(name);
  let baseline,candidate,baseError,candidateError;
  try{baseline=decodeScopeWorkspace(contents);}catch(e){baseError=e;}
  try{candidate=readCheckpointSource(contents);}catch(e){candidateError=e;}
  assert.equal(Boolean(candidateError),Boolean(baseError),name);
  if(!baseError)assert.deepEqual(candidate.checkpoints,baseline.draft.checkpoints,name);
  cases.push({name,accepted:!candidateError,bytes:file(name).length});
 }
 const unfinished=readCheckpointSource(text('unfinished-source.json'));
 const rows=selectCheckpointDefinitions(unfinished,[1,0],2);
 assert.deepEqual(rows,decodeScopeWorkspace(text('unfinished-source.json')).draft.checkpoints);
 assert.equal(rows[0].amount,' 1e3 ');assert.equal(rows[1].amount,'0');assert.equal(rows[0].title,'');
 assert.throws(()=>readCheckpointSource(null));
 return {cases,unfinished_strings_exact:true,utf8_browser_boundary:'not claimed by this text-only model receiver'};
});
group('normal_new_review_generates_destination_order_without_imported_state',()=>{
 const valid=decodeScopeWorkspace(text('destination-valid.json')).draft;
 const candidateDraft=joined(valid,selectCheckpointDefinitions(source,[4,2,0],valid.checkpoints.length));
 assert.equal(validateScopeDraft(candidateDraft).ok,true);
 const actualDraft=encodeScopeWorkspace({draft:candidateDraft});
 assert.deepEqual(Buffer.from(actualDraft),file('expected-valid-plus-0-2-4.json'));
 const review=createScopeReview(candidateDraft);
 const state=review.snapshot();
 assert.equal(state.approved,0);assert.equal(state.events.length,0);assert.equal(state.captured,0);
 assert.deepEqual(state.checkpoints.map(x=>x.id),['scope-1','scope-2','scope-3','scope-4','scope-5']);
 assert.ok(state.checkpoints.every(x=>x.acceptedEvidence===null&&x.captureStatus==='not_started'&&!x.approved));
 const actual=encodeScopeWorkspace({draft:candidateDraft,review});
 assert.deepEqual(Buffer.from(actual),file('expected-valid-new-review.json'));
 const reopened=decodeScopeWorkspace(actual);
 assert.equal(reopened.evidenceDrafts.size,0);
 fs.writeFileSync(path.join(root,'actual-native-new-review.json'),actual);
 return {new_ids:state.checkpoints.map(x=>x.id),approved:0,events:0,captured:0,pending_notes:0,bytes:Buffer.byteLength(actual),sha256:sha(Buffer.from(actual))};
});
let custodyPassed=false;
try{assert.deepEqual(pinFiles(),pinsBefore);custodyPassed=true;}catch(error){groups.push({id:'source_input_custody',passed:false,error:{message:error.message}});}
const receipt={format:'scopesignal-checkpoint-independent-native-receiving/1',finished_at:new Date().toISOString(),node:process.version,
 contract_sha256:sha(fs.readFileSync(path.join(root,'independent-contract-before-candidate.json'))),
 fixtures_receipt_sha256:sha(fs.readFileSync(path.join(root,'frozen-fixtures-receipt.json'))),
 candidate_source_hashes:custody.source_fence,groups,passed:groups.filter(x=>x.passed).length,failed:groups.filter(x=>!x.passed).length,
 unchanged_sources_and_inputs:custodyPassed,source_and_fixture_files:Object.keys(pinsBefore).length,
 author_tests_accessed:false,author_suite_run:false,browser_started:false,
 browser_limit:'Initial owned /home namespace creation failed ENOSPC. No retry or cleanup; root requested native/source receiving without duplicating authored browser suite.',
 runtime_limit:'Node22.22.1 is supplemental below declared Node>=24. Supported hosted gates remain with final source integration.'};
fs.writeFileSync(path.join(root,'native-receiving.json'),JSON.stringify(receipt,null,2)+'\n');
console.log(JSON.stringify(receipt,null,2));
if(receipt.failed||!custodyPassed)process.exitCode=1;
