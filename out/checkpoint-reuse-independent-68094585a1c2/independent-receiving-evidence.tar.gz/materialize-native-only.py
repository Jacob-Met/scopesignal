from pathlib import Path
import hashlib,json,os
origin=Path("/tmp/hamon-scopesignal-checkpoint-import-68094585a1c2")
root=Path("/tmp/hamon-scopesignal-independent-68094585a1c2")
target=root/"candidate-runtime"
expected={
"src/scope-checkpoint-import.mjs":"89019640fbe3a9a5f3955566bb3fd6e7d838fc30c984e41cd24fb43dd6f9788e",
"src/scope-checkpoint-import-ui.mjs":"850e8ef9afcc9c63e013d097839a823615d5e66389acf4a970897ce114843195",
"src/scope-workspace.mjs":"4bc64e884e1f518b8abefaf2f736ee60fd4e97ed47a095fbe978982d649069d8",
"scope-checkpoint-import.css":"45587c17cf2db359652b88553b66c88898abb9fa4108380dd6dcb5a8f8e67f2f",
"scope.html":"3d894b4df7c2b21a2934909fc9c1175d36c4d9aaa6d99b17c84720083793b6a7",
"README.md":"d334caa9ca0d87394a9e6aefa9dbeadf9f5affbf2d89450e82b390b0194c98a8"}
record={"format":"scopesignal-independent-candidate-custody/1","source_path":str(origin/"candidate"),"contract_before_access_sha256":hashlib.sha256((root/"independent-contract-before-candidate.json").read_bytes()).hexdigest(),"source_fence":{},"runtime_files":{},"candidate_tests_or_scripts_accessed":False}
def identity(raw):
 return {"bytes":len(raw),"sha256":hashlib.sha256(raw).hexdigest(),"git_blob":hashlib.sha1(b"blob "+str(len(raw)).encode()+bytes([0])+raw).hexdigest()}
for name,digest in expected.items():
 raw=(origin/"candidate"/name).read_bytes()
 assert hashlib.sha256(raw).hexdigest()==digest,name
 record["source_fence"][name]=identity(raw)
allowed=[]
for p in (origin/"baseline").rglob("*"):
 if not p.is_file():continue
 rel=p.relative_to(origin/"baseline")
 if any(part in {"tests","scripts","docs",".git","node_modules"} for part in rel.parts):continue
 if p.suffix in {".mjs",".js",".json",".css",".html",".svg",".png",".webp",".woff",".woff2"}:allowed.append(rel)
for name in expected:
 p=Path(name)
 if name!="README.md" and p not in allowed:allowed.append(p)
for rel in sorted(allowed):
 raw=(origin/"candidate"/rel).read_bytes()
 old=origin/"baseline"/rel
 if str(rel) not in expected:
  assert old.is_file() and old.read_bytes()==raw,rel
 out=target/rel;out.parent.mkdir(parents=True,exist_ok=True)
 if out.exists():assert out.read_bytes()==raw,rel
 else:out.write_bytes(raw)
 record["runtime_files"][str(rel)]=identity(raw)
record["browser_files"]=None
record["browser_profile_namespace"]=None
record["runtime_files_count"]=len(record["runtime_files"])
record["browser_startup"]="held: first owned /home directory creation failed ENOSPC; no browser launch"
(root/"candidate-custody-native.json").write_text(json.dumps(record,indent=2)+"\n")
print(json.dumps({"runtime_files":len(record["runtime_files"]),"paths":list(record["runtime_files"]),"fence_verified":6,"candidate_tests_or_scripts_accessed":False},indent=2))
