from pathlib import Path
import json,hashlib,io,tarfile,gzip,base64,datetime
root=Path('/tmp/hamon-scopesignal-independent-68094585a1c2')
original=Path('/tmp/hamon-scopesignal-checkpoint-import-68094585a1c2')
out=root/'publication'
out.mkdir(exist_ok=True)
def sha(b): return hashlib.sha256(b).hexdigest()
def blob(b): return hashlib.sha1(('blob '+str(len(b))+'\0').encode()+b).hexdigest()
def identity(p):
 b=p.read_bytes()
 return {'bytes':len(b),'sha256':sha(b),'git_blob':blob(b)}
def dump(p,v): p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def load(p): return json.loads(p.read_text())
pins={
 'independent-contract-before-candidate.json':'67316e9e5c4e45ed291f92ca49a2ea95105aa7489ad6f137e345434b0e65de39',
 'frozen-fixtures-receipt.json':'c1b27e44a9a33125d7b3ef073fa7a1b2e993095259742d555d5c2387f71b5b7c',
 'native-receiving.json':'efa5ddd8611d3971c4564160f455b2d38f62ce28d56f62c34502e9b3ad0421bb',
 'current-lifecycle-before-composition.json':'3eb71046faac777cc01d187bf5c48d6dd539f9720cc790effd80265362ae0b09',
 'current-composition-source-receiving.json':'0c5e2dbcdd366a7ec2981b6010d99a720e65c6bca9209938b2ed5b1d5cc5024b',
 'frozen-inputs/expected-current-remove-and-append-four.json':'1a0a9e15d0ba34789def7f42afa49d0de7ab916f0497996b6ef50629a9382dce'
}
for p,d in pins.items(): assert sha((root/p).read_bytes())==d,p
native=load(root/'native-receiving.json')
source=load(root/'current-composition-source-receiving.json')
binding=load(root/'published-source-binding.json')
v1=load(root/'browser-current-undo-v1/receipt.json')
v2=load(root/'browser-current-undo-v2/receipt.json')
assert len(native['groups'])==5 and all(x['passed'] for x in native['groups'])
assert all(x['full_reverse_exact'] and x['only_insertions'] for x in source['shared_file_proofs'].values())
assert not v1['passed'] and not v2['passed'] and not v1['steps'] and not v2['steps']
assert v2['error']['message']=='DevTools startup exceeded45s' and v2['source_unchanged']
assert binding['commit']['sha']=='65209a72c4593358848a6921847a478ce6fba8c3'
assert binding['tree']=='57e70cff603e2e03a590daf9f346c565df4dcead'
assert binding['inherited_exact']==669 and len(binding['changes'])==3
source_final={}
for category,dirpath,fence in [('initial',original/'candidate',native['candidate_source_hashes']),('composed',original/'integration/candidate',source['source_fence'])]:
 for p,expected in fence.items():
  data=(dirpath/p).read_bytes()
  assert sha(data)==expected['sha256'] and blob(data)==expected['git_blob'],(category,p)
  dest=root/'source-fence'/category/p
  dest.parent.mkdir(parents=True,exist_ok=True)
  if dest.exists(): assert dest.read_bytes()==data
  else: dest.write_bytes(data)
  source_final[category+'/'+p]=identity(dest)
for p,expected in source['runtime_files'].items():
 assert identity(root/'composed-runtime'/p)==expected,p
original_input_map=load(original/'baseline-input-map.json')
for row in original_input_map['inputs']:
 data=(original/'baseline'/row['path']).read_bytes()
 assert len(data)==row['bytes'] and blob(data)==row['git_blob'],row['path']
 dest=root/'original-only/baseline'/row['path']
 dest.parent.mkdir(parents=True,exist_ok=True)
 if dest.exists(): assert dest.read_bytes()==data
 else: dest.write_bytes(data)
for p in ['baseline-input-map.json','contract-before-edit.json','evidence/native-baseline/reviewed-source.json']:
 data=(original/p).read_bytes()
 if p=='contract-before-edit.json': assert sha(data)=='21ee8b3d2c18bd6589805c02a054698fb6ae38898ac67f10bf11518b7e437daf'
 if p.endswith('reviewed-source.json'): assert sha(data)=='e5178a88cbf589b767b72da873c78f31692f1c0f9bc9388338fe0eda6842c2b5'
 dest=root/'original-only'/p
 dest.parent.mkdir(parents=True,exist_ok=True)
 if dest.exists(): assert dest.read_bytes()==data
 else: dest.write_bytes(data)
limits=[
 {'id':'initial-owned-namespace-ENOSPC','record':'environment-failure-1.json','product_test_started':False,'effect':'First profile directory could not be created; original failure and script preserved.'},
 {'id':'current-browser-v1-unsettled-click','record':'browser-current-undo-v1/receipt.json','stdout':'browser-current-undo-v1.log','stderr':'browser-current-undo-v1/chromium.stderr.log','tested_composition_steps_completed':0,'effect':'Whole-open preview displayed, but immediate-coordinate physical click left Northstar fixture unchanged. Existing smooth scroll establishes a concrete observer synchronization flaw; v1 did not record a hit target, so no product conclusion is drawn.'},
 {'id':'current-browser-v2-startup-timeout','record':'browser-current-undo-v2/receipt.json','stdout':'browser-current-undo-v2.log','stderr':'browser-current-undo-v2/chromium.stderr.log','stderr_bytes':(root/'browser-current-undo-v2/chromium.stderr.log').stat().st_size,'tested_composition_steps_completed':0,'effect':'Observer-only correction preserved source and oracle. DevTools startup exceeded the bounded 45 seconds; no page loaded. No third attempt.'}
]
receipt={
 'format':'scopesignal-checkpoint-independent-receiving/1',
 'sealed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'cohort':'chatgpt:68094585a1c2',
 'attribution':{'original_source_author':'estate-68094585a1c2 / receiving_review','source_continuation_executor':'scope_receiving','independent_receiver':'offhand_delivery','integration_decision_owner':'root'},
 'repository':'Jacob-Met/scopesignal','issue':35,'pull_request':46,
 'published_source_commit':binding['commit']['sha'],'published_source_tree':binding['tree'],
 'publication_base_commit':binding['base_commit'],'publication_base_tree':binding['base_tree'],
 'frozen_inputs':{p:identity(root/p) for p in pins},
 'native_receiving':{'passed':True,'groups':native['groups'],'node':native['node'],'fixture_and_runtime_custody':'44 frozen input/runtime paths unchanged at native completion; original-only producer separately retained all 16 baseline inputs.','declared_runtime_floor':'Node >=24','qualification_limit':'Node22.22.1 execution is supplemental below the declared floor; the unchanged hosted Node24 gate is a separate owner receipt.'},
 'current_source_receiving':{'passed':True,'shared_file_proofs':{p:{'full_reverse_exact':v['full_reverse_exact'],'only_insertions':v['only_insertions'],'insertion_blocks':len(v['insertions'])} for p,v in source['shared_file_proofs'].items()},'runtime_files_exact':len(source['runtime_files']),'original_helper_ui_css_identical':True,'history_and_draft_recovery_beforeimages_preserved':True,'append_clear_before_workspace_changed':True,'published_base_leaves':binding['base_leaves'],'published_leaves':binding['leaves'],'inherited_leaves_exact':binding['inherited_exact'],'modified_inherited_paths':[x['path'] for x in binding['changes']]},
 'source_final_custody':source_final,
 'composition_only_browser_witness':{'status':'unobserved','passed':False,'frozen_control':'Pending import must remain retired after Remove/Undo ABA, and a fresh committed append must clear available Undo.','expected_native_download':identity(root/'frozen-inputs/expected-current-remove-and-append-four.json'),'actual_download_received':False,'product_defect_established':False,'attempts':2,'third_attempt_made':False,'limits':limits,'v1_source_unchanged_false_means':'v1 exited before its success-only final source check; final sealing independently rehashes both source fences and all 18 composed runtime files exactly.'},
 'independence':{'authored_candidate_tests_read':False,'authored_candidate_scripts_read':False,'authored_browser_suite_repeated':False,'original_native_groups_repeated':False,'browser_changes':'Only independent observer v2 changed; source and frozen expectations did not.','source_edited':False},
 'delivery_boundary':'This capsule reports independent native and complete source receiving plus preserved browser limits. Root decides integration; no deployed Pages, installed app, live account or provider result is claimed here.'
}
dump(out/'receipt.json',receipt)
readme='''# Independent selected-checkpoint receiving

Source: ScopeSignal #35, PR46 at 65209a72c4593358848a6921847a478ce6fba8c3, tree 57e70cff603e2e03a590daf9f346c565df4dcead. Original source author: estate-68094585a1c2 / receiving_review; source continuation: scope_receiving; independent receiver: offhand_delivery, cohort chatgpt:68094585a1c2. Root owns integration.

## Result

Five independently frozen native groups passed, and the complete current-source comparison passed. The additional current-only Remove/Undo browser witness is **unobserved**. It did not reach an import/Undo assertion or an actual download. No product defect was established by those incomplete attempts, and no third attempt was made. These limits are part of the result.

The original contract and distinct native producer were frozen before reading candidate product source. The producer uses the unchanged original workspace codec and review model to create a five-row reviewed source, a separate unfinished destination, exact append/review reference bytes and admission/capacity boundaries. Rows 0 and 2 are equal definitions at distinct positions. One source approval, four private events and two pending notes are intentionally separate from the literal planned evidence.

## Independent native evidence

1. Definition-only projection preserves exact strings and freezes the result while dropping approvals, accepted/pending notes, events and IDs.
2. Selection request [4, 2, 0] appends source positions [0, 2, 4], preserves both equal occurrences and all current fields, and produces the exact original-native 1,064-byte unfinished workspace (SHA256 32f38ffed7baa872f048edda37be64d97de1228c7a48bc48ad603dd0ae651631). Returned copies are independent.
3. Twenty invalid selection/capacity inputs refuse atomically. The exact 12-row boundary produces the original-native 1,811-byte reference.
4. Existing codec admission agrees on six cases, including exactly 1 MiB and one byte beyond it. Unfinished strings remain literal. Fatal UTF-8 behavior belongs to the UI boundary and is not claimed by this text-only native receiver.
5. An ordinary new review produces the original-native 1,032-byte reference with five new destination-order IDs and zero approvals, events, captured value or pending notes.

This native run used existing Node22.22.1, below the repository's declared Node >=24 floor. It is supplemental evidence. The ordinary hosted Node24 gate is separately received by the source/integration owner. No original native suite or authored browser suite was repeated, and the independent receiver did not read the author's candidate tests or candidate scripts.

## Current composition

The publication base is cdffd2476cae0c7332dff64677ae814b7f594947, tree 03775ba5484d768a0bda6a22d51bdad9fd30d184. Independent GitHub reads supplied complete current beforeimages and all 672 leaves. The published source has 684 leaves: all 669 unaffected prior leaves remain exact; only README, scope HTML and the shared controller changed among inherited paths.

Removing four controller insertion blocks, two HTML insertion blocks and one README insertion block recovers each complete current beforeimage byte-for-byte. All 18 composed runtime files were bound to current GitHub blobs or the six exact contribution pins. The original qualified import helper, UI and CSS are unchanged.

The current controller preserves author-history and draft-removal recovery code. Existing workspaceChanged remains recovery-neutral, so text edits can retain Undo; import retirement was inserted there. The new append explicitly clears draft-removal recovery before workspaceChanged. Whole-workspace replacement retires import before its existing clear. These source controls passed. The current-only browser supplement was frozen before reading the composed candidate to test pending import retirement across Remove/Undo ABA and recovery clearing after a new append.

## Retained limits

- Initial materialization reached ENOSPC when creating the first owned browser namespace. It occurred after source verification/runtime copy and before a browser or candidate test started. The record and original materializer remain intact.
- Browser v1 started Chrome153.0.8010.47 and served the exact composed source. A native whole-open preview appeared, but the initial physical Apply click left the original Northstar fixture displayed. The page's unchanged CSS uses smooth scrolling, while v1 immediately sampled coordinates after scrollIntoView. The observer lacked a hit-target record. No import/Undo assertion was reached, so that run gives no product acceptance result. Its raw receipt/log/stderr are retained.
- Observer v2 changed only scrolling synchronization and hit-target validation, preserving product source and every frozen expectation. Its Chrome process did not expose DevTools within the 45-second bound. The stdout/receipt retain that timeout; Chromium stderr is exactly empty. No page loaded, no browser import/Undo result or actual downloaded workspace was received, and no third attempt was made.

The final seal rehashes both six-file source fences and all 18 composed runtime files. The v1 field source_unchanged:false means its success-only end check was not reached; it is not evidence of a mutation. Root must decide integration using the complete native/source, authored and hosted evidence, with this browser gap explicit.

## Capsule contents and custody

The capsule includes frozen contracts, original-only input sources, native producers and fixtures, original and composed runtime snapshots, full source inverses and GitHub binding, the native receiver/outputs, both browser observers, all three limit records, and raw browser logs. Each payload member is listed with byte count, SHA256 and Git blob ID in capsule-manifest.json; the same manifest is included in the archive as MANIFEST.json. The archive and four publication files are described by publication-metadata.json outside the archive.

Recorded scripts retain their actual native absolute paths. The original-only snapshot and both runtime snapshots are included for inspection and reproduction in an isolated namespace; any relocation must update only those recorded paths and preserve the manifests. Browser profiles are disposable runtime state and are not packaged; existing profiles were left alone, and no other worker's files were cleaned. No deployed Pages, installed application, live account or payment-provider result is claimed by this independent capsule.
'''
(out/'README.md').write_text(readme)
files=[]
for p in sorted(root.rglob('*')):
 if not p.is_file() or out in p.parents: continue
 if p.name.endswith('.b64'): continue
 files.append((str(p.relative_to(root)),p.read_bytes()))
manifest={'format':'scopesignal-independent-capsule-manifest/1','member_count':len(files),'members':[{'path':p,'bytes':len(b),'sha256':sha(b),'git_blob':blob(b)} for p,b in files]}
manifest_bytes=(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n').encode()
(out/'capsule-manifest.json').write_bytes(manifest_bytes)
tarbuf=io.BytesIO()
with tarfile.open(fileobj=tarbuf,mode='w') as tar:
 for p,b in files+[('MANIFEST.json',manifest_bytes)]:
  info=tarfile.TarInfo(p);info.size=len(b);info.mode=0o644;info.mtime=0
  tar.addfile(info,io.BytesIO(b))
archive=out/'independent-receiving-evidence.tar.gz'
with archive.open('wb') as raw:
 with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0,compresslevel=6) as gz: gz.write(tarbuf.getvalue())
with tarfile.open(archive,'r:gz') as tar:
 assert len(tar.getmembers())==len(files)+1
 for p,b in files: assert tar.extractfile(p).read()==b,p
 assert tar.extractfile('MANIFEST.json').read()==manifest_bytes
metadata={'format':'scopesignal-independent-publication-metadata/1','source_commit':binding['commit']['sha'],'source_tree':binding['tree'],'base_commit':binding['base_commit'],'native_groups_passed':5,'current_source_passed':True,'current_only_browser':'unobserved','payload_members':len(files),'archive_members':len(files)+1,'publication_directory':str(out),'suggested_repository_path':'out/checkpoint-reuse-independent-68094585a1c2','files':{p:identity(out/p) for p in ['README.md','receipt.json','capsule-manifest.json','independent-receiving-evidence.tar.gz']},'source_inverse_receipt':identity(root/'current-composition-source-receiving.json'),'browser_v1_receipt':identity(root/'browser-current-undo-v1/receipt.json'),'browser_v2_receipt':identity(root/'browser-current-undo-v2/receipt.json'),'browser_v2_stderr':identity(root/'browser-current-undo-v2/chromium.stderr.log')}
dump(out/'publication-metadata.json',metadata)
encoded=base64.b64encode(archive.read_bytes()).decode()
(out/'capsule.b64').write_text('\n'.join(encoded[i:i+4096] for i in range(0,len(encoded),4096))+'\n')
for p,d in pins.items(): assert sha((root/p).read_bytes())==d,p
print(json.dumps(metadata,ensure_ascii=False,indent=2))
