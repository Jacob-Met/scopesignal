# Even checkpoint amounts

In the editable ScopeSignal draft, choose **Preview equal amounts** under the checkpoint list. The proposal shows each current amount beside a proposed amount. It uses the entered positive USD cap and the current row count. **Apply these amounts** replaces the amount fields; **Cancel allocation** keeps them unchanged.

Amounts are divided in integer cents. Every checkpoint receives the quotient; the first rows receive one extra cent until the remainder is used. For example, a $100.01 cap over three checkpoints becomes $33.34, $33.34 and $33.33. A cap smaller than one cent per row refuses. This fills the entire cap; it is an editing convenience, not advice about what work should cost.

The original cap notation, brief, project name, deliverables, row order and planned evidence remain as entered. Empty or unfinished old amounts are allowed in the preview. Missing required text still needs correction before ordinary **Review this scope** succeeds. Applying does not approve a checkpoint or record a payment event.

Any edit, row addition/removal/copy/move, successful review, or actual saved-workspace replacement retires an older allocation proposal. Preview again before applying the changed draft. Downloading a workspace or merely previewing/canceling a saved file does not itself change the draft. Applying deliberately cancels pending file/import work and retires Undo removal; its earlier amount could otherwise undo the newly reviewed allocation. Ordinary later amount editing remains available.

The action is inside the editable form and is unavailable while reviewing a scope. Return with **Edit draft** when the existing rules allow it. After approval, the existing revision-draft workflow remains the way to author different terms.

## Receiving

Native model tests run with the repository's existing `npm test`. They use the real draft codec and review consumer, including complete cents, exact raw fields, cancellation/stale proposals, detached return objects and zero inherited events. The model retains native money admission; this change introduces no currency conversion or precision policy.

The focused real-browser receiver needs Node24 and an **already installed** Chrome/Chromium executable:

```sh
SCOPESIGNAL_CHROME=/path/to/chrome node scripts/check-scope-allocation.mjs . /path/to/new/output candidate
```

The output directory must not exist. It serves only the selected local source, uses a new disposable browser profile, blocks nonlocal page requests, and preserves literal fictional inputs, actual native workspace downloads, served/source hashes, keyboard/layout observations and the original failure if any. The optional `baseline` mode checks the original healthy native editor/download and the absent allocation action. The repository's added PR-only browser workflow runs that mode against the fixed original5bbb5208, then receives the actual candidate checkout. It installs no browser or npm package. Browser execution, source integration and public Pages release remain separate evidence; the receiver alone makes no public deployment claim.
