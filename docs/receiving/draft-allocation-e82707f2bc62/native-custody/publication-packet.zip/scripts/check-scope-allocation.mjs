// The local CDP transport/pointer helpers follow the existing
// check-scope-draft-removal.mjs receiver. These checks concern allocation only.
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import fs from 'node:fs';
import http from 'node:http';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { pathToFileURL } from 'node:url';

const [sourceArg, outputArg, mode = 'candidate'] = process.argv.slice(2);
if (!sourceArg || !outputArg || !['baseline', 'candidate'].includes(mode)) {
  throw new Error('Usage: node check-scope-allocation.mjs SOURCE NEW_OUTPUT [baseline|candidate]');
}
const source = path.resolve(sourceArg), output = path.resolve(outputArg);
fs.mkdirSync(output);
const profile = path.join(output, 'profile'), downloads = path.join(output, 'downloads');
fs.mkdirSync(downloads);
const sha = data => crypto.createHash('sha256').update(data).digest('hex');
const sourceFiles = [
  'scope.html', 'styles.css', 'scope-workspace.css', 'scope-history.css',
  ...(mode === 'candidate' ? ['scope-allocation.css'] : []),
  ...fs.readdirSync(path.join(source, 'src')).filter(f => f.endsWith('.mjs')).map(f => 'src/' + f)
];
const sourcePins = Object.fromEntries(sourceFiles.map(f => [f, sha(fs.readFileSync(path.join(source, f)))]));
const results = [], pageErrors = [], blocked = [], served = {};
const receipt = { mode, source, runtime: process.version, sourcePins, results, served, blocked, pageErrors, accepted: false, cleanupErrors: [] };
let chrome, socket, server, sequence = 0;
const pending = new Map();
const waitFor = async (probe, label, timeout = 12000) => {
  const deadline = Date.now() + timeout;
  while (Date.now() < deadline) { try { const value = await probe(); if (value) return value; } catch (error) { if (!/context|Cannot read properties/.test(String(error))) throw error; } await new Promise(resolve => setTimeout(resolve, 40)); }
  throw new Error('Timed out: ' + label);
};
const send = (method, params = {}) => new Promise((resolve, reject) => {
  const id = ++sequence;
  const timer = setTimeout(() => { pending.delete(id); reject(new Error(method + ' timed out')); }, 15000);
  pending.set(id, { resolve: value => { clearTimeout(timer); resolve(value); }, reject: error => { clearTimeout(timer); reject(error); } });
  socket.send(JSON.stringify({ id, method, params }));
});
const evaluate = async expression => {
  const reply = await send('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: true });
  if (reply.exceptionDetails) throw new Error(reply.exceptionDetails.exception?.description || reply.exceptionDetails.text);
  return reply.result.value;
};
const check = async (name, fn) => { try { const detail = await fn(); results.push({ name, pass: true, detail }); } catch (error) { results.push({ name, pass: false, error: String(error.stack || error) }); throw error; } };
const readDraft = () => evaluate(`({label:document.querySelector('#scope-label').value,brief:document.querySelector('#scope-brief').value,cap:document.querySelector('#scope-cap').value,checkpoints:[...document.querySelectorAll('.scope-row')].map(row=>Object.fromEntries([...row.querySelectorAll('[data-field]')].map(f=>[f.dataset.field,f.value])))})`);
const fill = async (selector, value) => {
  await evaluate(`document.querySelector(${JSON.stringify(selector)}).focus()`);
  await send('Input.dispatchKeyEvent', { type: 'keyDown', key: 'a', code: 'KeyA', windowsVirtualKeyCode: 65, modifiers: 2 });
  await send('Input.dispatchKeyEvent', { type: 'keyUp', key: 'a', code: 'KeyA', windowsVirtualKeyCode: 65, modifiers: 2 });
  await send('Input.insertText', { text: value });
};
const click = async selector => {
  const p = await evaluate(`(async()=>{const e=document.querySelector(${JSON.stringify(selector)});if(!e||e.disabled||e.closest('[hidden]'))throw Error('Control unavailable');e.scrollIntoView({block:'center',behavior:'instant'});await new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r)));const r=e.getBoundingClientRect();return{x:r.x+r.width/2,y:r.y+r.height/2}})()`);
  await send('Input.dispatchMouseEvent', { type: 'mousePressed', button: 'left', clickCount: 1, ...p });
  await send('Input.dispatchMouseEvent', { type: 'mouseReleased', button: 'left', clickCount: 1, ...p });
};
let origin, navigation = 0;
const fresh = async () => { const url = origin + '/scope.html?receiving=' + (++navigation); await send('Page.navigate', { url }); await waitFor(() => evaluate(`location.href===${JSON.stringify(url)} && document.readyState==='complete' && document.querySelectorAll('.scope-row').length===3 && !!document.querySelector('#draft-2-title')`), 'draft startup'); };
const loadFile = async file => { const doc = await send('DOM.getDocument'); const q = await send('DOM.querySelector', { nodeId: doc.root.nodeId, selector: '#scope-open' }); await send('DOM.setFileInputFiles', { nodeId: q.nodeId, files: [file] }); };

const keyboard = async (key, code, number) => {
  await send('Input.dispatchKeyEvent', { type: 'keyDown', key, code, windowsVirtualKeyCode: number,
    ...(key === 'Enter' ? { text: '\r', unmodifiedText: '\r' } : {}) });
  await send('Input.dispatchKeyEvent', { type: 'keyUp', key, code, windowsVirtualKeyCode: number });
};
const visibleProposal = () => evaluate("!document.querySelector('.scope-allocation-proposal').hidden");
const { decodeScopeWorkspace, encodeScopeWorkspace } = await import(pathToFileURL(path.join(source, 'src/scope-workspace-record.mjs')));
const { createScopeReview, draftFromFixture } = await import(pathToFileURL(path.join(source, 'src/scope-plan.mjs')));
let downloadNumber = 0;
const download = async () => {
  const directory = path.join(downloads, String(++downloadNumber)); fs.mkdirSync(directory);
  await send('Page.setDownloadBehavior', { behavior: 'allow', downloadPath: directory });
  await click('#scope-save');
  const file = path.join(directory, 'scopesignal-workspace-v1.json');
  await waitFor(() => {
    if (!fs.existsSync(file)) return false;
    try { decodeScopeWorkspace(fs.readFileSync(file, 'utf8')); return true; } catch { return false; }
  }, 'complete native workspace download');
  const bytes = fs.readFileSync(file);
  return { file, bytes, admitted: decodeScopeWorkspace(bytes.toString('utf8')) };
};
const authored = async () => {
  await fresh();
  await fill('#scope-label', '  <fixture> & allocation Ω ');
  await fill('#scope-brief', 'First line\n  Keep this exact fictional brief.');
  await fill('#scope-cap', ' 00100.01 ');
  await fill('#draft-0-title', '<img src=x onerror=alert(1)> Ω');
  await fill('#draft-0-amount', ' unfinished ');
  await fill('#draft-1-amount', '');
  await fill('#draft-2-amount', '99.99');
  await fill('#draft-0-evidence', 'A literal <script> & proof\nsecond line');
  const intended = draftFromFixture();
  intended.label = '  <fixture> & allocation Ω ';
  intended.brief = 'First line\n  Keep this exact fictional brief.';
  intended.cap = ' 00100.01 ';
  intended.checkpoints[0].title = '<img src=x onerror=alert(1)> Ω';
  intended.checkpoints[0].amount = ' unfinished ';
  intended.checkpoints[1].amount = '';
  intended.checkpoints[2].amount = '99.99';
  intended.checkpoints[0].evidence = 'A literal <script> & proof\nsecond line';
  const actual = await readDraft();
  assert.deepEqual(actual, intended, 'native input must produce the exact intended authored fixture');
  return actual;
};
try {
  server = http.createServer((req, res) => {
    let relative;
    try { relative = decodeURIComponent(new URL(req.url, 'http://localhost').pathname).replace(/^\/+/, ''); }
    catch { res.writeHead(400).end(); return; }
    const filename = path.resolve(source, relative || 'scope.html');
    if (!filename.startsWith(source + path.sep)) { res.writeHead(403).end(); return; }
    try {
      const bytes = fs.readFileSync(filename); served[relative] = sha(bytes);
      res.setHeader('Content-Type', filename.endsWith('.mjs') ? 'text/javascript' : filename.endsWith('.css') ? 'text/css' : 'text/html');
      res.end(bytes);
    } catch { res.writeHead(404).end(); }
  });
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  origin = 'http://127.0.0.1:' + server.address().port;
  const chromePath = process.env.SCOPESIGNAL_CHROME;
  if (!chromePath) throw new Error('SCOPESIGNAL_CHROME must name an existing Chrome/Chromium executable.');
  chrome = spawn(chromePath, ['--headless=new', '--remote-debugging-port=0', '--user-data-dir=' + profile,
    '--no-first-run', '--no-default-browser-check', '--disable-background-networking', 'about:blank'],
    { stdio: ['ignore', 'ignore', 'pipe'] });
  let chromeErrors = '';
  chrome.stderr.on('data', bytes => { chromeErrors = (chromeErrors + bytes).slice(-20000); });
  chrome.on('error', error => { receipt.launchError = String(error); });
  const activePort = path.join(profile, 'DevToolsActivePort');
  await waitFor(() => {
    if (receipt.launchError) throw new Error(receipt.launchError);
    if (chrome.exitCode !== null) throw new Error('Chrome exited: ' + chromeErrors);
    return fs.existsSync(activePort);
  }, 'Chrome debugging endpoint');
  const port = fs.readFileSync(activePort, 'utf8').split(/\r?\n/)[0];
  const tabs = await (await fetch('http://127.0.0.1:' + port + '/json/list')).json();
  socket = new WebSocket(tabs.find(tab => tab.type === 'page').webSocketDebuggerUrl);
  await new Promise((resolve, reject) => {
    socket.addEventListener('open', resolve, { once: true }); socket.addEventListener('error', reject, { once: true });
  });
  socket.addEventListener('message', event => {
    const msg = JSON.parse(event.data);
    if (msg.id) {
      const request = pending.get(msg.id);
      if (request) {
        pending.delete(msg.id);
        msg.error ? request.reject(new Error(JSON.stringify(msg.error))) : request.resolve(msg.result);
      }
      return;
    }
    if (msg.method === 'Runtime.exceptionThrown') {
      pageErrors.push(msg.params.exceptionDetails.exception?.description || msg.params.exceptionDetails.text);
    }
    if (msg.method === 'Fetch.requestPaused') {
      const { requestId, request } = msg.params;
      const action = request.url.startsWith(origin + '/')
        ? send('Fetch.continueRequest', { requestId })
        : (blocked.push(request.url), send('Fetch.failRequest', { requestId, errorReason: 'BlockedByClient' }));
      action.catch(error => pageErrors.push(String(error)));
    }
  });
  for (const method of ['Page.enable', 'Runtime.enable', 'DOM.enable']) await send(method);
  await send('Fetch.enable', { patterns: [{ urlPattern: '*', requestStage: 'Request' }] });
  receipt.browser = (await send('Browser.getVersion')).product;
  await send('Emulation.setDeviceMetricsOverride', { width: 1280, height: 1000, deviceScaleFactor: 1, mobile: false });

  let original, originalSaved;
  await check('original native authoring and download preserve unfinished literal amounts', async () => {
    original = await authored();
    originalSaved = await download();
    assert.deepEqual(originalSaved.admitted.draft, original);
    assert.equal(originalSaved.admitted.review, null);
    assert.equal(originalSaved.bytes.toString('utf8'), encodeScopeWorkspace({ draft: original }));
    assert.deepEqual(await readDraft(), original);
    if (mode === 'baseline') {
      assert.equal(await evaluate("document.querySelectorAll('#scope-allocation-preview').length"), 0);
    }
    return { absentAllocation: mode === 'baseline', nativeDownloadSha256: sha(originalSaved.bytes), draft: original };
  });

  if (mode === 'candidate') {
    await check('preview shows exact old strings, literal titles and every proposed cent without editing', async () => {
      await click('#scope-allocation-preview');
      assert.equal(await visibleProposal(), true);
      assert.deepEqual(await readDraft(), original);
      const rows = await evaluate("[...document.querySelectorAll('#scope-allocation-rows li')].map(row=>({title:row.querySelector('strong').textContent,old:row.querySelector('code').textContent,next:row.querySelectorAll('p')[1].textContent}))");
      assert.deepEqual(rows.map(row => row.old), [' unfinished ', '(empty)', '99.99']);
      assert.equal(rows[0].title, 'Checkpoint 1: ' + original.checkpoints[0].title);
      assert.deepEqual(rows.map(row => row.next), ['Proposed amount: $33.34', 'Proposed amount: $33.34', 'Proposed amount: $33.33']);
      assert.equal(await evaluate("document.querySelectorAll('#scope-allocation-rows img, #scope-allocation-rows script').length"), 0);
      const after = await download(); assert.equal(sha(after.bytes), sha(originalSaved.bytes));
      return { rows, unchangedDownloadSha256: sha(after.bytes) };
    });
    await check('cancel preserves the complete raw draft and returns keyboard focus', async () => {
      await click('#scope-allocation-cancel');
      assert.equal(await visibleProposal(), false);
      assert.deepEqual(await readDraft(), original);
      assert.equal(await evaluate('document.activeElement.id'), 'scope-allocation-preview');
    });
    await check('explicit apply changes amounts only, cancels older replacement and saves exact native draft', async () => {
      await click('#scope-allocation-preview');
      await loadFile(originalSaved.file);
      await waitFor(() => evaluate("!document.querySelector('#scope-open-preview').hidden"), 'saved workspace preview');
      assert.equal(await visibleProposal(), true);
      await click('#scope-allocation-apply');
      const expected = { ...original, checkpoints: original.checkpoints.map((row, i) => ({ ...row, amount: i < 2 ? '33.34' : '33.33' })) };
      assert.deepEqual(await readDraft(), expected);
      assert.equal(await visibleProposal(), false);
      assert.equal(await evaluate("document.querySelector('#scope-open-preview').hidden"), true);
      assert.equal(await evaluate('document.activeElement.id'), 'draft-0-amount');
      const saved = await download();
      assert.equal(saved.bytes.toString('utf8'), encodeScopeWorkspace({ draft: expected }));
      const native = createScopeReview(saved.admitted.draft).snapshot();
      assert.equal(native.total, 10001); assert.equal(native.approved, 0); assert.deepEqual(native.events, []);
      return { nativeDownloadSha256: sha(saved.bytes), nativeTotal: native.total };
    });
    await check('ordinary edits and same-value roundtrips retire prepared allocation', async () => {
      await click('#scope-allocation-preview');
      const before = await readDraft();
      await fill('#scope-brief', before.brief + 'changed');
      await fill('#scope-brief', before.brief);
      assert.equal(await visibleProposal(), false);
      assert.deepEqual(await readDraft(), before);
      for (const action of ['#scope-add', '[data-duplicate="0"]', '[data-move="down"][data-index="0"]', '[data-remove="1"]']) {
        await fresh(); await click('#scope-allocation-preview'); await click(action);
        assert.equal(await visibleProposal(), false, action);
      }
    });
    await check('invalid and insufficient caps refuse without changing any checkpoint', async () => {
      await authored();
      for (const cap of ['0.02', '0', '1.001', 'unfinished']) {
        await fill('#scope-cap', cap); const before = await readDraft();
        await click('#scope-allocation-preview');
        assert.equal(await visibleProposal(), false);
        assert.deepEqual(await readDraft(), before);
        assert.ok((await evaluate("document.querySelector('#scope-allocation-status').textContent")).length);
      }
    });
    await check('preview and cancel keep Undo removal; applying deliberately retires it', async () => {
      await fresh(); await click('[data-remove="1"]');
      assert.equal(await evaluate("document.querySelector('#scope-undo-remove').disabled"), false);
      await click('#scope-allocation-preview'); await click('#scope-allocation-cancel');
      assert.equal(await evaluate("document.querySelector('#scope-undo-remove').disabled"), false);
      await click('#scope-allocation-preview'); await click('#scope-allocation-apply');
      assert.equal(await evaluate("document.querySelector('#scope-undo-remove').disabled"), true);
      assert.deepEqual((await readDraft()).checkpoints.map(row => row.amount), ['600.00', '600.00']);
    });
    await check('whole-workspace replacement retires proposal and retains exact restored fields', async () => {
      await fresh(); await click('#scope-allocation-preview');
      await loadFile(originalSaved.file);
      await waitFor(() => evaluate("!document.querySelector('#scope-open-preview').hidden"), 'whole workspace preview');
      await click('#scope-open-apply');
      assert.equal(await visibleProposal(), false);
      assert.deepEqual(await readDraft(), original);
    });
    await check('keyboard-only preview and apply lead to an unapproved native review', async () => {
      await fresh(); await fill('#scope-cap', '0.05');
      await evaluate("document.querySelector('#scope-allocation-preview').focus()");
      await keyboard('Enter', 'Enter', 13);
      assert.equal(await visibleProposal(), true);
      await keyboard('Tab', 'Tab', 9);
      assert.equal(await evaluate('document.activeElement.id'), 'scope-allocation-apply');
      await keyboard('Enter', 'Enter', 13);
      assert.deepEqual((await readDraft()).checkpoints.map(row => row.amount), ['0.02', '0.02', '0.01']);
      assert.equal(await evaluate('document.activeElement.id'), 'draft-0-amount');
      await click('#scope-form button[type="submit"]');
      assert.equal(await evaluate("document.querySelector('#scope-form').hidden"), true);
      assert.equal(await evaluate("document.querySelector('#scope-event-count').textContent"), '0 events');
      assert.equal(await evaluate("document.querySelector('#scope-approved').textContent"), '0 / 3');
      const saved = await download(); assert.equal(saved.admitted.summary.stage, 'review');
      assert.equal(saved.admitted.summary.events, 0); assert.equal(saved.admitted.summary.approved, 0);
      await click('#scope-edit'); assert.equal(await visibleProposal(), false);
    });
    await check('phone layout retains literal proposal, practical targets and native keyboard focus', async () => {
      await send('Emulation.setDeviceMetricsOverride', { width: 390, height: 844, deviceScaleFactor: 1, mobile: true });
      await authored(); await click('#scope-allocation-preview');
      const geometry = await evaluate("({overflow:document.documentElement.scrollWidth>innerWidth,buttons:[...document.querySelectorAll('#scope-allocation button')].filter(e=>!e.closest('[hidden]')).map(e=>({id:e.id,width:e.getBoundingClientRect().width,height:e.getBoundingClientRect().height}))})");
      assert.equal(geometry.overflow, false);
      assert.ok(geometry.buttons.every(button => button.height >= 44 && button.width >= 44));
      await evaluate("document.querySelector('#scope-allocation-preview').focus()");
      await keyboard('Tab', 'Tab', 9);
      const focus = await evaluate("({id:document.activeElement.id,style:getComputedStyle(document.activeElement).outlineStyle,width:getComputedStyle(document.activeElement).outlineWidth})");
      assert.equal(focus.id, 'scope-allocation-apply'); assert.equal(focus.style, 'solid'); assert.equal(focus.width, '3px');
      const capture = await send('Page.captureScreenshot', { format: 'png', captureBeyondViewport: false });
      fs.writeFileSync(path.join(output, 'phone.png'), Buffer.from(capture.data, 'base64'));
      return { geometry, focus };
    });
  }
  assert.deepEqual(pageErrors, []);
  assert.ok(blocked.every(url => /^https:\/\/fonts\.(googleapis|gstatic)\.com\//.test(url)), 'Only inherited font requests may be blocked');
  for (const [filename, expected] of Object.entries(sourcePins)) {
    assert.equal(sha(fs.readFileSync(path.join(source, filename))), expected, filename);
  }
  for (const [filename, actual] of Object.entries(served)) {
    if (Object.hasOwn(sourcePins, filename)) assert.equal(actual, sourcePins[filename], filename);
  }
  receipt.accepted = true;
} catch (error) {
  receipt.error = String(error.stack || error); receipt.accepted = false;
} finally {
  // Publish the substantive outcome before cleanup, so cleanup cannot conceal it.
  fs.writeFileSync(path.join(output, 'receipt-before-cleanup.json'), JSON.stringify(receipt, null, 2) + '\n');
  const stopped = async timeout => {
    if (!chrome || chrome.exitCode !== null || chrome.signalCode !== null) return true;
    return Promise.race([
      new Promise(resolve => chrome.once('exit', () => resolve(true))),
      new Promise(resolve => setTimeout(() => resolve(false), timeout))
    ]);
  };
  try {
    if (socket?.readyState === WebSocket.OPEN) { try { await send('Browser.close'); } catch {} socket.close(); }
    if (!(await stopped(3000))) chrome.kill('SIGTERM');
    if (!(await stopped(3000))) chrome.kill('SIGKILL');
    if (!(await stopped(3000))) throw new Error('Chrome did not exit; profile retained.');
    await fs.promises.rm(profile, { recursive: true, force: true, maxRetries: 5, retryDelay: 100 });
  } catch (error) { receipt.cleanupErrors.push(String(error.stack || error)); receipt.accepted = false; }
  server?.close();
  fs.writeFileSync(path.join(output, 'receipt.json'), JSON.stringify(receipt, null, 2) + '\n');
  console.log(JSON.stringify(receipt));
  if (!receipt.accepted) process.exitCode = 1;
}
