import { createDraftAllocation } from './scope-allocation.mjs';
import { formatUSD } from './scope-plan.mjs';

export function mountDraftAllocation(root, { getDraft, isEditable, replaceDraft }) {
  const model = createDraftAllocation();
  const document = root.ownerDocument;
  const element = (tag, text, className) => {
    const node = document.createElement(tag);
    if (text !== undefined) node.textContent = text;
    if (className) node.className = className;
    return node;
  };
  const heading = element('h2', 'Divide the cap across checkpoints');
  heading.id = 'scope-allocation-title';
  const help = element('p', 'Preview equal amounts for every current checkpoint. Apply replaces their amount fields only; the brief, cap and evidence stay as entered. You can edit the amounts afterward and must still review the scope.');
  const preview = element('button', 'Preview equal amounts', 'button button-outline');
  preview.type = 'button'; preview.id = 'scope-allocation-preview';
  const status = element('p');
  status.id = 'scope-allocation-status'; status.setAttribute('role', 'status');
  status.setAttribute('aria-live', 'polite'); status.setAttribute('aria-atomic', 'true');
  const panel = element('div', undefined, 'scope-allocation-proposal');
  panel.hidden = true;
  const summary = element('p');
  const rows = element('ol');
  rows.id = 'scope-allocation-rows';
  const notice = element('p', 'Applying retires any pending saved-file replacement, checkpoint import and Undo removal. This changes no approvals or simulated payments.');
  const apply = element('button', 'Apply these amounts', 'button button-dark');
  apply.type = 'button'; apply.id = 'scope-allocation-apply';
  const cancel = element('button', 'Cancel allocation', 'button button-outline');
  cancel.type = 'button'; cancel.id = 'scope-allocation-cancel';
  const actions = element('div', undefined, 'scope-allocation-actions');
  actions.append(apply, cancel);
  panel.append(summary, rows, notice, actions);
  root.replaceChildren(heading, help, preview, status, panel);

  function clear(message = '') {
    model.clear(); panel.hidden = true; rows.replaceChildren(); summary.textContent = '';
    status.textContent = message; status.classList.remove('error');
  }

  preview.addEventListener('click', () => {
    clear();
    if (!isEditable()) return;
    try {
      const proposal = model.prepare(getDraft());
      for (const row of proposal.rows) {
        const item = element('li');
        item.append(element('strong', `Checkpoint ${row.index + 1}: ${row.title}`));
        const previous = element('p', 'Current amount: ');
        previous.append(element('code', row.previousAmount === '' ? '(empty)' : row.previousAmount));
        const next = element('p', `Proposed amount: ${formatUSD(row.cents)}`);
        item.append(previous, next); rows.append(item);
      }
      summary.textContent = `${formatUSD(proposal.capCents)} divided across ${proposal.rows.length} checkpoints. ${proposal.remainderCount === 0 ? 'Every amount is equal.' : `The first ${proposal.remainderCount} checkpoint(s) receive one extra cent so the total equals the cap.`}`;
      panel.hidden = false;
      status.textContent = 'Proposal ready. Your current amounts are unchanged.';
    } catch (error) {
      clear(); status.textContent = error.message; status.classList.add('error');
    }
  });

  apply.addEventListener('click', () => {
    if (!isEditable()) { clear(); return; }
    try {
      const next = model.apply(getDraft());
      replaceDraft(next);
      clear('Equal amounts applied. Review the scope when the remaining fields are ready.');
    } catch (error) {
      clear(); status.textContent = error.message; status.classList.add('error');
      preview.focus();
    }
  });

  cancel.addEventListener('click', () => {
    clear('Allocation canceled. Your current amounts are unchanged.'); preview.focus();
  });

  return Object.freeze({
    clear() {
      const hadProposal = model.available;
      clear(hadProposal ? 'Draft changed. Preview equal amounts again if needed.' : '');
    }
  });
}
