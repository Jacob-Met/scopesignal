import { parseDollars, dollars } from './scope-plan.mjs';
import { encodeScopeWorkspace, decodeScopeWorkspace } from './scope-workspace-record.mjs';

// Admission and canonical field order belong to the unchanged native codec.
function admit(draft) {
  const signature = encodeScopeWorkspace({ draft });
  return { signature, draft: decodeScopeWorkspace(signature).draft };
}

export function createDraftAllocation() {
  let pending = null;
  return Object.freeze({
    get available() { return pending !== null; },
    clear() { pending = null; },
    prepare(current) {
      pending = null;
      const admitted = admit(current);
      const draft = admitted.draft;
      const capCents = parseDollars(draft.cap);
      if (capCents === null) throw new Error('Enter a positive project cap with no more than two decimal places.');
      const count = draft.checkpoints.length;
      if (capCents < count) throw new Error('The cap must allow at least one cent for each checkpoint.');
      const total = BigInt(capCents);
      const quotient = total / BigInt(count);
      const remainderCount = Number(total % BigInt(count));
      const rows = draft.checkpoints.map((row, index) => {
        const cents = Number(quotient + (index < remainderCount ? 1n : 0n));
        return { index, title: row.title, previousAmount: row.amount, nextAmount: dollars(cents), cents };
      });
      const next = { ...draft, checkpoints: draft.checkpoints.map((row, index) => ({
        ...row, amount: rows[index].nextAmount
      })) };
      pending = { signature: admitted.signature, next };
      // The mutable display proposal has no shared arrays/objects with pending.
      return { capCents, remainderCount, rows };
    },
    apply(current) {
      const proposal = pending;
      pending = null;
      if (!proposal) throw new Error('Preview equal amounts before applying them.');
      if (admit(current).signature !== proposal.signature) {
        throw new Error('The draft changed. Preview the current amounts again.');
      }
      return structuredClone(proposal.next);
    }
  });
}
