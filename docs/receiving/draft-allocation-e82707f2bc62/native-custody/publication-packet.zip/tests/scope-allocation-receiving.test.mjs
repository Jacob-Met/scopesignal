import assert from 'node:assert/strict';
import { test } from 'node:test';
import { resolve } from 'node:path';
import { pathToFileURL, fileURLToPath } from 'node:url';

const root = process.env.SCOPESIGNAL_SOURCE_ROOT
  ? resolve(process.env.SCOPESIGNAL_SOURCE_ROOT)
  : fileURLToPath(new URL('..', import.meta.url));
const native = name => import(pathToFileURL(resolve(root, 'src', name)).href);
const { parseDollars, draftBudget, createScopeReview } = await native('scope-plan.mjs');
const { encodeScopeWorkspace, decodeScopeWorkspace } = await native('scope-workspace-record.mjs');
const allocation = async () => (await native('scope-allocation.mjs')).createDraftAllocation();
const copy = value => structuredClone(value);

function fixture(cap = '7.03', count = 7, unfinished = false) {
  return {
    label: '  Fictional film — Δ  ',
    brief: 'First line\n\n  Keep this exact second line\tand spacing.',
    cap,
    checkpoints: Array.from({ length: count }, (_, index) => ({
      title: unfinished && index === 1 ? '' : '  Same title <' + (index % 2) + '>  ',
      amount: unfinished ? ['', ' TBD ', '1e3', '0.001', ' 0001.0 ', '-2', 'NaN'][index % 7] : '0.01',
      evidence: unfinished && index === 2 ? '\n \t' : 'Evidence ' + index + '\n  literal <tag> & value.'
    }))
  };
}

function deepFreeze(value) {
  for (const child of Object.values(value)) {
    if (child && typeof child === 'object') deepFreeze(child);
  }
  return Object.freeze(value);
}

function expected(draft) {
  const capCents = parseDollars(draft.cap);
  assert.notEqual(capCents, null);
  const cap = BigInt(capCents);
  const count = BigInt(draft.checkpoints.length);
  const quotient = cap / count;
  const remainder = cap % count;
  return {
    capCents,
    remainderCount: Number(remainder),
    rows: draft.checkpoints.map((row, index) => {
      const cents = quotient + (BigInt(index) < remainder ? 1n : 0n);
      return {
        index, title: row.title, previousAmount: row.amount,
        nextAmount: String(cents / 100n) + '.' + String(cents % 100n).padStart(2, '0'),
        cents: Number(cents)
      };
    })
  };
}

function replaced(draft, proposal) {
  const result = copy(draft);
  for (const row of proposal.rows) result.checkpoints[row.index].amount = row.nextAmount;
  return result;
}

test('native control preserves raw draft and requires a separate zero-event review', () => {
  assert.equal(parseDollars('90071992547409.89'), 9007199254740989);
  const raw = fixture(' \t000007.03 \t', 7, true);
  const encoded = encodeScopeWorkspace({ draft: raw });
  const restored = decodeScopeWorkspace(encoded);
  assert.deepEqual(restored.draft, raw);
  assert.equal(restored.review, null);
  assert.equal(restored.summary.events, 0);
  assert.throws(() => createScopeReview(restored.draft), Error);
  const valid = fixture();
  const review = createScopeReview(valid);
  assert.equal(review.snapshot().approved, 0);
  assert.deepEqual(review.snapshot().events, []);
  assert.deepEqual(decodeScopeWorkspace(encodeScopeWorkspace({ draft: valid, review })).review.snapshot(), review.snapshot());
});

test('exact native cents allocate to earliest rows while preserving every raw non-amount field', async () => {
  const cases = [
    { cap: ' \t000007.03 \t', count: 7, amounts: ['1.01', '1.01', '1.01', '1.00', '1.00', '1.00', '1.00'] },
    { cap: '90071992547409.89', count: 11, amounts: [...Array(5).fill('8188362958855.45'), ...Array(6).fill('8188362958855.44')] },
    { cap: '0.12', count: 12, amounts: Array(12).fill('0.01') },
    { cap: '9.2', count: 1, amounts: ['9.20'] }
  ];
  for (const item of cases) {
    const draft = deepFreeze(fixture(item.cap, item.count, true));
    const before = copy(draft);
    const controller = await allocation();
    assert.equal(controller.available, false);
    const oracle = expected(draft);
    assert.deepEqual(oracle.rows.map(row => row.nextAmount), item.amounts);
    const proposal = controller.prepare(draft);
    assert.deepEqual(proposal, oracle);
    assert.equal(controller.available, true);
    assert.deepEqual(draft, before);
    const result = controller.apply(draft);
    assert.deepEqual(result, replaced(before, oracle));
    assert.equal(result.cap, item.cap);
    assert.deepEqual(draft, before);
    assert.equal(draftBudget(result).unallocated, 0);
    assert.equal(draftBudget(result).allocated, oracle.capCents);
    assert.deepEqual(decodeScopeWorkspace(encodeScopeWorkspace({ draft: result })).draft, result);
  }
});

test('mutable proposal is detached and canonical key order preserves single-use apply', async () => {
  const controller = await allocation();
  const draft = deepFreeze(fixture('10.07', 6));
  const oracle = expected(draft);
  const proposal = controller.prepare(draft);
  proposal.capCents = 1;
  proposal.remainderCount = 0;
  proposal.rows[0].cents = 1;
  proposal.rows[0].nextAmount = '999.99';
  proposal.rows[0].title = 'tampered';
  proposal.rows.reverse();
  proposal.rows.push({ index: 40, title: 'extra', nextAmount: '1.00', cents: 100 });
  const reordered = Object.fromEntries(Object.entries(copy(draft)).reverse());
  reordered.checkpoints = reordered.checkpoints.map(row => Object.fromEntries(Object.entries(row).reverse()));
  const before = copy(reordered);
  const result = controller.apply(reordered);
  assert.deepEqual(result, replaced(draft, oracle));
  assert.deepEqual(reordered, before);
  assert.notEqual(result, reordered);
  assert.notEqual(result.checkpoints, reordered.checkpoints);
  assert.notEqual(result.checkpoints[0], reordered.checkpoints[0]);
  result.checkpoints[0].evidence = 'output changed afterwards';
  assert.equal(reordered.checkpoints[0].evidence, draft.checkpoints[0].evidence);
  assert.equal(controller.available, false);
  assert.throws(() => controller.apply(draft), Error);
  assert.deepEqual(draft, fixture('10.07', 6));
});

test('invalid preparation clears older proposals through native draft and cap admission', async () => {
  const valid = fixture();
  const invalid = ['0.06', '0', '-1', '1e2', '1.234', '90071992547410.00', '']
    .map(cap => ({ ...copy(valid), cap }));
  for (const mutate of [
    draft => { draft.extra = 'unsupported'; },
    draft => { draft.checkpoints[0].amount = 23; },
    draft => { draft.checkpoints[1].title = 'CR\rvalue'; },
    draft => { draft.checkpoints[0].extra = 'unsupported'; },
    draft => { draft.checkpoints = []; },
    draft => { draft.checkpoints = Array.from({ length: 13 }, () => copy(valid.checkpoints[0])); }
  ]) {
    const bad = copy(valid);
    mutate(bad);
    invalid.push(bad);
  }
  const controller = await allocation();
  for (const bad of invalid) {
    controller.prepare(valid);
    assert.equal(controller.available, true);
    const before = copy(bad);
    assert.throws(() => controller.prepare(bad), Error);
    assert.equal(controller.available, false);
    assert.throws(() => controller.apply(valid), Error);
    assert.deepEqual(bad, before);
    assert.deepEqual(valid, fixture());
  }
});

test('complete raw draft identity and explicit lifecycle clear retire stale proposals', async () => {
  const valid = fixture();
  const mutations = [
    draft => { draft.label += ' '; },
    draft => { draft.brief += '\n'; },
    draft => { draft.cap = '007.03'; },
    draft => { draft.checkpoints[0].title += ' '; },
    draft => { draft.checkpoints[0].evidence += '\n'; },
    draft => { draft.checkpoints[0].amount = '00.01'; },
    draft => { draft.checkpoints.reverse(); },
    draft => { draft.checkpoints.pop(); },
    draft => { draft.checkpoints.push(copy(draft.checkpoints[0])); },
    draft => { draft.extra = true; }
  ];
  const controller = await allocation();
  for (const mutate of mutations) {
    controller.prepare(valid);
    const changed = copy(valid);
    mutate(changed);
    const before = copy(changed);
    assert.throws(() => controller.apply(changed), Error);
    assert.equal(controller.available, false);
    assert.throws(() => controller.apply(valid), Error);
    assert.deepEqual(changed, before);
  }
  controller.prepare(valid);
  assert.equal(controller.clear(), undefined);
  assert.equal(controller.available, false);
  assert.throws(() => controller.apply(copy(valid)), Error);
  assert.deepEqual(valid, fixture());
});

test('allocated draft reaches ordinary review with no approvals or payment events', async () => {
  const draft = fixture('7.03', 7);
  const original = copy(draft);
  const controller = await allocation();
  const proposal = controller.prepare(draft);
  const result = controller.apply(draft);
  assert.deepEqual(draft, original);
  assert.deepEqual(result, replaced(original, proposal));
  const draftFile = encodeScopeWorkspace({ draft: result });
  assert.equal(JSON.parse(draftFile).stage, 'draft');
  assert.deepEqual(JSON.parse(draftFile).events, []);
  assert.deepEqual(JSON.parse(draftFile).evidenceDrafts, []);
  assert.equal(decodeScopeWorkspace(draftFile).review, null);
  const review = createScopeReview(result);
  const state = review.snapshot();
  assert.equal(state.plan.amount, 703);
  assert.equal(state.total, 703);
  assert.equal(state.unallocated, 0);
  assert.equal(state.approved, 0);
  assert.equal(state.captured, 0);
  assert.equal(state.remaining, 703);
  assert.deepEqual(state.events, []);
  for (const row of state.checkpoints) {
    assert.equal(row.approved, false);
    assert.equal(row.orderId, null);
    assert.equal(row.captureStatus, 'not_started');
    assert.equal(row.acceptedEvidence, null);
    assert.deepEqual(row.actions, ['approve']);
  }
  const restored = decodeScopeWorkspace(encodeScopeWorkspace({ draft: result, review }));
  assert.deepEqual(restored.draft, result);
  assert.deepEqual(restored.review.snapshot(), state);
  const unfinished = fixture('7.03', 7, true);
  controller.prepare(unfinished);
  const stillUnfinished = controller.apply(unfinished);
  assert.equal(stillUnfinished.checkpoints[1].title, '');
  assert.equal(stillUnfinished.checkpoints[2].evidence, '\n \t');
  assert.throws(() => createScopeReview(stillUnfinished), Error);
});
