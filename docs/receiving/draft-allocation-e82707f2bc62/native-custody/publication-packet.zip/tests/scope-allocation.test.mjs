import test from 'node:test';
import assert from 'node:assert/strict';
import { resolve } from 'node:path';
import { pathToFileURL } from 'node:url';

const root = resolve(process.env.SCOPESIGNAL_SOURCE ?? new URL('../', import.meta.url).pathname);
const { draftFromFixture, createScopeReview, parseDollars } = await import(pathToFileURL(`${root}/src/scope-plan.mjs`));
const { encodeScopeWorkspace, decodeScopeWorkspace } = await import(pathToFileURL(`${root}/src/scope-workspace-record.mjs`));
const allocation = () => import(pathToFileURL(`${root}/src/scope-allocation.mjs`)).then(m => m.createDraftAllocation());
function fixture(cap, count = 3) {
  const original = draftFromFixture();
  return { ...original, cap, checkpoints: Array.from({ length: count }, (_, i) => ({
    title: ` <step ${i}> Ω `, amount: i === 0 ? ' unfinished ' : '', evidence: `line ${i}\n  literal & detail `
  })) };
}

test('the original native codec preserves unfinished amounts and needs no approvals', () => {
  const draft = fixture('1.00');
  const decoded = decodeScopeWorkspace(encodeScopeWorkspace({ draft }));
  assert.deepEqual(decoded.draft, draft);
  assert.equal(decoded.review, null);
});

test('reviewed equal proposals allocate every cent, including ordered remainder cents', async () => {
  for (const [cap, count, expected] of [
    ['0.05', 3, [2, 2, 1]], ['123.45', 4, [3087, 3086, 3086, 3086]],
    ['1.00', 6, [17, 17, 17, 17, 16, 16]], ['0.01', 1, [1]]
  ]) {
    const model = await allocation(); const draft = fixture(cap, count);
    const proposal = model.prepare(draft);
    assert.equal(proposal.capCents, parseDollars(cap));
    assert.deepEqual(proposal.rows.map(row => row.cents), expected);
    assert.deepEqual(proposal.rows.map(row => row.previousAmount), draft.checkpoints.map(row => row.amount));
    const applied = model.apply(draft);
    assert.deepEqual(applied.checkpoints.map(row => parseDollars(row.amount)), expected);
    const state = createScopeReview(applied).snapshot();
    assert.equal(state.total, proposal.capCents);
    assert.equal(state.unallocated, 0); assert.equal(state.approved, 0); assert.deepEqual(state.events, []);
  }
});

test('every admitted row count gets positive near-equal amounts with an exact sum', async () => {
  const model = await allocation();
  for (let count = 1; count <= 12; count += 1) {
    for (const cents of [count, count + 1, count * 2 - 1, 99991]) {
      const draft = fixture(`${Math.floor(cents / 100)}.${String(cents % 100).padStart(2, '0')}`, count);
      const rows = model.prepare(draft).rows;
      assert.equal(rows.reduce((sum, row) => sum + BigInt(row.cents), 0n), BigInt(cents));
      assert.ok(rows.every(row => row.cents > 0));
      assert.ok(Math.max(...rows.map(row => row.cents)) - Math.min(...rows.map(row => row.cents)) <= 1);
      assert.ok(rows.every((row, i) => row.index === i && (i === 0 || row.cents <= rows[i - 1].cents)));
    }
  }
});

test('preview and application preserve every non-amount string and leave caller data detached', async () => {
  const model = await allocation(); const draft = fixture(' 00100.01 '); const before = structuredClone(draft);
  const preview = model.prepare(draft); assert.deepEqual(draft, before);
  preview.rows[0].nextAmount = '999'; preview.rows[0].cents = 999; preview.capCents = 999;
  const next = model.apply(draft);
  assert.deepEqual(draft, before);
  assert.deepEqual(next, { ...before, checkpoints: before.checkpoints.map((row, i) => ({ ...row, amount: i < 2 ? '33.34' : '33.33' })) });
  next.checkpoints[0].title = 'later edit'; assert.deepEqual(draft, before);
  assert.throws(() => model.apply(draft));
});

test('invalid caps and too-small caps refuse without replacing any amount', async () => {
  const model = await allocation();
  for (const cap of ['0.02', '', '0', '-1', '0.001', '1e2', 'Infinity', '90071992547410.00']) {
    const draft = fixture(cap); const before = structuredClone(draft);
    assert.throws(() => model.prepare(draft));
    assert.equal(model.available, false); assert.deepEqual(draft, before);
  }
  for (const draft of [fixture('1', 0), fixture('1', 13), { ...fixture('1'), unknown: true }]) {
    assert.throws(() => model.prepare(draft)); assert.equal(model.available, false);
  }
});

test('any changed draft refuses apply and consumes its proposal', async () => {
  for (const change of [
    draft => { draft.label += '!'; }, draft => { draft.brief += '!'; }, draft => { draft.cap = '1.01'; },
    draft => { draft.checkpoints[0].title += '!'; }, draft => { draft.checkpoints[0].amount = '0.20'; },
    draft => { draft.checkpoints[0].evidence += '!'; }, draft => { draft.checkpoints.reverse(); }
  ]) {
    const model = await allocation(); const draft = fixture('1.00'); model.prepare(draft); change(draft);
    const before = structuredClone(draft); assert.throws(() => model.apply(draft));
    assert.equal(model.available, false); assert.deepEqual(draft, before); assert.throws(() => model.apply(draft));
  }
});

test('cancel and unsuccessful replacement preparation retire older proposals', async () => {
  const model = await allocation(); const draft = fixture('1');
  model.prepare(draft); assert.equal(model.available, true); model.clear();
  assert.equal(model.available, false); assert.throws(() => model.apply(draft));
  model.prepare(draft); assert.throws(() => model.prepare(fixture('bad')));
  assert.equal(model.available, false); assert.throws(() => model.apply(draft));
});

test('saved applied drafts retain native identity and still require valid scope text', async () => {
  const model = await allocation(); const draft = fixture('0.12', 12);
  model.prepare(draft); const next = model.apply(draft);
  const saved = encodeScopeWorkspace({ draft: next });
  const decoded = decodeScopeWorkspace(saved);
  assert.deepEqual(decoded.draft, next); assert.equal(decoded.summary.stage, 'draft');
  assert.equal(decoded.summary.approved, 0); assert.equal(decoded.summary.events, 0);
  const state = createScopeReview(decoded.draft).snapshot();
  assert.deepEqual(state.checkpoints.map(row => row.id), Array.from({ length: 12 }, (_, i) => `scope-${i + 1}`));
  const unfinished = fixture('1'); unfinished.brief = '';
  model.prepare(unfinished); const balanced = model.apply(unfinished);
  assert.throws(() => createScopeReview(balanced));
});
